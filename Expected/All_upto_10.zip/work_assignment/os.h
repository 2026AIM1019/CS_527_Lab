#ifndef OS_H
#define OS_H

#include "processor.h"

#define TIME_SLICE 10
#define MAX_PROCESSES 128

typedef enum { SCHED_RR=0, SCHED_PRIORITY, SCHED_SJF, SCHED_FEEDBACK } SchedulerPolicy;

void os_init(void);
int loader(const char *program_file, const char *data_file);
int loader_with_priority(const char *program_file, const char *data_file, int priority);
void scheduler(void);
void shell(void);
int os_should_exit(void);
void os_print_processes(void);
void os_print_memory_maps(void);
void os_set_policy(SchedulerPolicy policy);
const char *os_policy_name(void);

#endif
