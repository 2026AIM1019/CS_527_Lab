#ifndef COMPILER_H
#define COMPILER_H

/* Compile source text into four-byte-per-instruction bytecode. */
void compile(const char *source_file, const char *program_file);

#endif
