#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>
#include <time.h>
#include <stdarg.h>
#include "os.h"
#include "compiler.h"
#include "memory.h"
#include "processor.h"

/*
 * ----------------------------- OS OVERVIEW -----------------------------
 *
 * The old version associated a permanent register bank with each processor.
 * This version separates the two ideas:
 *
 *     PROCESS = saved CPUContext + address space + accounting information
 *     CPU     = one reusable execution resource
 *
 * The scheduler chooses one READY process, restores its CPUContext, executes
 * a time slice, and saves the context again.  Thus many programs appear to
 * run "in parallel" even though the default machine has only one CPU.
 *
 * Build with `make MP=1` to compile the same scheduler with NP=4.  In that
 * mode each CPU can hold one process at a time, while the process context is
 * still explicitly saved and restored by the OS.
 */

typedef enum { UNUSED=0, READY, RUNNING, WAITING } State;

typedef struct {
    int pid;
    int slot;                  /* index in the OS process table */
    int cpu_id;
    State state;
    int priority;
    unsigned long age;
    unsigned long slices;
    unsigned long instructions;
    unsigned long remaining_estimate;
    unsigned long rr_ticket;
    char program_file[512];
    char data_file[512];
    char generated_program[512];
    CPUContext context;
    int loaded;                /* 1 once its logical pages are resident */
} Task;

static Task tasks[MAX_PROCESSES];
static int next_pid = 1;
static int cpu_task[NP];
static int shell_exit = 0;
static char shell_line[1024];
static int shell_len = 0;
static int prompt_shown = 0;
static unsigned long scheduler_round = 0;
static SchedulerPolicy policy = SCHED_RR;
static int time_slice = TIME_SLICE;
static unsigned long rr_counter = 0;
static int demo_mode = 0;

static void log_event(const char *fmt, ...)
{
    if (!fd_log) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(fd_log, fmt, ap);
    va_end(ap);
    fflush(fd_log);
}

static void msleep(unsigned usec)
{
    struct timespec ts = {usec / 1000000U, (long)(usec % 1000000U) * 1000L};
    nanosleep(&ts, NULL);
}

static Task *task_by_pid(int pid)
{
    for (int i=0;i<MAX_PROCESSES;i++)
        if (tasks[i].state != UNUSED && tasks[i].pid == pid) return &tasks[i];
    return NULL;
}

static Task *task_by_slot(int slot)
{
    if (slot < 0 || slot >= MAX_PROCESSES || tasks[slot].state == UNUSED) return NULL;
    return &tasks[slot];
}

static int free_slot(void)
{
    for (int i=0;i<MAX_PROCESSES;i++) if (tasks[i].state == UNUSED) return i;
    return -1;
}

static int file_readable(const char *path)
{
    FILE *f = fopen(path,"r");
    if (!f) return 0;
    fclose(f);
    return 1;
}

static int copy_file(const char *src, const char *dst)
{
    FILE *a=fopen(src,"rb"), *b;
    char buf[4096]; size_t n;
    if(!a) return 0;
    b=fopen(dst,"wb"); if(!b){fclose(a);return 0;}
    while((n=fread(buf,1,sizeof(buf),a))>0) if(fwrite(buf,1,n,b)!=n){fclose(a);fclose(b);return 0;}
    fclose(a); fclose(b); return 1;
}

static void sibling_path(const char *source,const char *name,char *out,size_t n)
{
    const char *slash=strrchr(source,'/');
    if(slash){size_t k=(size_t)(slash-source); if(k+1+strlen(name)+1<=n){memcpy(out,source,k);out[k]='/';strcpy(out+k+1,name);return;}}
    snprintf(out,n,"%s",name);
}

void os_init(void)
{
    memset(tasks,0,sizeof(tasks));
    memset(cpu_task,0,sizeof(cpu_task));
    for(int i=0;i<NP;i++) cpu_task[i]=-1;
    next_pid=1; shell_exit=0; shell_len=0; prompt_shown=0; scheduler_round=0;
    policy=SCHED_RR; time_slice=TIME_SLICE; rr_counter=0;
    demo_mode=(getenv("OS_DEMO")!=NULL);
    memory_system_init();
    memset(&cpu_stats,0,sizeof(cpu_stats));
    reset(0);
    fd_log=fopen("process.log","w");
    if(fd_log){
        log_event("============================================================\n");
        log_event("CS527 EXTENDED MINI-COMPUTER OS\n");
        log_event("CPUs=%d  physical memory=%d bytes  page size=%d\n",NP,MEMSIZE,PAGESIZE);
        log_event("Scheduler=%s  time-slice=%d\n\n",os_policy_name(),time_slice);
    }
}

static int ensure_task_loaded(Task *t)
{
    if (!t) return -1;
    if (t->loaded) return 0;
    if (initialize(t->slot,t->program_file,t->data_file)!=0) return -1;
    t->loaded=1;
    memset(&t->context,0,sizeof(t->context));
    t->context.pid=t->pid;
    return 0;
}

static int ensure_task_loaded_for_share(Task *t)
{
    if (!t) return -1;
    if (t->loaded) return 0;
    if (initialize_minimal(t->slot,t->program_file,t->data_file)!=0) return -1;
    t->loaded=1;
    memset(&t->context,0,sizeof(t->context));
    t->context.pid=t->pid;
    return 0;
}

static int dispatch_to_cpu(Task *t,int cpu_id)
{
    if(!t || cpu_id<0 || cpu_id>=NP) return -1;
    if(!t->loaded){
        if(ensure_task_loaded(t)!=0) return -1;
        t->context.pc=0;
        t->context.halted=0;
    }
    /* A resumed process receives the exact context saved at the last switch. */
    load_context(cpu_id,t->slot,&t->context);
    set_processor_pid(cpu_id,t->pid);
    t->cpu_id=cpu_id;
    t->state=RUNNING;
    cpu_task[cpu_id]=t->slot;
    return 0;
}

int loader_with_priority(const char *program_file,const char *data_file,int priority)
{
    if(!program_file || !data_file || !*program_file || !*data_file) return -1;
    if(!file_readable(program_file) || !file_readable(data_file)){
        fprintf(stderr,"OS: input file cannot be opened\n"); return -1;
    }
    int slot=free_slot();
    if(slot<0 || next_pid>MAX_PROCESSES){fprintf(stderr,"OS: process table full\n");return -1;}

    char program_byte[512]={0}, generated[512]={0};
    const char *dot=strrchr(program_file,'.');
    if(dot && strcmp(dot,".txt")==0){
        sibling_path(program_file,"program.byte",program_byte,sizeof(program_byte));
        compile(program_file,program_byte);
        snprintf(generated,sizeof(generated),"%s.pid%d",program_byte,next_pid);
        if(!copy_file(program_byte,generated)){fprintf(stderr,"OS: compiler output could not be preserved\n");return -1;}
        program_file=generated;
    }

    Task *t=&tasks[slot];
    memset(t,0,sizeof(*t));
    t->pid=next_pid++; t->slot=slot; t->cpu_id=-1; t->state=WAITING;
    t->priority=priority; t->age=0; t->remaining_estimate=1; t->rr_ticket=rr_counter++;
    snprintf(t->program_file,sizeof(t->program_file),"%s",program_file);
    snprintf(t->data_file,sizeof(t->data_file),"%s",data_file);
    snprintf(t->generated_program,sizeof(t->generated_program),"%s",generated);
    {
        FILE *pf=fopen(t->program_file,"r");
        unsigned long bytes=0; unsigned int value;
        if(pf){while(fscanf(pf,"%x",&value)==1) ++bytes; fclose(pf);}
        t->remaining_estimate = bytes ? (bytes + 3) / 4 : 1;
    }

    /* In the single-CPU configuration, the CPU is not a reason to reject a
     * task.  If RAM has enough free frames, the task becomes READY and waits
     * for the scheduler. */
    t->state=READY;
    log_event("[LOADER] PID %d created: priority=%d\n",t->pid,t->priority);
    printf("[OS] PID %d accepted (priority %d)\n",t->pid,t->priority);
    fflush(stdout);
    return t->pid;
}

int loader(const char *program_file,const char *data_file)
{
    return loader_with_priority(program_file,data_file,0);
}

static int ready_count(void)
{
    int n=0; for(int i=0;i<MAX_PROCESSES;i++) if(tasks[i].state==READY) ++n; return n;
}

static int choose_ready(void)
{
    int best=-1;
    for(int i=0;i<MAX_PROCESSES;i++){
        if(tasks[i].state!=READY) continue;
        if(best<0){best=i;continue;}
        Task *a=&tasks[i], *b=&tasks[best];
        switch(policy){
            case SCHED_PRIORITY:
                if(a->priority>b->priority || (a->priority==b->priority && a->pid<b->pid)) best=i;
                break;
            case SCHED_SJF:
                if(a->remaining_estimate<b->remaining_estimate ||
                   (a->remaining_estimate==b->remaining_estimate && a->pid<b->pid)) best=i;
                break;
            case SCHED_FEEDBACK:
                /* Higher priority wins, but waiting time ages a process. */
                if(a->priority+(int)(a->age/5) > b->priority+(int)(b->age/5)) best=i;
                break;
            case SCHED_RR:
            default:
                /* rr_ticket is advanced after every time slice, so this is a
                 * real rotating queue rather than repeatedly choosing PID 1. */
                if(a->rr_ticket < b->rr_ticket) best=i;
                break;
        }
    }
    return best;
}

static int find_free_cpu(void)
{
    for(int i=0;i<NP;i++) if(cpu_task[i]<0) return i;
    return -1;
}

static void dispatch_ready_tasks(void)
{
    for(;;){
        int c=find_free_cpu(); if(c<0) return;
        int slot=choose_ready(); if(slot<0) return;
        Task *t=&tasks[slot];
        if(dispatch_to_cpu(t,c)!=0){
            /* Insufficient frames: keep it waiting.  The next completed task
             * will release RAM and the scheduler will retry this task. */
            t->state=WAITING;
            log_event("[MMU] PID %d waiting for physical frames\n",t->pid);
            continue;
        }
        log_event("[DISPATCH] PID %d -> CPU %d\n",t->pid,c);
    }
}

static void reap_finished(void)
{
    for(int c=0;c<NP;c++){
        if(cpu_task[c]<0) continue;
        Task *t=task_by_slot(cpu_task[c]);
        if(!t) {cpu_task[c]=-1;continue;}
        if(!cpu.halted) continue;

        save_context(c,&t->context);
        finalize(t->slot,t->data_file);
        log_event("[FINISH] PID %d completed; context discarded and pages freed\n",t->pid);
        printf("[OS] PID %d finished on CPU %d\n",t->pid,c);
        if(t->generated_program[0]) unlink(t->generated_program);
        t->state=UNUSED; t->cpu_id=-1; t->loaded=0; cpu_task[c]=-1;
    }
}

void os_set_policy(SchedulerPolicy p)
{
    policy=p;
    log_event("[SCHEDULER] policy changed to %s\n",os_policy_name());
    printf("[OS] Scheduling policy: %s\n",os_policy_name());
}

const char *os_policy_name(void)
{
    switch(policy){case SCHED_PRIORITY:return "priority";case SCHED_SJF:return "sjf";case SCHED_FEEDBACK:return "feedback";default:return "round-robin";}
}

void os_print_processes(void)
{
    printf("PID   STATE    CPU  PRI  SLICES  PC   INSTR\n");
    for(int i=0;i<MAX_PROCESSES;i++) if(tasks[i].state!=UNUSED){
        const char *s=tasks[i].state==READY?"READY":tasks[i].state==RUNNING?"RUNNING":"WAITING";
        int pc=(tasks[i].state==RUNNING && tasks[i].cpu_id==0)?cpu.pc:tasks[i].context.pc;
        printf("%-5d %-8s %-4d %-4d %-7lu %-4d %lu\n",tasks[i].pid,s,tasks[i].cpu_id,tasks[i].priority,tasks[i].slices,pc,tasks[i].instructions);
    }
}

void os_print_memory_maps(void)
{
    for(int i=0;i<MAX_PROCESSES;i++) if(tasks[i].state!=UNUSED) print_memory_map(tasks[i].slot);
    print_physical_memory_usage();
}

static void print_prompt(void){if(!prompt_shown&&!shell_exit){printf("$ ");fflush(stdout);prompt_shown=1;}}

void shell(void)
{
    fd_set set; struct timeval tv={0,0}; char ch;
    if(shell_exit) return;
    print_prompt(); FD_ZERO(&set); FD_SET(STDIN_FILENO,&set);
    if(select(STDIN_FILENO+1,&set,NULL,NULL,&tv)<=0) return;

    while(read(STDIN_FILENO,&ch,1)==1){
        if(ch=='\r') continue;
        if(ch=='\n'){
            shell_line[shell_len]='\0'; char local[1024]; snprintf(local,sizeof(local),"%s",shell_line); shell_len=0;
            char *s=local; while(*s==' '||*s=='\t'||*s=='$') ++s;
            char *save=NULL,*cmd=strtok_r(s," \t",&save); char *a=strtok_r(NULL," \t",&save); char *b=strtok_r(NULL," \t",&save); char *c=strtok_r(NULL," \t",&save);
            if(!cmd){prompt_shown=0;print_prompt();return;}
            if(strcmp(cmd,"exit")==0){shell_exit=1;printf("[OS] Shell stopped accepting new tasks.\n");return;}
            if(strcmp(cmd,"help")==0){
                printf("run <program.txt|program.byte> <data.byte> [priority]\n");
                printf("schedule rr|priority|sjf|feedback [slice]\n");
                printf("ps | memmap | perf | cache | flushcache | share <ownerPID> <targetPID> <dataPage>\n");
                printf("protect <PID> <dataPage> <rwx>\n");
            } else if(strcmp(cmd,"run")==0 && a && b){
                int pri=c?atoi(c):0; loader_with_priority(a,b,pri);
            } else if(strcmp(cmd,"schedule")==0 && a){
                if(strcmp(a,"rr")==0) os_set_policy(SCHED_RR);
                else if(strcmp(a,"priority")==0) os_set_policy(SCHED_PRIORITY);
                else if(strcmp(a,"sjf")==0) os_set_policy(SCHED_SJF);
                else if(strcmp(a,"feedback")==0) os_set_policy(SCHED_FEEDBACK);
                else fprintf(stderr,"Unknown scheduler policy.\n");
                if(b){int q=atoi(b);if(q>0&&q<1000)time_slice=q;}
            } else if(strcmp(cmd,"ps")==0) os_print_processes();
            else if(strcmp(cmd,"memmap")==0) os_print_memory_maps();
            else if(strcmp(cmd,"perf")==0) processor_print_stats();
            else if(strcmp(cmd,"cache")==0) processor_print_cache_tlb();
            else if(strcmp(cmd,"flushcache")==0) processor_flush_cache_tlb();
            else if(strcmp(cmd,"share")==0 && a && b && c){
                Task *owner=task_by_pid(atoi(a)), *target=task_by_pid(atoi(b));
                int page=atoi(c);
                /* The command may be issued before the target has ever run.
                 * Materialising its address space here makes IPC setup explicit
                 * and avoids losing the shared PTE during first dispatch. */
                if(owner && target && ensure_task_loaded(owner)==0 && ensure_task_loaded_for_share(target)==0 &&
                   share_memory_page(owner->slot,target->slot,page)==0)
                    printf("[OS] shared data page %d: PID %d -> PID %d\n",page,owner->pid,target->pid);
                else fprintf(stderr,"[OS] share failed\n");
            } else fprintf(stderr,"[Shell] Invalid command; type help\n");
            prompt_shown=0; print_prompt(); return;
        }
        if(shell_len<(int)sizeof(shell_line)-1) shell_line[shell_len++]=ch;
    }
    shell_exit=1;
}

void scheduler(void)
{
    while(1){
        ++scheduler_round;
        dispatch_ready_tasks();

        int active=0;
        for(int c=0;c<NP;c++){
            if(cpu_task[c]<0) continue;
            active=1;
            Task *t=task_by_slot(cpu_task[c]);
            if(!t) continue;
            log_event("[SCHED] round=%lu CPU=%d PID=%d policy=%s slice=%d\n",scheduler_round,c,t->pid,os_policy_name(),time_slice);
            unsigned long before=cpu_stats.instructions;
            process_instructions(c,time_slice);
            unsigned long retired=cpu_stats.instructions-before;
            t->instructions += retired;
            if(!cpu.halted){
                /* Context switch: save every register, vector register, PC and flags. */
                save_context(c,&t->context);
                t->state=READY; t->cpu_id=-1; t->slices++; t->rr_ticket=rr_counter++; t->remaining_estimate = retired>=t->remaining_estimate ? 1 : t->remaining_estimate-retired;
                cpu_task[c]=-1;
                log_event("[CONTEXT SWITCH] PID %d saved (PC=%d, %lu instructions this slice)\n",t->pid,t->context.pc,retired);
            }
        }

        reap_finished();
        /* Age waiting/ready processes so feedback scheduling cannot starve them. */
        for(int i=0;i<MAX_PROCESSES;i++) if(tasks[i].state==READY || tasks[i].state==WAITING) tasks[i].age++;
        shell();
        dispatch_ready_tasks();

        active=0;
        for(int c=0;c<NP;c++) if(cpu_task[c]>=0) active=1;
        int queued=ready_count();
        for(int i=0;i<MAX_PROCESSES;i++) if(tasks[i].state==WAITING) queued=1;
        if(shell_exit && !active && !queued) break;
        msleep(1000);
    }
    if(fd_log){log_event("[OS] scheduler stopped\n");fclose(fd_log);fd_log=NULL;}
}

int os_should_exit(void){return shell_exit;}
