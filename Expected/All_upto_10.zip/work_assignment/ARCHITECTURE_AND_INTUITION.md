# Architecture, Intuition, and Complete Execution Flow

## 1. Big picture

The simulator is easiest to understand as four layers:

1. **Compiler** translates readable source into four-byte instructions.
2. **OS** creates processes, owns queues, chooses who gets CPU time, and saves/restores process state.
3. **Processor** executes the ISA and accounts for cache, TLB, pipeline, and performance timing.
4. **Memory/MMU** translates logical addresses into physical addresses, enforces page permissions, and owns physical frames.

The central idea of the extension is separation of **process state** from **CPU hardware**. A process is not a processor. A CPU is a resource that can be borrowed by one process, its state saved, and then reused by another process.

## 2. Single processor multitasking

The default build has `NP=1`. Suppose PID 1 executes ten instructions and is then preempted.

```text
PID 1 context before slice
       |
       v
CPU registers / PC / flags
       |
       | execute 10 instructions
       v
save_context()
       |
       v
PID 1 saved context
       |
       +---- CPU is now free ----+
                                  |
                                  v
                           load PID 2 context
```

PID 1 is not restarted. Its registers, vector registers, PC and condition flags are copied into its `CPUContext`. When it runs again, execution resumes from exactly that saved PC.

This is the mechanism that creates the illusion of parallel progress on one CPU.

## 3. Round robin and other schedulers

The scheduler maintains process states:

```text
READY -> RUNNING -> READY -> RUNNING ...
                    |
                    +--> FINISHED
```

Four policies are available:

- **round-robin:** oldest `rr_ticket` gets the next turn.
- **priority:** highest priority wins.
- **SJF:** smallest remaining instruction estimate wins.
- **feedback:** priority is combined with accumulated waiting age, reducing starvation.

A time slice is the maximum number of architectural instructions executed before a context switch.

## 4. Physical page tables

The logical address space of one process is split into pages. Physical RAM is split into frames of the same size.

For the default constants:

```text
logical instruction space = 1024 bytes = 2 pages
logical data space        = 4096 bytes = 8 pages
one process               = 10 PTEs
physical memory           = 8192 bytes = 16 frames
```

Instead of keeping `pageTable[process][page]` as a C array, the PTE bytes are placed in reserved physical frames. A PTE stores:

```text
low nibble  = physical frame number
high bits   = R/W/X/SHARED permissions
```

Therefore the MMU must read the page-table entry from simulated RAM before producing a physical address.

## 5. Address translation

For instruction fetches:

```text
logical page = address / PAGESIZE
```

For data accesses:

```text
logical page = 2 + address / PAGESIZE
```

Then:

```text
physical address = frame * PAGESIZE + page offset
```

The processor first checks the TLB. On a TLB miss it consults the page table in physical memory, checks permissions, and installs the translation in the TLB.

## 6. Security permissions

Instruction pages are mapped with `RX`. Data pages are mapped with `RW`.

This gives a basic protection boundary:

```text
instruction fetch -> needs X
load              -> needs R
store             -> needs W
```

A forbidden operation produces a security fault and halts the offending task instead of silently accessing another page.

## 7. Cache

The processor contains a small direct-mapped cache. Normal RAM accesses go through the cache after address translation. MMIO is deliberately not cached because device registers must have immediate side effects.

The performance utility reports:

```text
cache hits
cache misses
hit rate
```

The cache is write-through, which keeps the implementation easy to reason about: a store updates both RAM and an already resident cache line.

## 8. TLB

The TLB caches page translations:

```text
(task, logical page) -> (physical frame, permissions)
```

The task identifier is part of the tag. Therefore PID 1 cannot accidentally reuse PID 2's translation.

The utility reports TLB hits and misses. `flushcache` clears both cache and TLB state.

## 9. Pipeline

The processor exposes the classic five conceptual stages:

```text
IF -> ID -> EX -> MEM -> WB
```

The simulator charges five base timing units per retired instruction and adds a two-cycle branch flush penalty when a branch changes control flow. The stage model is intentionally conservative and educational: architectural effects remain deterministic, while timing counters expose the performance impact of pipelining and control flow.

## 10. Memory-mapped I/O

A small logical range is reserved for devices. The most useful device is:

```text
0xF00 = console output
```

A normal store to `0xF00` therefore becomes a device write instead of a RAM write. This demonstrates the key MMIO idea: the processor uses the same load/store ISA, but the address selects a device.

## 11. Shared-memory IPC

The source directive `SHARED 0` marks data page 0 as shareable in the owner PTE. The OS `share` command then makes two processes point at the same physical frame.

```text
PID 1 data page 0 ----+
                     +---- physical frame F
PID 2 data page 0 ----+
```

The frame uses reference counting, so finishing one process does not free the physical frame while another process still maps it.

The shared bit is stored in each PTE, so the sharing relationship is visible through `memmap`.

The ISA also contains `SHLOAD` and `SHSTORE` forms. They use the same memory system; sharing is a page-table property rather than a second RAM implementation.

## 12. Virtual registers, liveness, coloring and spilling

The compiler accepts virtual integer names such as `r0`, `r1`, ... . It records the first and last source line where each virtual value is used.

The interval:

```text
[first use, last use]
```

is treated as its live range. Overlapping live ranges interfere and cannot use the same physical register.

A linear-scan greedy allocator reuses a physical x-register when the previous live range has ended. Up to 240 physical registers are available to the virtual allocator, leaving scratch registers for spill/reload operations.

If no color is available, the virtual value receives a spill slot in the compiler-managed data area. The compiler emits a reload before use and a store after the instruction. This is the educational version of register spilling.

## 13. End-to-end execution

When a user enters:

```text
run program.txt data.byte
```

the following happens:

```text
1. Shell parses the command.
2. OS loader invokes compiler if the program is source text.
3. Compiler emits program.byte.
4. OS creates a PID and process table entry.
5. Scheduler selects the task.
6. MMU allocates physical frames for instruction/data pages.
7. Page-table entries are written into reserved physical frames.
8. CPUContext is initialized.
9. Processor fetches an instruction.
10. TLB/cache/MMU translate the instruction address.
11. Decode/execute performs the ISA operation.
12. Data accesses repeat the translation + permission + cache path.
13. After the time slice, OS saves CPUContext.
14. Another READY task receives the CPU.
15. A halted task is finalized: data is reconstructed and written back.
16. Its frames are released, allowing waiting tasks to start.
```

## 14. Why this design is useful

The implementation deliberately keeps the boundaries visible:

- **OS** decides *who runs*.
- **CPU** decides *how instructions execute*.
- **MMU** decides *where memory lives and whether access is legal*.
- **Compiler** decides *how source constructs become ISA instructions*.
- **Physical memory** is the shared resource underneath all processes.

That separation makes each requested extension understandable and testable without rewriting the whole simulator.
