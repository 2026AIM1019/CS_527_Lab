# CS527 Extended Mini-Computer

This repository starts from the supplied CS527 Lab 5 implementation and extends it with the requested operating-system and processor concepts. The original Lab 5 behavior is retained: scalar/vector ISA, compiler, logical-to-physical translation, page allocation, shell, Print, and data finalisation.

## What was added

1. **Single-CPU multitasking and context switching** - the default machine has one CPU. Each process owns a saved `CPUContext`; the scheduler restores it for a time slice and saves it again at preemption. This lets many processes make progress on one processor.
2. **Multiprocessor extension** - `make MP=1` builds with four logical CPU execution resources. The same context abstraction is used for each CPU.
3. **Multiple scheduling policies** - round-robin, priority, shortest-job-first estimate, and aging feedback scheduling.
4. **Page tables in physical memory** - page-table bytes live in reserved physical frames rather than an OS C array.
5. **Memory-mapped I/O** - logical `0xF00` is a console output register; status/timer/PID registers are also provided.
6. **Utilities** - `ps`, `memmap`, `perf`, `cache`, and cache/TLB flush support.
7. **Cache + TLB + pipeline timing** - a small direct-mapped cache, tagged TLB, and five-stage pipeline timing model record hits, misses, cycles, stalls and branch flushes.
8. **Shared-memory IPC** - `share <ownerPID> <targetPID> <dataPage>` maps the same physical data frame into another process and records the shared permission bit.
9. **Page permissions** - PTEs contain R/W/X/SHARED permission bits. Accesses are checked by the MMU.
10. **Virtual-register allocation** - source `r0`, `r1`, ... names are analyzed with live intervals and greedily colored onto physical x-registers. Values beyond the available color set use a simple spill/reload mechanism.

## Build

```bash
make clean
make
```

The default build uses **one processor**.

To build the multiprocessor extension:

```bash
make MP=1
```

## Run with command-line input

The executable accepts pairs of files:

```bash
./executable tests/test_02/program.txt tests/test_02/data.byte
```

Multiple programs can be supplied:

```bash
./executable tests/lab4_multiprocess/program1.txt tests/lab4_multiprocess/data1.byte \
             tests/lab4_multiprocess/program2.txt tests/lab4_multiprocess/data2.byte
```

After command-line tasks are loaded, the non-blocking shell remains active. Type:

```text
exit
```

to stop accepting new programs. Existing tasks continue until completion.

## Interactive shell input

Start with:

```bash
./executable
```

Then use:

```text
$ run tests/test_02/program.txt tests/test_02/data.byte 5
$ schedule rr 10
$ schedule priority 10
$ schedule sjf 10
$ schedule feedback 10
$ ps
$ memmap
$ perf
$ cache
$ flushcache
$ share 1 2 0
$ protect 1 0 rw
$ help
$ exit
```

The optional number on `run` is the process priority. Higher priority is preferred by the priority scheduler.

`SHARED PAGE` in a source program marks a data page as shareable and compiles to the `SHAREPAGE` ISA directive.

`share OWNER TARGET PAGE` then maps that owner page into the target process. Page 0 means logical data addresses 0..511.

`protect PID PAGE PERMISSIONS` changes permissions for a data page. Use combinations such as `r`, `rw`, or `rwx`.

## Memory-mapped I/O

The logical data address range `0xF00..0xFFF` is reserved for devices. Important registers are:

```text
0xF00  Console output: writing the low byte prints one character
0xF04  Status register
0xF08  Timer register
0xF0C  PID/status register
```

Example source:

```text
x1 = 65
x2 = 15
x3 = x2 * 255
x2 = x3 + 15
[x2] = x1
```

This writes `A` to the simulated console.

## Tests

Run the complete regression suite:

```bash
make test
```

The suite checks the original scalar/vector programs, MMU page-boundary behavior, single-CPU context switching, and MMIO behavior.

To check the four-CPU extension separately:

```bash
make MP=1
./executable tests/lab4_multiprocess/program1.txt tests/lab4_multiprocess/data1.byte
```

## Generated files

- `executable` - final simulator
- `process.log` - scheduler, context-switch and Print diagnostics
- `program.byte` - compiler output when a `.txt` program is submitted

## Architecture idea

```text
source program
     |
     v
  compiler
     |
     v
 program.byte -----> OS loader -----> process table
                         |                  |
                         |                  +--> saved CPUContext
                         v
                  physical page tables
                         |
                         v
                 physical RAM frames
                         ^
                         |
                  TLB -> cache -> RAM
                         |
                         v
                    processor
             IF -> ID -> EX -> MEM -> WB
                         |
                         v
                 MMIO / shared memory
```
