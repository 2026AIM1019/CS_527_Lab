#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>

/*
 * The default build models ONE physical processor.  The same source can
 * be compiled with -DNP=4 ("make MP=1") to enable the multiprocessor
 * extension requested by the task.
 */
#ifndef NP
#define NP 1
#endif

#define MAX_PROC NP
#define MAX_PROCESSES 128

/* Physical memory and the logical address spaces used by a task. */
#define MEMSIZE 8192
#define PAGESIZE 512
#define INSTRUCTION_LOGICAL_SIZE 1024
#define DATA_LOGICAL_SIZE 4096
#define NUM_LOGICAL_PAGES (INSTRUCTION_LOGICAL_SIZE / PAGESIZE + DATA_LOGICAL_SIZE / PAGESIZE)
#define NUM_PHYSICAL_PAGES (MEMSIZE / PAGESIZE)

/*
 * A small part of physical memory is reserved for page tables.  We store
 * the complete OS page-table array inside physical memory instead of in a
 * C array.  Ten bytes describe one task: 2 instruction pages + 8 data
 * pages.  128 tasks therefore need 1280 bytes = three physical frames.
 */
#define PAGE_TABLE_BYTES (MAX_PROCESSES * NUM_LOGICAL_PAGES)
#define PAGE_TABLE_FRAMES ((PAGE_TABLE_BYTES + PAGESIZE - 1) / PAGESIZE)
#define PAGE_TABLE_BASE_FRAME 1
#define FIRST_ALLOCATABLE_FRAME (PAGE_TABLE_BASE_FRAME + PAGE_TABLE_FRAMES)

/* A few logical addresses are reserved for memory-mapped I/O. */
#define MMIO_BASE 0x0F00
#define MMIO_END  0x0FFF
#define MMIO_CONSOLE 0x0F00
#define MMIO_STATUS  0x0F04
#define MMIO_TIMER   0x0F08
#define MMIO_PID     0x0F0C

/* Page permission bits. */
#define PERM_READ  0x01
#define PERM_WRITE 0x02
#define PERM_EXEC   0x04
#define PERM_SHARED 0x08

extern unsigned char memory[MEMSIZE];
extern unsigned char freePages[NUM_PHYSICAL_PAGES];

void memory_system_init(void);

/* MMU translation.  access_type is PERM_READ/PERM_WRITE/PERM_EXEC. */
int getPhysicalAddress(int proc_id, int isFetch, int address, int access_type);
int getPhysicallAddress(int proc_id, int isFetch, int address); /* Lab-5 compatible wrapper. */

int getFreePage(void);
void releaseProcessPages(int proc_id);

int initialize(int proc_id, const char *program_file, const char *data_file);
int initialize_minimal(int proc_id, const char *program_file, const char *data_file);
int finalize(int proc_id, const char *data_file);

int32_t read_memory_32(int proc_id, int address);
void write_memory_32(int proc_id, int address, int32_t value);

/* Shared-memory support.  A logical page can be attached to another PID. */
int share_memory_page(int owner_pid, int target_pid, int logical_data_page);
int map_shared_page(int proc_id, int logical_page, int frame, unsigned char permissions);
int set_page_permissions(int proc_id, int logical_page, unsigned char permissions);
int mark_page_shared(int proc_id, int logical_data_page);

/* Debugging/utility interfaces used by the OS shell. */
void print_memory_map(int proc_id);
void print_physical_memory_usage(void);
int get_page_table_entry(int proc_id, int logical_page, unsigned char *permissions);

#endif
