#!/usr/bin/env python3
"""Regression tests for the original Lab-5 behavior and new extensions."""
import subprocess, struct, tempfile, shutil, os
from pathlib import Path

ROOT=Path(__file__).resolve().parent
EXE=ROOT/'executable'
TESTS=['test_01','test_02','test_03','test_04','test_05','vector_array_add','vector_fir']

def bytes_of(p): return bytes(int(x,16)&255 for x in p.read_text().split())
def i32(b,a): return struct.unpack_from('<i',b,a)[0]
def run(cmd,inp=b'',timeout=20):
    return subprocess.run(cmd,cwd=ROOT,input=inp,text=False,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
def build():
    r=run(['make','clean']);
    if r.returncode: print(r.stdout.decode()); return False
    r=run(['make']);
    if r.returncode: print(r.stdout.decode()); return False
    print('[PASS] Build'); return True

def check_bytecode(d):
    return (d/'program.byte').exists() and (d/'expected_program.byte').exists() and (d/'program.byte').read_bytes()==(d/'expected_program.byte').read_bytes()

def check_result(name,d):
    b=bytes_of(d/'data.byte')
    if name.startswith('test_'):
        ex={'test_01':[(16,55)],'test_02':[(16,70),(20,85)],'test_03':[(36,37)],'test_04':[(24,150)],'test_05':[(16,10),(20,40),(24,80)]}[name]
        return all(i32(b,a)==v for a,v in ex)
    n=i32(b,0)
    if name=='vector_array_add':
        if n<=0 or n%8:return False
        A,B,C=4,4+4*n,4+8*n
        return all(i32(b,C+4*i)==i32(b,A+4*i)+i32(b,B+4*i) for i in range(n))
    weights=[i32(b,4+4*i) for i in range(8)]; inp=[i32(b,36+4*i) for i in range(n)]
    return all(i32(b,0x100+4*k)==sum(inp[k+i]*weights[i] for i in range(8)) for k in range(max(0,n-8)))

def regression():
    passed=0
    for name in TESTS:
        d=ROOT/'tests'/name; data=d/'data.byte'; original=data.read_bytes()
        try:
            r=run([str(EXE),str(d/'program.txt'),str(data)],b'exit\n')
            ok=r.returncode==0 and check_bytecode(d) and check_result(name,d)
            print('[PASS] '+name if ok else '[FAIL] '+name)
            if not ok: print(r.stdout.decode()[-2500:])
            passed+=ok
        finally: data.write_bytes(original)
    return passed

def print_test():
    d=ROOT/'tests'/'lab4_print'; data=d/'data.byte'; original=data.read_bytes(); log=ROOT/'process.log'
    if log.exists():log.unlink()
    try:
        r=run([str(EXE),str(d/'program.txt'),str(data)],b'exit\n'); text=log.read_text() if log.exists() else ''
        ok=r.returncode==0 and 'x1 : 0000002A' in text and 'x2 : 000000FF' in text
        print('[PASS] print' if ok else '[FAIL] print'); return ok
    finally:data.write_bytes(original)

def context_switch_test():
    # test_02 is 13 instructions while the default slice is 10.  Successful
    # completion proves PC/register state survives a preemption and restore.
    d=ROOT/'tests'/'test_02'; data=d/'data.byte'; original=data.read_bytes(); log=ROOT/'process.log'
    if log.exists():log.unlink()
    try:
        r=run([str(EXE),str(d/'program.txt'),str(data)],b'exit\n'); text=log.read_text() if log.exists() else ''
        b=bytes_of(data)
        ok=r.returncode==0 and i32(b,16)==70 and i32(b,20)==85 and '[CONTEXT SWITCH]' in text
        print('[PASS] single_cpu_context_switch' if ok else '[FAIL] single_cpu_context_switch'); return ok
    finally:data.write_bytes(original)

def mmio_test():
    d=ROOT/'tests'/'mmio_demo'; data=d/'data.byte'; original=data.read_bytes()
    try:
        r=run([str(EXE),str(d/'program.txt'),str(data)],b'exit\n')
        ok=r.returncode==0 and b'A' in r.stdout
        print('[PASS] mmio' if ok else '[FAIL] mmio'); return ok
    finally:data.write_bytes(original)

def virtual_test():
    d=ROOT/'tests'/'virtual_registers'; data=d/'data.byte'; original=data.read_bytes(); log=ROOT/'process.log'
    try:
        r=run([str(EXE),str(d/'program.txt'),str(data)],b'exit\n'); text=log.read_text() if log.exists() else ''
        ok=r.returncode==0 and 'x2 : 0000001E' in text
        print('[PASS] virtual_registers' if ok else '[FAIL] virtual_registers'); return ok
    finally:data.write_bytes(original)

def ipc_test():
    d=ROOT/'tests'/'ipc_demo'; d1=d/'data1.byte'; d2=d/'data2.byte'
    originals=(d1.read_bytes(),d2.read_bytes()); log=ROOT/'process.log'
    if log.exists():log.unlink()
    try:
        commands=(f'run {d/"program1.txt"} {d1}\n'
                  f'run {d/"program2.txt"} {d2}\n'
                  'share 1 2 0\nexit\n').encode()
        r=run([str(EXE)],commands)
        text=log.read_text() if log.exists() else ''
        ok=r.returncode==0 and 'shared data page 0: PID 1 -> PID 2' in r.stdout.decode() and 'x1 : 0000006F' in text
        print('[PASS] shared_memory_ipc' if ok else '[FAIL] shared_memory_ipc'); return ok
    finally:
        d1.write_bytes(originals[0]); d2.write_bytes(originals[1])


def mp_extension_test():
    r=run(['make','clean']);
    if r.returncode:return False
    r=run(['make','MP=1'])
    if r.returncode:
        print(r.stdout.decode()); return False
    d=ROOT/'tests'/'test_01'; data=d/'data.byte'; original=data.read_bytes()
    try:
        r=run([str(EXE),str(d/'program.txt'),str(data)],b'exit\n')
        ok=r.returncode==0 and i32(bytes_of(data),16)==55
        print('[PASS] multiprocessor_build' if ok else '[FAIL] multiprocessor_build'); return ok
    finally:data.write_bytes(original)

def main():
    if not build():return 1
    passed=regression()+print_test()+context_switch_test()+mmio_test()+virtual_test()+ipc_test()
    # Rebuild in MP mode only after all default tests, then restore default so
    # the final repository executable is the normal single-CPU one.
    passed+=mp_extension_test()
    run(['make','clean']); run(['make'])
    total=len(TESTS)+6
    print(f'\n{passed}/{total} tests passed')
    return 0 if passed==total else 1

if __name__=='__main__':raise SystemExit(main())
