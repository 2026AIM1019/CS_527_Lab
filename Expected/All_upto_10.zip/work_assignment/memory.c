#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "memory.h"

/*
 * Physical memory is the ONLY byte array used as RAM.
 *
 * Important design decision:
 *   pageTable[] is deliberately NOT a C array anymore.
 *   The OS stores every page-table entry inside reserved physical frames.
 *   This makes page-table lookup itself a memory operation in the simulated
 *   machine, which is exactly what this extension asks us to demonstrate.
 */
unsigned char memory[MEMSIZE];
unsigned char freePages[NUM_PHYSICAL_PAGES];

static unsigned char frame_refs[NUM_PHYSICAL_PAGES];

static size_t pt_offset(int task_slot, int logical_page)
{
    return (size_t)task_slot * NUM_LOGICAL_PAGES + logical_page;
}

static unsigned char encode_pte(int frame, unsigned char permissions)
{
    /* Four low bits are enough for the 16 physical frames. */
    return (unsigned char)((frame & 0x0F) | ((permissions & 0x0F) << 4));
}

static int pte_frame(unsigned char pte) { return pte & 0x0F; }
static unsigned char pte_perms(unsigned char pte) { return (pte >> 4) & 0x0F; }

static unsigned char *page_table_byte(int task_slot, int logical_page)
{
    size_t off = pt_offset(task_slot, logical_page);
    if (task_slot < 0 || task_slot >= MAX_PROCESSES ||
        logical_page < 0 || logical_page >= NUM_LOGICAL_PAGES ||
        off >= PAGE_TABLE_BYTES) return NULL;
    return &memory[PAGE_TABLE_BASE_FRAME * PAGESIZE + off];
}

int get_page_table_entry(int proc_id, int logical_page, unsigned char *permissions)
{
    unsigned char *entry = page_table_byte(proc_id, logical_page);
    if (!entry) return 0;
    if (permissions) *permissions = pte_perms(*entry);
    return pte_frame(*entry);
}

static int set_page_table_entry(int proc_id, int logical_page, int frame, unsigned char permissions)
{
    unsigned char *entry = page_table_byte(proc_id, logical_page);
    if (!entry || frame < 0 || frame >= NUM_PHYSICAL_PAGES) return -1;
    *entry = encode_pte(frame, permissions);
    return 0;
}

void memory_system_init(void)
{
    memset(memory, 0, sizeof(memory));
    memset(freePages, 0, sizeof(freePages));
    memset(frame_refs, 0, sizeof(frame_refs));

    /* Frames containing the page-table array are permanently reserved. */
    freePages[0] = 1;
    for (int f = PAGE_TABLE_BASE_FRAME;
         f < FIRST_ALLOCATABLE_FRAME && f < NUM_PHYSICAL_PAGES; ++f)
        freePages[f] = 1;

    /* A zero PTE means "not mapped". */
    memset(memory + PAGE_TABLE_BASE_FRAME * PAGESIZE, 0, PAGE_TABLE_FRAMES * PAGESIZE);
}

int getPhysicalAddress(int proc_id, int isFetch, int address, int access_type)
{
    int logical_page;
    int frame;
    unsigned char permissions;

    if (proc_id < 0 || proc_id >= MAX_PROCESSES || address < 0) {
        fprintf(stderr, "MMU ERROR: invalid task/address (%d, %d)\n", proc_id, address);
        return -1;
    }

    if (isFetch) {
        if (address >= INSTRUCTION_LOGICAL_SIZE) {
            fprintf(stderr, "MMU ERROR: instruction address %d out of range\n", address);
            return -1;
        }
        logical_page = address / PAGESIZE;
    } else {
        if (address >= DATA_LOGICAL_SIZE) {
            /* MMIO lives in a reserved part of the logical data address space. */
            if (address < MMIO_BASE || address > MMIO_END) {
                fprintf(stderr, "MMU ERROR: data address %d out of range\n", address);
                return -1;
            }
            return -2; /* special MMIO address, not ordinary RAM */
        }
        logical_page = INSTRUCTION_LOGICAL_SIZE / PAGESIZE + address / PAGESIZE;
    }

    frame = get_page_table_entry(proc_id, logical_page, &permissions);
    if (frame <= 0 || frame >= NUM_PHYSICAL_PAGES) {
        fprintf(stderr, "MMU ERROR: task %d logical page %d is not mapped\n",
                proc_id, logical_page);
        return -1;
    }

    if ((permissions & access_type) != access_type) {
        fprintf(stderr, "SECURITY FAULT: task %d page %d lacks permission 0x%02X\n",
                proc_id, logical_page, access_type);
        return -1;
    }

    return frame * PAGESIZE + (address % PAGESIZE);
}

int getPhysicallAddress(int proc_id, int isFetch, int address)
{
    return getPhysicalAddress(proc_id, isFetch, address,
                              isFetch ? PERM_EXEC : PERM_READ);
}

int getFreePage(void)
{
    for (int f = FIRST_ALLOCATABLE_FRAME; f < NUM_PHYSICAL_PAGES; ++f) {
        if (!freePages[f]) {
            freePages[f] = 1;
            frame_refs[f] = 1;
            memset(memory + f * PAGESIZE, 0, PAGESIZE);
            return f;
        }
    }
    fprintf(stderr, "ERROR: No free physical frame available\n");
    return -1;
}

void releaseProcessPages(int proc_id)
{
    if (proc_id < 0 || proc_id >= MAX_PROCESSES) return;

    for (int lp = 0; lp < NUM_LOGICAL_PAGES; ++lp) {
        unsigned char *entry = page_table_byte(proc_id, lp);
        if (!entry) continue;
        int frame = pte_frame(*entry);
        if (frame >= FIRST_ALLOCATABLE_FRAME && frame < NUM_PHYSICAL_PAGES) {
            if (frame_refs[frame] > 0) --frame_refs[frame];
            if (frame_refs[frame] == 0) freePages[frame] = 0;
        }
        *entry = 0;
    }
}

static int allocate_and_map(int task_slot, int logical_page, unsigned char perms)
{
    int frame = getFreePage();
    if (frame < 0) return -1;
    if (set_page_table_entry(task_slot, logical_page, frame, perms) != 0) {
        freePages[frame] = 0;
        return -1;
    }
    return frame;
}

static int load_region(int task_slot, const char *file_name, int isFetch, int max_bytes)
{
    FILE *fp = fopen(file_name, "r");
    int value;
    int logical_offset = 0;
    int base_page = isFetch ? 0 : INSTRUCTION_LOGICAL_SIZE / PAGESIZE;

    if (!fp) {
        fprintf(stderr, "OS: cannot open %s\n", file_name);
        return -1;
    }

    while (logical_offset < max_bytes && fscanf(fp, "%x", &value) == 1) {
        int page = base_page + logical_offset / PAGESIZE;
        unsigned char perms = isFetch ? (PERM_READ | PERM_EXEC)
                                      : (PERM_READ | PERM_WRITE);
        unsigned char *entry = page_table_byte(task_slot, page);
        int frame;

        if (!entry) { fclose(fp); return -1; }
        frame = pte_frame(*entry);
        if (frame == 0) {
            frame = allocate_and_map(task_slot, page, perms);
            if (frame < 0) { fclose(fp); return -2; }
        }

        memory[frame * PAGESIZE + logical_offset % PAGESIZE] = (unsigned char)value;
        ++logical_offset;
    }

    fclose(fp);
    return logical_offset;
}

int initialize(int proc_id, const char *program_file, const char *data_file)
{
    int rc;
    if (proc_id < 0 || proc_id >= MAX_PROCESSES) return -1;

    releaseProcessPages(proc_id);
    rc = load_region(proc_id, program_file, 1, INSTRUCTION_LOGICAL_SIZE);
    if (rc < 0) { releaseProcessPages(proc_id); return rc; }
    rc = load_region(proc_id, data_file, 0, DATA_LOGICAL_SIZE);
    if (rc < 0) { releaseProcessPages(proc_id); return rc; }
    return 0;
}

/*
 * IPC helper: materialise the instruction pages and only data page zero.
 * The remaining data pages are left zero/unmapped.  This lets a process be
 * prepared as a shared-memory participant even when physical RAM is nearly
 * full; its shared page can then replace the small private page.
 */
int initialize_minimal(int proc_id, const char *program_file, const char *data_file)
{
    int rc;
    if (proc_id < 0 || proc_id >= MAX_PROCESSES) return -1;
    releaseProcessPages(proc_id);
    rc = load_region(proc_id, program_file, 1, INSTRUCTION_LOGICAL_SIZE);
    if (rc < 0) { releaseProcessPages(proc_id); return rc; }
    rc = load_region(proc_id, data_file, 0, PAGESIZE);
    if (rc < 0) { releaseProcessPages(proc_id); return rc; }
    return 0;
}

static int mmio_read(int address, int32_t *value)
{
    if (address == MMIO_STATUS) { *value = 1; return 1; }
    if (address == MMIO_TIMER) { *value = (int32_t)time(NULL); return 1; }
    if (address == MMIO_PID) { *value = 0; return 1; }
    if (address == MMIO_CONSOLE) { *value = 0; return 1; }
    return address >= MMIO_BASE && address <= MMIO_END;
}

static int mmio_write(int address, int32_t value)
{
    if (address == MMIO_CONSOLE) {
        fputc((unsigned char)value, stdout);
        fflush(stdout);
        return 1;
    }
    /* Other MMIO registers are deliberately write-ignored/read-only. */
    return address >= MMIO_BASE && address <= MMIO_END;
}

int finalize(int proc_id, const char *data_file)
{
    FILE *fp = fopen(data_file, "w");
    if (!fp) {
        fprintf(stderr, "OS: cannot write data %s\n", data_file);
        return -1;
    }

    for (int logical = 0; logical < DATA_LOGICAL_SIZE; ++logical) {
        int page = INSTRUCTION_LOGICAL_SIZE / PAGESIZE + logical / PAGESIZE;
        unsigned char *entry = page_table_byte(proc_id, page);
        unsigned char value = 0;
        if (entry && pte_frame(*entry) != 0) {
            int frame = pte_frame(*entry);
            value = memory[frame * PAGESIZE + logical % PAGESIZE];
        }
        fprintf(fp, "%02X%s", value, logical % 4 == 3 ? "\n" : " ");
    }
    fclose(fp);
    releaseProcessPages(proc_id);
    return 0;
}

int32_t read_memory_32(int proc_id, int address)
{
    int32_t mmio_value = 0;
    uint32_t v = 0;

    if (address >= MMIO_BASE && address <= MMIO_END && mmio_read(address, &mmio_value))
        return mmio_value;

    for (int i = 0; i < 4; ++i) {
        int p = getPhysicalAddress(proc_id, 0, address + i, PERM_READ);
        if (p < 0) return 0;
        v |= (uint32_t)memory[p] << (8 * i);
    }
    return (int32_t)v;
}

void write_memory_32(int proc_id, int address, int32_t value)
{
    if (address >= MMIO_BASE && address <= MMIO_END) {
        mmio_write(address, value);
        return;
    }

    uint32_t v = (uint32_t)value;
    for (int i = 0; i < 4; ++i) {
        int p = getPhysicalAddress(proc_id, 0, address + i, PERM_WRITE);
        if (p < 0) return;
        memory[p] = (unsigned char)(v >> (8 * i));
    }
}

int set_page_permissions(int proc_id, int logical_page, unsigned char permissions)
{
    unsigned char *entry = page_table_byte(proc_id, logical_page);
    if (!entry || pte_frame(*entry) == 0) return -1;
    *entry = encode_pte(pte_frame(*entry), permissions);
    return 0;
}

int mark_page_shared(int proc_id, int logical_data_page)
{
    int lp = INSTRUCTION_LOGICAL_SIZE / PAGESIZE + logical_data_page;
    unsigned char perms = 0;
    int frame = get_page_table_entry(proc_id, lp, &perms);
    if (frame <= 0) return -1;
    return set_page_permissions(proc_id, lp, perms | PERM_SHARED);
}

int map_shared_page(int proc_id, int logical_page, int frame, unsigned char permissions)
{
    if (proc_id < 0 || proc_id >= MAX_PROCESSES ||
        logical_page < INSTRUCTION_LOGICAL_SIZE / PAGESIZE ||
        logical_page >= NUM_LOGICAL_PAGES ||
        frame < FIRST_ALLOCATABLE_FRAME || frame >= NUM_PHYSICAL_PAGES)
        return -1;
    /* If the target already has a mapping, release its old reference first. */
    unsigned char *old = page_table_byte(proc_id, logical_page);
    if (old && pte_frame(*old) >= FIRST_ALLOCATABLE_FRAME) {
        int old_frame = pte_frame(*old);
        if (frame_refs[old_frame] > 0) --frame_refs[old_frame];
        if (frame_refs[old_frame] == 0) freePages[old_frame] = 0;
    }

    /* Shared mappings add a reference instead of allocating a new frame. */
    freePages[frame] = 1;
    ++frame_refs[frame];
    if (set_page_table_entry(proc_id, logical_page, frame,
                             permissions | PERM_SHARED) != 0) {
        if (frame_refs[frame] > 0) --frame_refs[frame];
        if (frame_refs[frame] == 0) freePages[frame] = 0;
        return -1;
    }
    return 0;
}

int share_memory_page(int owner_pid, int target_pid, int logical_data_page)
{
    int lp = INSTRUCTION_LOGICAL_SIZE / PAGESIZE + logical_data_page;
    unsigned char perms;
    int frame = get_page_table_entry(owner_pid, lp, &perms);
    /* A process must explicitly mark the page SHARED before another process
     * can attach to it.  This is the security boundary for IPC setup. */
    if (frame <= 0 || !(perms & PERM_SHARED)) return -1;
    return map_shared_page(target_pid, lp, frame, perms | PERM_READ | PERM_WRITE);
}

void print_memory_map(int proc_id)
{
    printf("Memory map for task slot %d:\n", proc_id);
    for (int lp = 0; lp < NUM_LOGICAL_PAGES; ++lp) {
        unsigned char perms = 0;
        int frame = get_page_table_entry(proc_id, lp, &perms);
        if (frame > 0)
            printf("  logical page %2d -> frame %2d  perms=%c%c%c%s\n",
                   lp, frame,
                   perms & PERM_READ ? 'R' : '-',
                   perms & PERM_WRITE ? 'W' : '-',
                   perms & PERM_EXEC ? 'X' : '-',
                   perms & PERM_SHARED ? " SHARED" : "");
    }
}

void print_physical_memory_usage(void)
{
    printf("Physical frames (frame 0 + %d page-table frames reserved):\n",
           PAGE_TABLE_FRAMES);
    for (int f = 0; f < NUM_PHYSICAL_PAGES; ++f)
        printf("  frame %2d: %s%s\n", f,
               freePages[f] ? "USED" : "FREE",
               (f == 0) ? " (reserved)" :
               (f >= PAGE_TABLE_BASE_FRAME && f < FIRST_ALLOCATABLE_FRAME) ? " (page table)" : "");
}
