#include <stdio.h>
#include <string.h>
#include "os.h"

/*
 * The executable is intentionally small: all real work belongs to the
 * compiler and OS modules.  Command-line pairs are optional; without them
 * the interactive non-blocking shell is used.
 */
int main(int argc, char **argv)
{
    if (argc > 1 && ((argc - 1) % 2 != 0)) {
        fprintf(stderr, "Usage: %s [program.txt data.byte] ...\n", argv[0]);
        return 1;
    }

    os_init();
    for (int i=1;i<argc;i+=2)
        if (loader(argv[i],argv[i+1])<0) return 1;

    scheduler();
    return 0;
}
