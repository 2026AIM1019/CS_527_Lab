#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <stdint.h>
#include <stdio.h>
#include "memory.h"

#define INTEGER_REGISTERS 256
#define VECTOR_REGISTERS 32
#define VECTOR_LANES 8
#define PIPELINE_STAGES 5

/* A complete architectural context.  The OS saves/restores this structure
 * whenever the single CPU changes from one task to another. */
typedef struct {
    int32_t reg[INTEGER_REGISTERS];
    int32_t vreg[VECTOR_REGISTERS][VECTOR_LANES];
    int pc;
    int z, n, c, v;
    int pid;
    int halted;
} CPUContext;

typedef struct {
    unsigned long instructions;
    unsigned long cycles;
    unsigned long cache_hits;
    unsigned long cache_misses;
    unsigned long tlb_hits;
    unsigned long tlb_misses;
    unsigned long pipeline_stalls;
    unsigned long pipeline_flushes;
    unsigned long context_switches;
    unsigned long memory_reads;
    unsigned long memory_writes;
} ProcessorStats;

extern CPUContext cpu;
extern ProcessorStats cpu_stats;
extern int opcode, dest, src1, src2;
extern int proc_id;
extern FILE *fd_log;

void reset(int id);
void load_context(int id, int task_slot, const CPUContext *ctx);
void save_context(int id, CPUContext *ctx);
void fetch(int id);
void decode(void);
void execute(int id);
void process_instructions(int id, int instruction_count);
void set_processor_pid(int id, int pid);

void processor_print_stats(void);
void processor_print_cache_tlb(void);
void processor_flush_cache_tlb(void);

#endif
