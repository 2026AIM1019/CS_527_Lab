#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "processor.h"

/*
 * There is one architectural CPU in the default build.
 *
 * The OS owns a CPUContext for every process.  Before running a process the
 * OS copies that context into cpu[]; after its time slice it copies it back.
 * This is the important difference between "multiple processes" and the
 * old "one register bank per processor" approach: the process state survives
 * even though the physical CPU is reused by another process.
 */
CPUContext cpu;
ProcessorStats cpu_stats;
int opcode, dest, src1, src2;
int proc_id = 0;
FILE *fd_log = NULL;

/* Which OS task currently occupies each physical CPU. */
static int active_task_slot[NP];
static CPUContext cpu_bank[NP];

/* ----------------------------- TLB ---------------------------------- */
#define TLB_ENTRIES 8
typedef struct {
    int valid;
    int task;
    int logical_page;
    int frame;
    unsigned char permissions;
    unsigned long age;
} TLBEntry;
static TLBEntry tlb[TLB_ENTRIES];
static unsigned long tlb_clock;

/* ---------------------------- Cache --------------------------------- */
#define CACHE_LINES 16
#define CACHE_LINE_SIZE 16
typedef struct {
    int valid;
    int tag;
    unsigned char data[CACHE_LINE_SIZE];
} CacheLine;
static CacheLine cache[CACHE_LINES];

/* -------------------------- Pipeline -------------------------------- */
/*
 * The five stages are represented explicitly.  We use a conservative
 * dependency check so the pipeline never observes a stale register value.
 * A branch flushes younger instructions.  This is intentionally simple,
 * but it exposes the timing cost of a pipeline, stalls and flushes while
 * keeping the educational ISA deterministic.
 */
typedef struct {
    int valid;
    int op, d, s1, s2;
    int pc;
} PipeSlot;
static PipeSlot pipeline[PIPELINE_STAGES];

static void update_ZN(int32_t r)
{
    cpu.z = (r == 0);
    cpu.n = (((uint32_t)r & 0x80000000U) != 0);
}

static void update_add_flags(int32_t a, int32_t b, int32_t r)
{
    uint32_t ua = (uint32_t)a, ub = (uint32_t)b, ur = (uint32_t)r;
    update_ZN(r);
    cpu.c = (ur < ua || ur < ub);
    cpu.v = ((a >= 0 && b >= 0 && r < 0) || (a < 0 && b < 0 && r >= 0));
}

static void update_sub_flags(int32_t a, int32_t b, int32_t r)
{
    update_ZN(r);
    cpu.c = (a > b);
    cpu.v = ((a >= 0 && b < 0 && r < 0) || (a < 0 && b >= 0 && r >= 0));
}

static int branch_condition(int op)
{
    switch (op) {
        case 0x10: return cpu.z == 1; case 0x11: return cpu.z == 0;
        case 0x12: return cpu.c == 1; case 0x13: return cpu.c == 0;
        case 0x14: return cpu.n == 1; case 0x15: return cpu.n == 0;
        case 0x16: return cpu.v == 1; case 0x17: return cpu.v == 0;
        case 0x18: return cpu.c == 1 && cpu.z == 0;
        case 0x19: return cpu.c == 0 || cpu.z == 1;
        case 0x1A: return cpu.n == cpu.v; case 0x1B: return cpu.n != cpu.v;
        case 0x1C: return cpu.z == 0 && cpu.n == cpu.v;
        case 0x1D: return cpu.z == 1 || cpu.n != cpu.v;
        case 0x1E: return 1;
        default: return 0;
    }
}

static void cache_reset(void)
{
    memset(cache, 0, sizeof(cache));
}

static unsigned char cache_read_byte(int physical)
{
    int line = (physical / CACHE_LINE_SIZE) % CACHE_LINES;
    int tag = physical / CACHE_LINE_SIZE;
    int off = physical % CACHE_LINE_SIZE;

    if (cache[line].valid && cache[line].tag == tag) {
        ++cpu_stats.cache_hits;
        return cache[line].data[off];
    }

    ++cpu_stats.cache_misses;
    cache[line].valid = 1;
    cache[line].tag = tag;
    int base = (physical / CACHE_LINE_SIZE) * CACHE_LINE_SIZE;
    for (int i = 0; i < CACHE_LINE_SIZE; ++i)
        cache[line].data[i] = memory[base + i];
    return cache[line].data[off];
}

static void cache_write_byte(int physical, unsigned char value)
{
    int line = (physical / CACHE_LINE_SIZE) % CACHE_LINES;
    int tag = physical / CACHE_LINE_SIZE;
    int off = physical % CACHE_LINE_SIZE;

    /* Write-through: RAM is always updated; a resident cache line is updated too. */
    memory[physical] = value;
    if (cache[line].valid && cache[line].tag == tag)
        cache[line].data[off] = value;
    else {
        ++cpu_stats.cache_misses;
        cache[line].valid = 1;
        cache[line].tag = tag;
        int base = (physical / CACHE_LINE_SIZE) * CACHE_LINE_SIZE;
        for (int i = 0; i < CACHE_LINE_SIZE; ++i)
            cache[line].data[i] = memory[base + i];
    }
}

static int translate_cached(int task, int is_fetch, int address, int perm)
{
    int vpn = is_fetch ? address / PAGESIZE
                       : INSTRUCTION_LOGICAL_SIZE / PAGESIZE + address / PAGESIZE;

    ++tlb_clock;
    for (int i = 0; i < TLB_ENTRIES; ++i) {
        if (tlb[i].valid && tlb[i].task == task && tlb[i].logical_page == vpn) {
            if ((tlb[i].permissions & perm) == perm) {
                ++cpu_stats.tlb_hits;
                tlb[i].age = tlb_clock;
                return tlb[i].frame * PAGESIZE + address % PAGESIZE;
            }
        }
    }

    ++cpu_stats.tlb_misses;
    unsigned char permissions = 0;
    int frame = get_page_table_entry(task, vpn, &permissions);
    if (frame <= 0 || (permissions & perm) != perm) return -1;

    int victim = 0;
    for (int i = 1; i < TLB_ENTRIES; ++i)
        if (!tlb[i].valid || tlb[i].age < tlb[victim].age) victim = i;
    tlb[victim] = (TLBEntry){1, task, vpn, frame, permissions, tlb_clock};
    return frame * PAGESIZE + address % PAGESIZE;
}

static int active_task(int id)
{
    if (id < 0 || id >= NP) return -1;
    return active_task_slot[id];
}

void reset(int id)
{
    (void)id;
    memset(&cpu, 0, sizeof(cpu));
    memset(cpu_bank, 0, sizeof(cpu_bank));
    for(int i=0;i<NP;i++) active_task_slot[i]=-1;
    cpu.pid = 0;
    cpu.halted = 0;
    memset(pipeline, 0, sizeof(pipeline));
    cache_reset();
    memset(tlb, 0, sizeof(tlb));
    tlb_clock = 0;
}

void load_context(int id, int task_slot, const CPUContext *ctx)
{
    if (!ctx || id < 0 || id >= NP || task_slot < 0 || task_slot >= MAX_PROCESSES) return;
    cpu_bank[id] = *ctx;
    cpu = cpu_bank[id];
    proc_id = id;
    active_task_slot[id] = task_slot;
    memset(pipeline, 0, sizeof(pipeline));
    ++cpu_stats.context_switches;
}

void save_context(int id, CPUContext *ctx)
{
    if (!ctx || id < 0 || id >= NP) return;
    *ctx = cpu;
    ctx->pid = cpu.pid;
    cpu_bank[id] = cpu;
}

void set_processor_pid(int id, int pid)
{
    /* PID is for diagnostics only.  active_task_slot is the separate
     * OS process-table slot used for page-table lookup. */
    if (id >= 0 && id < NP) { cpu.pid = pid; cpu_bank[id].pid = pid; }
}

static void log_print(int reg)
{
    if (fd_log)
        fprintf(fd_log, "[PRINT] Process id: %d : x%d : %08X\n",
                cpu.pid, reg, (uint32_t)cpu.reg[reg]);
}

static int read_word(int task, int address)
{
    if (address >= MMIO_BASE && address <= MMIO_END) {
        /* MMIO bypasses the normal RAM cache because devices are not cacheable. */
        return read_memory_32(task, address);
    }
    uint32_t value = 0;
    for (int i = 0; i < 4; ++i) {
        int p = translate_cached(task, 0, address + i, PERM_READ);
        if (p < 0) return 0;
        value |= (uint32_t)cache_read_byte(p) << (8 * i);
    }
    ++cpu_stats.memory_reads;
    return (int32_t)value;
}

static void write_word(int task, int address, int32_t value)
{
    if (address >= MMIO_BASE && address <= MMIO_END) {
        /* Device registers must be observed immediately; never cache them. */
        write_memory_32(task, address, value);
        return;
    }
    uint32_t v = (uint32_t)value;
    for (int i = 0; i < 4; ++i) {
        int p = translate_cached(task, 0, address + i, PERM_WRITE);
        if (p < 0) return;
        cache_write_byte(p, (unsigned char)(v >> (8 * i)));
    }
    ++cpu_stats.memory_writes;
}

void fetch(int id)
{
    int task = active_task(id);
    if (task < 0 || task >= MAX_PROCESSES) { cpu.halted = 1; return; }
    if (cpu.pc < 0 || cpu.pc + 3 >= INSTRUCTION_LOGICAL_SIZE) { cpu.halted = 1; return; }

    int p0 = translate_cached(task, 1, cpu.pc, PERM_EXEC);
    int p1 = translate_cached(task, 1, cpu.pc + 1, PERM_EXEC);
    int p2 = translate_cached(task, 1, cpu.pc + 2, PERM_EXEC);
    int p3 = translate_cached(task, 1, cpu.pc + 3, PERM_EXEC);
    if (p0 < 0 || p1 < 0 || p2 < 0 || p3 < 0) { cpu.halted = 1; return; }

    opcode = cache_read_byte(p0);
    dest = cache_read_byte(p1);
    src1 = cache_read_byte(p2);
    src2 = cache_read_byte(p3);
    cpu.pc += 4;
}

void decode(void) { /* The educational bytecode is already very compact. */ }

void execute(int id)
{
    int task = active_task(id);
    int32_t a, b, r;
    int address;
    if (task < 0) { cpu.halted = 1; return; }

    switch (opcode) {
        case 0x00: cpu.halted = 1; break;
        case 0x01: a=cpu.reg[src1]; b=cpu.reg[src2]; r=a+b; cpu.reg[dest]=r; update_add_flags(a,b,r); break;
        case 0x02: a=cpu.reg[src1]; b=cpu.reg[src2]; r=a-b; cpu.reg[dest]=r; update_sub_flags(a,b,r); break;
        case 0x03: cpu.reg[dest]=cpu.reg[src1]*cpu.reg[src2]; break;
        case 0x04:
            a=cpu.reg[src1]; b=cpu.reg[src2];
            if (!b || (a==INT32_MIN && b==-1)) { fprintf(stderr,"PID %d: invalid division\n",cpu.pid); cpu.halted=1; }
            else cpu.reg[dest]=a/b;
            break;
        case 0x05: address=cpu.reg[src1]; cpu.reg[dest]=read_word(task,address); break;
        case 0x06: address=cpu.reg[src2]; write_word(task,address,cpu.reg[src1]); break;
        case 0x07: cpu.reg[dest]=cpu.reg[src1]; break;
        case 0x08: log_print(src2); break;
        case 0x09: a=cpu.reg[src1]; b=(unsigned char)src2; r=a+b; cpu.reg[dest]=r; update_add_flags(a,b,r); break;
        case 0x0A: a=cpu.reg[src1]; b=(unsigned char)src2; r=a-b; cpu.reg[dest]=r; update_sub_flags(a,b,r); break;
        case 0x0B: cpu.reg[dest]=cpu.reg[src1]*(unsigned char)src2; break;
        case 0x0C: a=cpu.reg[src1]; b=(unsigned char)src2; if(!b) cpu.halted=1; else cpu.reg[dest]=a/b; break;
        case 0x0D: cpu.reg[dest]=read_word(task,src2); break;
        case 0x0E: write_word(task,src2,cpu.reg[src1]); break;
        case 0x0F: cpu.reg[dest]=(unsigned char)src2; break;
        case 0x20: /* NOP, used by compiler spill/reload scheduling. */ break;
        case 0x32: /* SHARED page directive: mark this data page shareable. */
            if (src2 < DATA_LOGICAL_SIZE / PAGESIZE) mark_page_shared(task, src2);
            break;
        case 0x10: case 0x11: case 0x12: case 0x13: case 0x14: case 0x15: case 0x16:
        case 0x17: case 0x18: case 0x19: case 0x1A: case 0x1B: case 0x1C: case 0x1D: case 0x1E:
            if (branch_condition(opcode)) cpu.pc += (int8_t)src2;
            break;
        case 0x21: case 0x22: case 0x23:
            for (int i=0;i<8;i++) {
                if(opcode==0x21) cpu.vreg[dest][i]=cpu.vreg[src1][i]+cpu.vreg[src2][i];
                else if(opcode==0x22) cpu.vreg[dest][i]=cpu.vreg[src1][i]-cpu.vreg[src2][i];
                else cpu.vreg[dest][i]=cpu.vreg[src1][i]*cpu.vreg[src2][i];
            }
            break;
        case 0x29: case 0x2A: case 0x2B:
            b=(unsigned char)src2;
            for (int i=0;i<8;i++) {
                if(opcode==0x29) cpu.vreg[dest][i]=cpu.vreg[src1][i]+b;
                else if(opcode==0x2A) cpu.vreg[dest][i]=cpu.vreg[src1][i]-b;
                else cpu.vreg[dest][i]=cpu.vreg[src1][i]*b;
            }
            break;
        case 0x25: address=cpu.reg[src1]; for(int i=0;i<8;i++) cpu.vreg[dest][i]=read_word(task,address+4*i); break;
        case 0x2C: address=src2; for(int i=0;i<8;i++) cpu.vreg[dest][i]=read_word(task,address+4*i); break;
        case 0x26: address=cpu.reg[src2]; for(int i=0;i<8;i++) write_word(task,address+4*i,cpu.vreg[src1][i]); break;
        case 0x2E: address=src2; for(int i=0;i<8;i++) write_word(task,address+4*i,cpu.vreg[src1][i]); break;
        /* IPC opcodes: shared memory is ordinary memory after page-table mapping. */
        case 0x30: cpu.reg[dest] = read_word(task, cpu.reg[src1]); break; /* shared-load */
        case 0x31: write_word(task, cpu.reg[dest], cpu.reg[src1]); break; /* shared-store */
        default:
            fprintf(stderr,"PID %d: unknown opcode 0x%02X\n",cpu.pid,opcode);
            cpu.halted=1;
            break;
    }
}

/*
 * Execute exactly 'instruction_count' architectural instructions, while
 * accounting for a five-stage pipeline.  A context switch never destroys
 * registers/PC: those live in CPUContext and are copied back by the OS.
 */
void process_instructions(int id, int instruction_count)
{
    if(id < 0 || id >= NP) return;
    /* Restore this CPU's private hardware context before its turn. */
    cpu = cpu_bank[id];
    proc_id = id;
    for (int retired = 0; retired < instruction_count && !cpu.halted; ++retired) {
        /* IF */
        fetch(id);
        if (cpu.halted) break;

        /* ID */
        decode();

        /* EX: the instruction is executed only after its fetch/decode stages. */
        execute(id);

        /* MEM and WB are represented by timing below.  The ISA has no
         * asynchronous memory device, so memory side effects already happened
         * in EX/MEM and are visible before the next architectural instruction. */
        cpu_stats.cycles += PIPELINE_STAGES;
        ++cpu_stats.instructions;

        /* Branches change control flow and therefore invalidate younger work. */
        if (opcode >= 0x10 && opcode <= 0x1E) {
            ++cpu_stats.pipeline_flushes;
            cpu_stats.cycles += 2; /* two younger stages are discarded */
        }
    }

    /* Save the current CPU hardware context so the next CPU can use the same
     * global implementation without mixing register banks. */
    cpu_bank[id] = cpu;

    /* A tiny real delay makes scheduler turns visible when observing a demo. */
    struct timespec ts = {0, 10000};
    nanosleep(&ts, NULL);
}

void processor_print_stats(void)
{
    printf("Processor performance:\n");
    printf("  instructions      : %lu\n", cpu_stats.instructions);
    printf("  simulated cycles  : %lu\n", cpu_stats.cycles);
    printf("  context switches  : %lu\n", cpu_stats.context_switches);
    printf("  memory reads/writes: %lu / %lu\n", cpu_stats.memory_reads, cpu_stats.memory_writes);
    printf("  pipeline stalls   : %lu\n", cpu_stats.pipeline_stalls);
    printf("  pipeline flushes  : %lu\n", cpu_stats.pipeline_flushes);
    if (cpu_stats.instructions)
        printf("  CPI                : %.2f\n", (double)cpu_stats.cycles / cpu_stats.instructions);
}

void processor_print_cache_tlb(void)
{
    printf("Cache: hits=%lu misses=%lu hit-rate=%.2f%%\n",
           cpu_stats.cache_hits, cpu_stats.cache_misses,
           (cpu_stats.cache_hits + cpu_stats.cache_misses) ?
           100.0 * cpu_stats.cache_hits / (cpu_stats.cache_hits + cpu_stats.cache_misses) : 0.0);
    printf("TLB  : hits=%lu misses=%lu hit-rate=%.2f%%\n",
           cpu_stats.tlb_hits, cpu_stats.tlb_misses,
           (cpu_stats.tlb_hits + cpu_stats.tlb_misses) ?
           100.0 * cpu_stats.tlb_hits / (cpu_stats.tlb_hits + cpu_stats.tlb_misses) : 0.0);
}

void processor_flush_cache_tlb(void)
{
    cache_reset();
    memset(tlb, 0, sizeof(tlb));
    tlb_clock = 0;
    printf("Cache and TLB flushed.\n");
}
