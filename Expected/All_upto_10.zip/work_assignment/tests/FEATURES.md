# Extended feature smoke tests

- `mmio_demo`: writes ASCII `A` to the simulated console MMIO register at logical address `0xF00`.
- `ipc_demo`: small source examples for the `share` OS command and ordinary shared-memory load/store.
