#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "memory.h"

/*
 * One real physical memory is shared by all processes.
 *
 * A physical frame is PAGESIZE bytes.  The processor never directly uses
 * a logical address as an index into this array.  It first asks the MMU
 * (getPhysicallAddress()) to translate the logical address.
 */
unsigned char memory[MEMSIZE];

/*
 * freePages is OS/MMU bookkeeping, not a page table.  A value of 1 means
 * that the physical frame is currently reserved.  Frame 0 is permanently
 * reserved by the Lab 5 specification.
 */
unsigned char freePages[NUM_PHYSICAL_PAGES];

/*
 * IMPORTANT FOR THIS TASK:
 *
 * The old implementation kept the actual page-table entries in an OS
 * array such as:
 *
 *     pageTable[process][logical_page]
 *
 * That is no longer done.  Instead, every resident process gets one
 * physical frame that contains its page table.  The small array below only
 * remembers WHERE that page table starts; the page-table entries themselves
 * live inside physical memory[] just like ordinary memory.
 *
 * One page-table entry is one byte because there are only 16 physical
 * frames (0..15).  Therefore 10 entries occupy only 10 bytes of the
 * allocated 512-byte page-table frame.
 */
static int page_table_frame[NP];

/* Convert an address to the logical page-table index. */
static int page_index(int isFetch, int address)
{
    if (address < 0)
        return -1;

    if (isFetch)
        return address / PAGESIZE;

    /* Data logical pages follow the 2 instruction pages. */
    return address / PAGESIZE + INSTRUCTION_LOGICAL_SIZE / PAGESIZE;
}

/* Return the physical address of one page-table entry. */
static int page_table_entry_address(int proc_id, int index)
{
    if (proc_id < 0 || proc_id >= NP || index < 0 || index >= NUM_LOGICAL_PAGES)
        return -1;

    if (page_table_frame[proc_id] <= 0 ||
        page_table_frame[proc_id] >= NUM_PHYSICAL_PAGES)
        return -1;

    return page_table_frame[proc_id] * PAGESIZE + index;
}

/* Read one page-table entry from physical memory. */
static int read_page_table_entry(int proc_id, int index)
{
    int address = page_table_entry_address(proc_id, index);
    if (address < 0)
        return 0;

    return memory[address];
}

/* Write one page-table entry into physical memory. */
static void write_page_table_entry(int proc_id, int index, unsigned char frame)
{
    int address = page_table_entry_address(proc_id, index);
    if (address >= 0)
        memory[address] = frame;
}

void memory_system_init(void)
{
    memset(memory, 0, sizeof(memory));
    memset(freePages, 0, sizeof(freePages));

    /* No process owns a page-table frame when the machine starts. */
    for (int i = 0; i < NP; ++i)
        page_table_frame[i] = -1;

    /* Frame 0 is permanently reserved and can never be allocated. */
    freePages[0] = 1;
}

/*
 * Translate a logical address into a physical address.
 *
 * Fetches:
 *     logical page 0..1 -> page-table entry 0..1
 *
 * Data accesses:
 *     logical page 0..7 -> page-table entry 2..9
 *
 * The page-table entry contains the physical frame number.  The lower
 * address bits (address % PAGESIZE) are the offset inside that frame.
 */
int getPhysicallAddress(int proc_id, int isFetch, int address)
{
    int index;
    int frame;
    int offset;

    if (proc_id < 0 || proc_id >= NP || address < 0) {
        fprintf(stderr, "MMU ERROR: invalid proc/address (%d, %d)\n",
                proc_id, address);
        return -1;
    }

    if (isFetch) {
        if (address >= INSTRUCTION_LOGICAL_SIZE) {
            fprintf(stderr,
                    "MMU ERROR: instruction logical address %d out of range\n",
                    address);
            return -1;
        }
    } else {
        if (address >= DATA_LOGICAL_SIZE) {
            fprintf(stderr,
                    "MMU ERROR: data logical address %d out of range\n",
                    address);
            return -1;
        }
    }

    index = page_index(isFetch, address);
    if (index < 0 || index >= NUM_LOGICAL_PAGES) {
        fprintf(stderr, "MMU ERROR: page-table index %d out of range\n", index);
        return -1;
    }

    /*
     * This is the key change for Task 3: the page number is read from
     * physical memory, not from an OS pageTable[][] data structure.
     */
    frame = read_page_table_entry(proc_id, index);

    if (frame <= 0 || frame >= NUM_PHYSICAL_PAGES || freePages[frame] == 0) {
        fprintf(stderr,
                "MMU ERROR: unmapped logical page %d for PID slot %d\n",
                index, proc_id);
        return -1;
    }

    offset = address % PAGESIZE;
    return frame * PAGESIZE + offset;
}

/*
 * Find and reserve the first available physical frame.
 * Frame 0 is deliberately skipped because it is reserved.
 */
int getFreePage(void)
{
    for (int i = 1; i < NUM_PHYSICAL_PAGES; ++i) {
        if (freePages[i] == 0) {
            freePages[i] = 1;
            return i;
        }
    }

    fprintf(stderr, "ERROR: No free physical frame available\n");
    return -1;
}

/*
 * Free everything owned by one process, including its page-table frame.
 *
 * The page table has to be read BEFORE its own frame is released.  We first
 * collect/free all mapped program/data frames and then release the frame
 * that contains the page-table entries themselves.
 */
void releaseProcessPages(int proc_id)
{
    if (proc_id < 0 || proc_id >= NP)
        return;

    if (page_table_frame[proc_id] < 0)
        return;

    for (int i = 0; i < NUM_LOGICAL_PAGES; ++i) {
        int frame = read_page_table_entry(proc_id, i);

        if (frame > 0 && frame < NUM_PHYSICAL_PAGES &&
            frame != page_table_frame[proc_id]) {
            freePages[frame] = 0;
        }

        /* Clear the old entry for easier debugging before the PT is freed. */
        write_page_table_entry(proc_id, i, 0);
    }

    /* Finally release the physical frame occupied by this page table. */
    freePages[page_table_frame[proc_id]] = 0;
    page_table_frame[proc_id] = -1;
}

/*
 * Load one logical memory region from a .byte file.
 *
 * Every byte from the file is placed into physical memory.  The page table
 * is populated as new logical pages are encountered.
 */
static int load_region(int proc_id, const char *file_name,
                       int isFetch, int max_bytes)
{
    FILE *fp = fopen(file_name, "r");
    int value;
    int logical_offset = 0;

    if (!fp) {
        fprintf(stderr, "OS: cannot open %s\n", file_name);
        return -1;
    }

    while (logical_offset < max_bytes && fscanf(fp, "%x", &value) == 1) {
        int index = page_index(isFetch, logical_offset);
        int frame;
        int physical;

        if (index < 0 || index >= NUM_LOGICAL_PAGES) {
            fclose(fp);
            return -1;
        }

        /*
         * A page is allocated lazily.  The first byte belonging to a new
         * logical page causes one physical frame to be allocated.
         */
        frame = read_page_table_entry(proc_id, index);
        if (frame == 0) {
            frame = getFreePage();
            if (frame < 0) {
                fclose(fp);
                return -2; /* Physical memory temporarily unavailable. */
            }

            write_page_table_entry(proc_id, index, (unsigned char)frame);
            memset(memory + frame * PAGESIZE, 0, PAGESIZE);
        }

        /* Use the same MMU path that the processor uses at run time. */
        physical = getPhysicallAddress(proc_id, isFetch, logical_offset);
        if (physical < 0) {
            fclose(fp);
            return -1;
        }

        memory[physical] = (unsigned char)value;
        ++logical_offset;
    }

    fclose(fp);
    return logical_offset;
}

int initialize(int proc_id, const char *program_file, const char *data_file)
{
    int rc;
    int pt_frame;

    if (proc_id < 0 || proc_id >= NP)
        return -1;

    /* Remove any previous address space owned by this processor slot. */
    releaseProcessPages(proc_id);

    /*
     * TASK 3: allocate one physical frame for the page table itself.
     * The page table is therefore part of physical memory rather than an
     * OS-side pageTable[proc][page] array.
     */
    pt_frame = getFreePage();
    if (pt_frame < 0)
        return -2;

    page_table_frame[proc_id] = pt_frame;

    /* A fresh page-table frame starts with all entries unmapped (zero). */
    memset(memory + pt_frame * PAGESIZE, 0, PAGESIZE);

    /* Load instruction pages and data pages through the new page table. */
    rc = load_region(proc_id, program_file, 1, INSTRUCTION_LOGICAL_SIZE);
    if (rc < 0) {
        releaseProcessPages(proc_id);
        return rc;
    }

    rc = load_region(proc_id, data_file, 0, DATA_LOGICAL_SIZE);
    if (rc < 0) {
        releaseProcessPages(proc_id);
        return rc;
    }

    return 0;
}

int finalize(int proc_id, const char *data_file)
{
    FILE *fp;

    if (proc_id < 0 || proc_id >= NP)
        return -1;

    fp = fopen(data_file, "w");
    if (!fp) {
        fprintf(stderr, "OS: cannot write data %s\n", data_file);
        return -1;
    }

    /*
     * Reconstruct the logical data space by translating each logical byte
     * through the page table.  This also proves that the final data does not
     * depend on where the process happened to be placed in physical memory.
     */
    for (int logical = 0; logical < DATA_LOGICAL_SIZE; ++logical) {
        int physical = getPhysicallAddress(proc_id, 0, logical);
        unsigned char value = 0;

        /* Unmapped trailing pages are logically zero-filled. */
        if (physical >= 0)
            value = memory[physical];

        fprintf(fp, "%02X%s", value, (logical % 4 == 3) ? "\n" : " ");
    }

    fclose(fp);

    /* Page-table and data/instruction frames are no longer needed. */
    releaseProcessPages(proc_id);
    return 0;
}

/* Read one 32-bit little-endian value through the MMU. */
int32_t read_memory_32(int proc_id, int address)
{
    uint32_t v = 0;
    int p0, p1, p2, p3;

    p0 = getPhysicallAddress(proc_id, 0, address);
    p1 = getPhysicallAddress(proc_id, 0, address + 1);
    p2 = getPhysicallAddress(proc_id, 0, address + 2);
    p3 = getPhysicallAddress(proc_id, 0, address + 3);

    if (p0 < 0 || p1 < 0 || p2 < 0 || p3 < 0) {
        fprintf(stderr, "Memory read error: proc=%d address=%d\n", proc_id, address);
        return 0;
    }

    v = (uint32_t)memory[p0]
      | ((uint32_t)memory[p1] << 8)
      | ((uint32_t)memory[p2] << 16)
      | ((uint32_t)memory[p3] << 24);
    return (int32_t)v;
}

/* Write one 32-bit little-endian value through the MMU. */
void write_memory_32(int proc_id, int address, int32_t value)
{
    uint32_t v = (uint32_t)value;
    int p0, p1, p2, p3;

    p0 = getPhysicallAddress(proc_id, 0, address);
    p1 = getPhysicallAddress(proc_id, 0, address + 1);
    p2 = getPhysicallAddress(proc_id, 0, address + 2);
    p3 = getPhysicallAddress(proc_id, 0, address + 3);

    if (p0 < 0 || p1 < 0 || p2 < 0 || p3 < 0) {
        fprintf(stderr, "Memory write error: proc=%d address=%d\n", proc_id, address);
        return;
    }

    memory[p0] = (unsigned char)(v & 0xff);
    memory[p1] = (unsigned char)((v >> 8) & 0xff);
    memory[p2] = (unsigned char)((v >> 16) & 0xff);
    memory[p3] = (unsigned char)((v >> 24) & 0xff);
}
