#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>

/*
 * The machine has four processor slots.  Each processor slot represents
 * one currently resident process in the Lab 5 operating-system model.
 */
#define NP 4
#define MAX_PROC NP

/* Physical and logical memory sizes from the Lab 5 specification. */
#define MEMSIZE 8192
#define PAGESIZE 512
#define INSTRUCTION_LOGICAL_SIZE 1024
#define DATA_LOGICAL_SIZE 4096

/*
 * Two instruction pages (1024/512) + eight data pages (4096/512).
 * A page-table entry stores the physical frame number for one logical page.
 */
#define NUM_LOGICAL_PAGES (INSTRUCTION_LOGICAL_SIZE / PAGESIZE + DATA_LOGICAL_SIZE / PAGESIZE)
#define NUM_PHYSICAL_PAGES (MEMSIZE / PAGESIZE)

extern unsigned char memory[MEMSIZE];
extern unsigned char freePages[NUM_PHYSICAL_PAGES];

/* Lab 5 MMU / memory-management API. */
void memory_system_init(void);
int getPhysicallAddress(int proc_id, int isFetch, int address);
int getFreePage(void);
void releaseProcessPages(int proc_id);

int initialize(int proc_id, const char *program_file, const char *data_file);
int finalize(int proc_id, const char *data_file);

int32_t read_memory_32(int proc_id, int address);
void write_memory_32(int proc_id, int address, int32_t value);

#endif
