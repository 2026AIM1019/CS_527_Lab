# Task 2 - Extending Round-Robin Scheduling

## 1. Intuition

Round-robin (RR) is fair because every READY task gets a fixed time slice. However, an operating system does not always want every task to be treated exactly the same way.

For example:

- A short job should ideally finish quickly instead of waiting behind a long job.
- An important task may deserve more CPU preference than a background task.
- Some systems want to preserve arrival order.

Therefore, this extension keeps the original RR scheduler but adds several scheduling schemes that use the **same task table, context-switch mechanism, MMU, processor, and READY queue**.

The important idea is:

```text
                    READY TASKS
                         |
                         v
              +----------------------+
              | Scheduling policy    |
              +----------------------+
                 |    |    |     |
                RR   FCFS  SJF  PRIORITY
                 \    |    |     /
                  \   |    |    /
                   v  v    v   v
                    selected task
                         |
                         v
                    CPU dispatch
                         |
                         v
                  execute instructions
                         |
              +----------+----------+
              |                     |
           finished             not finished
              |                     |
           finalize              SAVE context
                                    |
                                  READY
```

The scheduler therefore changes **which task is selected**, while the processor still performs the same fetch/decode/execute operations.

---

## 2. Scheduling schemes implemented

### A. Round Robin (RR)

This is the original scheduler and remains the default.

Each task receives:

```text
TIME_SLICE = 10 instructions
```

Example:

```text
PID 1 -> 10 instructions
PID 2 -> 10 instructions
PID 3 -> 10 instructions
PID 1 -> next 10 instructions
...
```

After a slice, the processor context is saved into the task. When the task is selected again, its context is restored.

---

### B. First-Come, First-Served (FCFS)

FCFS gives preference to the task that arrived first.

The OS records an `arrival_order` for every task. The scheduler selects the smallest arrival order.

Unlike RR, FCFS is implemented as a **non-preemptive style** scheme in this simulator: once selected, the task is allowed to use its estimated remaining instruction count in one dispatch. If the program reaches its end earlier, the processor stops immediately.

Example:

```text
Arrival:
PID 1 -> PID 2 -> PID 3

Execution:
PID 1 -> finishes
PID 2 -> finishes
PID 3 -> finishes
```

This demonstrates the classic FCFS idea while reusing the existing processor execution function.

---

### C. Shortest Job First (SJF)

SJF selects the task with the smallest estimated remaining job size.

The compiler's bytecode is stored as four hexadecimal byte tokens per instruction. The loader counts those tokens and records the number of instructions in `total_instructions`.

For a task that has already executed some instructions:

```text
estimated remaining = total instructions - PC / 4
```

This is an estimate because a branch can execute the same instructions repeatedly.

SJF is also implemented as a non-preemptive style scheme: after selection, the estimated remaining instructions are given to the processor in one dispatch.

Example:

```text
PID 1 -> 15 instructions
PID 2 ->  4 instructions
PID 3 ->  8 instructions

SJF order:
PID 2 -> PID 3 -> PID 1
```

This is why the code does not simply use file size: `program.byte` is a text file containing hexadecimal byte tokens, not a binary instruction image.

---

### D. Priority Scheduling

Every task has a priority value:

```text
larger number = higher priority
```

Default priority:

```text
priority = 1
```

Priority scheduling remains preemptive and uses the normal `TIME_SLICE` of 10 instructions.

If two tasks have the same effective priority, the RR cursor is used as the tie-breaker so that the task table order does not permanently dominate the decision.

### Aging

A pure priority scheduler can starve low-priority tasks. To reduce this problem, the implementation uses **aging**.

A task that waits for scheduler rounds gradually gains effective priority:

```text
waiting rounds / 5
```

is added to its base priority.

Therefore a low-priority task can eventually become competitive with higher-priority tasks instead of waiting forever.

---

## 3. How the code works

The central data structure is the `Task` structure in `os.c`.

Important scheduling fields are:

```c
unsigned long arrival_order;
int priority;
unsigned long ready_since;
int total_instructions;
```

### `arrival_order`

Used by FCFS and as a stable tie-breaker.

### `priority`

Used by priority scheduling. Higher value means more important.

### `ready_since`

Records when a task entered the READY state. Priority scheduling uses it for aging.

### `total_instructions`

Stores the static bytecode instruction count used by SJF.

---

## 4. Task selection

The function:

```c
next_ready_task()
```

is the central selection point.

For RR, it scans starting from `ready_cursor`.

For the other policies it scans all READY tasks and compares candidates using:

```c
better_task()
```

This separation is useful because the rest of the OS does not need to know how a task was selected.

---

## 5. Different quantum for different policies

The function:

```c
scheduling_quantum()
```

decides how many instructions the selected task may execute.

```text
RR        -> TIME_SLICE (10)
PRIORITY  -> TIME_SLICE (10)
FCFS      -> estimated remaining instructions
SJF       -> estimated remaining instructions
```

This makes FCFS and SJF behave like non-preemptive schemes while RR and Priority remain time-sliced.

---

## 6. Context switching is still unchanged conceptually

The scheduling policy does **not** store registers itself. The existing context-switch implementation does that.

When a time-sliced task is not finished:

```text
CPU registers
PC
Z/N/C/V
vector registers
        |
        v
save_processor_context()
        |
        v
Task.context
        |
        v
Task -> READY
```

When it runs again:

```text
Task.context
      |
      v
load_processor_context()
      |
      v
CPU
```

This is the key separation of responsibilities:

```text
Scheduler -> decides WHO runs
Processor  -> decides HOW instructions execute
Task       -> owns saved CPU context
MMU        -> maintains the task's address-space mapping
```

---

## 7. Changing policy at runtime

The shell understands:

```text
policy rr
policy fcfs
policy sjf
policy priority
```

Example:

```text
$ policy sjf
[OS] Scheduling policy changed to SJF
```

The next scheduling decision uses SJF.

You can also ask for:

```text
$ help
```

The shell prints the available policies and input format.

---

## 8. Priority input

The normal input remains compatible:

```text
<program.txt> <data.byte>
```

An optional third value can specify priority:

```text
<program.txt> <data.byte> <priority>
```

Priority must be between `0` and `100`.

Example:

```text
$ tests/lab4_multiprocess/program1.txt tests/lab4_multiprocess/data1.byte 80
```

Here PID gets priority 80.

If no priority is supplied, the task receives priority 1.

---

## 9. Selecting a policy before execution

The policy can also be selected through the environment:

```bash
SCHED_POLICY=rr ./executable
SCHED_POLICY=fcfs ./executable
SCHED_POLICY=sjf ./executable
SCHED_POLICY=priority ./executable
```

This is useful for automated experiments because the source code does not need to be changed.

---

## 10. Single processor and multiprocessor compatibility

The same scheduler works for both configurations.

### One processor

```bash
make clean
make NP=1
```

Only CPU 0 executes tasks, but several tasks can share it through context switching.

### Four processors

```bash
make clean
make NP=4
```

The scheduler fills available CPUs from the same READY queue.

The scheduling policy determines which tasks are selected, while the existing context system allows a task to save its state and later resume on a processor.

---

## 11. Example comparison

Suppose the READY queue contains:

```text
PID 1: arrival=1, estimated size=15, priority=2
PID 2: arrival=2, estimated size=4,  priority=1
PID 3: arrival=3, estimated size=8,  priority=5
```

A useful way to understand the policies is:

```text
RR:
    1 -> 2 -> 3 -> 1 -> ...

FCFS:
    1 -> 2 -> 3

SJF:
    2 -> 3 -> 1

PRIORITY:
    3 -> ...
```

The exact future order can change as tasks finish, new tasks arrive, or priority aging changes their effective priority.

---

## 12. Why this is an extension rather than a separate scheduler

The implementation deliberately keeps one scheduling pipeline:

```text
READY queue
    |
    v
next_ready_task()
    |
    v
selected task
    |
    v
restore/create context
    |
    v
scheduling_quantum()
    |
    v
process_instructions()
    |
    +---- finished ----> finalize()
    |
    +---- unfinished --> save context -> READY
```

Only the decision functions change according to the selected policy. This keeps the code easy to understand and avoids duplicating the processor, memory, and context-switch logic.
