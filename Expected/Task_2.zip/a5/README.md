# CS527 Lab 5 - Task 2: Scheduling Schemes

This project is the CS527 Lab 5 mini-computer simulator. The existing Lab 5 functionality and Task 1 context-switching/multiprocessor implementation are retained.

## Task 2 implemented

The original Round-Robin scheduler has been extended with multiple scheduling schemes:

1. **Round Robin (RR)** - default, 10-instruction time slice.
2. **FCFS (First-Come, First-Served)** - older tasks get preference; implemented as a non-preemptive style dispatch.
3. **SJF (Shortest Job First)** - the task with the smallest estimated remaining instruction count gets preference.
4. **Priority Scheduling** - larger priority value gets preference, with aging to reduce starvation.

The scheduler can be changed at runtime from the shell or selected through the `SCHED_POLICY` environment variable.

See `TASK2_SCHEDULING.md` for the complete intuition, design, algorithms, context-switch flow, and examples.

---

## 1. Project structure

```text
main.c                    Program entry point
compiler.c                Source-language compiler
compiler.h                Compiler declarations
processor.c               CPU fetch/decode/execute + context support
processor.h               Processor state and context declarations
memory.c                  Physical memory, paging and MMU
memory.h                  Memory declarations
os.c                      Loader, task table, shell and scheduler
os.h                      OS declarations
Makefile                  Build and test commands
README.md                 This file
TASK2_SCHEDULING.md       Task 2 intuition and complete design explanation
LAB5_CHANGES.md           Task 1/context-switching notes
TEST_CASES.md             Existing test descriptions
test_runner.py            Automated regression tests
run_multiprocess_demo.sh  Four-processor demonstration
```

---

## 2. Build the project

### Single processor - Task 1 and Task 2

```bash
make clean
make NP=1
```

`NP=1` is also the default, so this is enough:

```bash
make
```

### Four-processor extension

```bash
make clean
make NP=4
```

or:

```bash
make mp
```

---

## 3. Run the project

The executable is:

```bash
./executable
```

There are two ways to provide tasks.

### Method A - command-line input

Pass program/data pairs:

```bash
./executable tests/test_01/program.txt tests/test_01/data.byte
```

Multiple tasks can be supplied as pairs:

```bash
./executable \
  tests/lab4_multiprocess/program1.txt tests/lab4_multiprocess/data1.byte \
  tests/lab4_multiprocess/program2.txt tests/lab4_multiprocess/data2.byte \
  tests/lab4_multiprocess/program3.txt tests/lab4_multiprocess/data3.byte
```

The format is always:

```text
program-file data-file
```

The command-line form uses the default priority of `1` for every task.

### Method B - interactive shell

Run:

```bash
./executable
```

You will see:

```text
$ 
```

Enter a task as:

```text
$ tests/test_01/program.txt tests/test_01/data.byte
```

The `$` is the simulator prompt. You may also type the command without `$`.

For priority scheduling, an optional priority can be supplied:

```text
$ tests/test_01/program.txt tests/test_01/data.byte 80
```

Priority must be an integer from `0` to `100`. Larger values mean higher priority.

To stop accepting new tasks:

```text
$ exit
```

`exit` does not terminate existing tasks. The OS continues scheduling all tasks that are already accepted.

---

## 4. Scheduler commands

The interactive shell supports:

```text
$ help
```

Show scheduling commands.

```text
$ policy rr
```

Use Round Robin.

```text
$ policy fcfs
```

Use First-Come, First-Served.

```text
$ policy sjf
```

Use Shortest Job First.

```text
$ policy priority
```

Use Priority Scheduling.

The policy can be changed while the simulator is running. The next dispatch decision uses the new policy.

---

## 5. Selecting a policy before running

You can select the scheduling policy from the terminal without modifying the code:

```bash
SCHED_POLICY=rr ./executable
SCHED_POLICY=fcfs ./executable
SCHED_POLICY=sjf ./executable
SCHED_POLICY=priority ./executable
```

You can also combine it with command-line tasks:

```bash
SCHED_POLICY=sjf ./executable \
  tests/lab4_multiprocess/program1.txt tests/lab4_multiprocess/data1.byte \
  tests/lab4_multiprocess/program2.txt tests/lab4_multiprocess/data2.byte
```

---

## 6. What each scheduling scheme does

### Round Robin

Every selected READY task gets up to 10 instructions:

```text
PID1 -> 10 instructions
PID2 -> 10 instructions
PID3 -> 10 instructions
PID1 -> next 10 instructions
...
```

If a task does not finish, its CPU context is saved and it returns to READY.

### FCFS

The oldest task gets preference based on `arrival_order`.

The selected task is allowed to run its estimated remaining instruction count in one dispatch. This gives the scheme its non-preemptive FCFS behaviour.

### SJF

The scheduler estimates remaining work using:

```text
estimated remaining = total bytecode instructions - PC / 4
```

The smallest estimated job is selected first.

### Priority

Larger priority means more important:

```text
priority 90 > priority 50 > priority 10
```

Priority scheduling is time-sliced. Equal effective priorities use a rotating tie-breaker.

Aging is also implemented so that a task waiting for many scheduler rounds gradually gains effective priority and is less likely to starve.

---

## 7. Single processor multitasking

Build with:

```bash
make clean
make NP=1
```

There can still be many tasks. They share CPU 0 through context switching.

Conceptually:

```text
PID1 -> CPU0 -> SAVE context
PID2 -> CPU0 -> SAVE context
PID3 -> CPU0 -> SAVE context
PID1 -> CPU0 -> RESTORE context
...
```

A task's saved context contains its integer registers, vector registers, PC, flags and execution state.

---

## 8. Multiprocessor extension

Build with:

```bash
make clean
make NP=4
```

The same READY queue is shared by the four processor instances.

The scheduler fills available CPUs from the READY queue. A task's architectural context belongs to the task, so it can be saved and later restored independently of which CPU executes it.

---

## 9. Paging and MMU

The Lab 5 memory model remains:

```text
MEMSIZE  = 8192 bytes
PAGESIZE = 512 bytes
```

There are 16 physical frames, with frame 0 reserved.

Each task has its own page-table mapping. The task slot, rather than processor ID, identifies the logical address space. This remains important when tasks move between processor instances.

---

## 10. Process log

The simulator writes scheduler and context-switch information to:

```text
process.log
```

Examples include:

```text
[DISPATCH] PID 2 -> CPU 0 (policy=SJF, priority=1, remaining~4)
[DISPATCH] PID 2 selected by SJF: quantum=4
[CONTEXT] SAVE PID 1 <- CPU 0: PC=40
[CONTEXT] RESTORE PID 1 -> CPU 0: PC=40
```

The log is useful for understanding and verifying scheduling decisions.

---

## 11. Demonstration

For the four-processor demonstration:

```bash
make demo
```

For a detailed scheduling demonstration with the selected policy:

```bash
OS_DEMO=1 SCHED_POLICY=sjf ./executable \
  tests/lab4_multiprocess/program1.txt tests/lab4_multiprocess/data1.byte \
  tests/lab4_multiprocess/program2.txt tests/lab4_multiprocess/data2.byte
```

---

## 12. Automated testing

Run:

```bash
make test
```

The regression suite verifies the existing scalar, vector, Print and MMU functionality plus the Task 1 single-processor and multiprocessor behaviour.

The final expected result for the existing regression suite is:

```text
11/11 tests passed
ALL TESTS PASSED
```

---

## 13. Important source-code idea

The scheduler does not duplicate processor logic for each policy.

The common pipeline is:

```text
READY queue
    |
    v
select task according to policy
    |
    v
restore/create task context
    |
    v
choose policy-specific quantum
    |
    v
execute instructions
    |
    +---- finished ----> finalize + free pages
    |
    +---- unfinished --> save context + READY
```

This makes Task 2 an extension of the original scheduler rather than a separate implementation.
