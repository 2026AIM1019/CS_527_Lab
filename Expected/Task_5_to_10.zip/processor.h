#ifndef PROCESSOR_H
#define PROCESSOR_H
#include <stdint.h>
#include <stdio.h>
#include "memory.h"

extern int32_t Register[NP][256];
extern int32_t VectorRegister[NP][32][8];
extern int PC[NP];
extern int opcode, dest, src1, src2;
extern int Z[NP], N[NP], C[NP], V[NP];
extern int process_pid[NP];
extern int end_of_simulation[NP];
extern int proc_id;
extern FILE *fd_log;

typedef struct {
    unsigned long instructions;
    unsigned long tlb_hits, tlb_misses;
    unsigned long cache_hits, cache_misses;
    unsigned long memory_accesses;
    unsigned long branch_count, branch_taken;
    unsigned long pipeline_stalls;
    unsigned long pipeline_cycles;
    unsigned long total_cycles;
    unsigned long wall_ns;
} ProcessorStats;

void reset(int id);
void fetch(int id);
void decode(void);
void execute(int id);
void process_instructions(int id, int instruction_count);
void set_processor_pid(int id, int pid);
void processor_stats_reset(int id);
const ProcessorStats *processor_get_stats(int id);
void processor_dump_stats(FILE *out, int id);
void processor_invalidate_translation_cache(int id);
void processor_invalidate_cache(int id);
int processor_cached_read32(int id, int address, int32_t *out);
int processor_cached_write32(int id, int address, int32_t value);

#endif
