#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>

/*
 * Physical-memory configuration.
 *
 * The original Lab-5 machine has 8 KiB of physical memory divided into
 * 512-byte frames.  Frame 0 is reserved for OS metadata/page tables.
 */
#define NP 4
#define MAX_PROC NP
#define MEMSIZE 8192
#define PAGESIZE 512
#define INSTRUCTION_LOGICAL_SIZE 1024
#define DATA_LOGICAL_SIZE 4096
#define NUM_LOGICAL_PAGES (INSTRUCTION_LOGICAL_SIZE / PAGESIZE + DATA_LOGICAL_SIZE / PAGESIZE)
#define NUM_PHYSICAL_PAGES (MEMSIZE / PAGESIZE)

/* Memory-mapped I/O lives in the upper part of the 4-KiB data address space. */
#define MMIO_BASE       0x00F0
#define MMIO_STATUS     0x00F0
#define MMIO_INPUT      0x00F4
#define MMIO_OUTPUT     0x00F8
#define MMIO_TIMER      0x00FC
#define MMIO_PID        0x00EC

/* Page-table entry permission bits.  Low four bits contain the frame. */
#define PTE_FRAME_MASK 0x0F
#define PTE_READ        0x10
#define PTE_WRITE       0x20
#define PTE_EXEC        0x40
#define PTE_SHARED      0x80

typedef enum { ACCESS_READ = 0, ACCESS_WRITE = 1, ACCESS_EXEC = 2 } MemoryAccess;

extern unsigned char memory[MEMSIZE];

/* Initialise the physical memory and the page-table area in frame 0. */
void memory_system_init(void);

/* Translate a logical address and enforce page permissions. */
int getPhysicallAddress(int proc_id, int isFetch, int address);
int translate_address(int proc_id, int address, MemoryAccess access);

/* Physical-frame allocator. Frame 0 is permanently reserved. */
int getFreePage(void);
void releaseProcessPages(int proc_id);

/* Load/finalise a process. */
int initialize(int proc_id, const char *program_file, const char *data_file);
int finalize(int proc_id, const char *data_file);

/* 32-bit little-endian memory operations. */
int32_t read_memory_32(int proc_id, int address);
void write_memory_32(int proc_id, int address, int32_t value);

/* Shared-memory support used by the OS/IPC extension. */
int memory_share_region(int proc_id, int logical_address, int size, int writable);
int memory_map_shared_page(int proc_id, int logical_page_index, int frame, int writable);
int memory_is_shared(int proc_id, int logical_address);

/* Utilities for the OS shell and documentation/debugging. */
void dump_memory_map(FILE *out);
void dump_process_memory_map(FILE *out, int proc_id, int pid);
int get_page_frame(int proc_id, int logical_page_index);
unsigned char get_page_entry(int proc_id, int logical_page_index);

/* MMIO helpers. */
int memory_is_mmio(int address);
int32_t mmio_read(int proc_id, int address);
void mmio_write(int proc_id, int address, int32_t value);

#endif
