#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "compiler.h"

#define MAX_LABELS 100

typedef struct
{
    char name[50];
    int address;
} Label;

Label labels[MAX_LABELS];
int label_count = 0;

int find_label(const char *name)
{
    for (int i = 0; i < label_count; i++)
    {
        if (strcmp(labels[i].name, name) == 0)
        {
            return labels[i].address;
        }
    }

    return -1;
}


/*
 * Educational register-allocation report.
 *
 * The ISA exposes 256 physical integer registers (x0..x255).  Source-level
 * virtual names rN are accepted as aliases for the same register namespace.
 * Before emitting bytecode we perform a simple interval/liveness analysis:
 * first and last use of each virtual name are collected and a linear-scan
 * graph-colouring pass assigns the lowest available physical colour.  If a
 * program asks for more than 256 simultaneously-live virtual registers, the
 * report identifies spill candidates.  The baseline language normally uses
 * xN directly, so no old program changes behaviour.
 */
typedef struct { int id, first, last, colour, uses; } VRegInfo;
static VRegInfo vregs[1024];
static int vreg_count;

static void normalize_virtual_registers(char *line)
{
    /* Convert rN to xN before the legacy parser sees the instruction.
     * This makes virtual-register syntax a front-end feature while the
     * existing 256-register ISA remains unchanged. */
    char out[512]; int oi=0;
    for(int i=0; line[i] && oi<(int)sizeof(out)-1; ) {
        if((line[i]=='r'||line[i]=='R') && isdigit((unsigned char)line[i+1])) {
            int n=0,j=i+1;
            while(isdigit((unsigned char)line[j])) { n=n*10+(line[j]-'0'); ++j; }
            int colour=-1;
            for(int k=0;k<vreg_count;k++) if(vregs[k].id==n) { colour=vregs[k].colour; break; }
            if(colour>=0) {
                int wrote=snprintf(out+oi,sizeof(out)-oi,"x%d",colour);
                if(wrote>0) oi+=wrote;
            } else {
                /* A virtual register with no physical colour is a true spill
                 * candidate.  Leave it untouched so the normal compiler emits
                 * a warning rather than silently using the wrong register. */
                while(i<j && oi<(int)sizeof(out)-1) out[oi++]=line[i++];
                continue;
            }
            i=j;
        } else out[oi++]=line[i++];
    }
    out[oi]='\0'; strcpy(line,out);
}

static void analyze_virtual_registers(const char *source_file, const char *program_file)
{
    FILE *f=fopen(source_file,"r");
    char line[256]; int address=0;
    vreg_count=0;
    if(!f) return;
    while(fgets(line,sizeof(line),f)){
        char *q=strchr(line,'%'); if(q)*q='\0';
        for(char *p=line; *p; ) {
            if((*p=='r'||*p=='R') && isdigit((unsigned char)p[1])) {
                long n=0; int len=0;
                sscanf(p+1,"%ld%n",&n,&len);
                if(n>=0&&n<1024){
                    int k=-1; for(int i=0;i<vreg_count;i++)if(vregs[i].id==n)k=i;
                    if(k<0&&vreg_count<1024){k=vreg_count++;vregs[k]=(VRegInfo){(int)n,address,address,0,0};}
                    if(k>=0){if(address<vregs[k].first)vregs[k].first=address;if(address>vregs[k].last)vregs[k].last=address;vregs[k].uses++;}
                }
                p += 1+len;
            } else ++p;
        }
        if(line[0]!='\0' && line[0]!='\n' && line[0]!='.') address+=4;
    }
    fclose(f);

    /* Linear-scan colouring is equivalent to colouring an interval graph. */
    for(int i=0;i<vreg_count;i++){
        int used[256]={0};
        for(int j=0;j<i;j++) if(vregs[j].colour>=0 && vregs[j].colour<256 &&
                                  vregs[j].last>=vregs[i].first && vregs[j].first<=vregs[i].last)
            used[vregs[j].colour]=1;
        int c; for(c=0;c<256&&used[c];c++);
        vregs[i].colour=(c<256)?c:-1;
    }

    char report[512];
    snprintf(report,sizeof(report),"%s.registers.md",program_file);
    FILE *o=fopen(report,"w"); if(!o)return;
    fprintf(o,"# Virtual-register allocation report\n\n");
    fprintf(o,"The compiler treats `rN` as a virtual integer register. `first` and `last` are bytecode addresses of its live interval.\n\n");
    fprintf(o,"| Virtual | First | Last | Uses | Physical colour | Spill |\n|---:|---:|---:|---:|---:|:---:|\n");
    int spills=0;
    for(int i=0;i<vreg_count;i++){
        if(vregs[i].colour<0)spills++;
        char colour_name[16];
        if(vregs[i].colour<0) snprintf(colour_name,sizeof(colour_name),"-");
        else snprintf(colour_name,sizeof(colour_name),"x%d",vregs[i].colour);
        fprintf(o,"| r%d | %d | %d | %d | %s | %s |\n",vregs[i].id,vregs[i].first,vregs[i].last,vregs[i].uses,
                colour_name,vregs[i].colour<0?"yes":"no");
    }
    fprintf(o,"\n## Algorithm\n\n1. Scan the source and record first/last use (liveness intervals).\n2. Colour overlapping intervals with different physical registers.\n3. Choose the lowest free colour, making the result deterministic.\n4. Intervals for which all 256 colours are occupied are marked as spill candidates.\n\nSpill candidates are intentionally reported rather than silently corrupting a program; the supplied ISA has no dedicated stack/spill opcode, so the OS data space is the natural location for a future spill pass.\n\nSpill candidates: %d\n",spills);
    fclose(o);
}

void compile(const char *source_file, const char *program_file)
{
    label_count = 0;
    analyze_virtual_registers(source_file, program_file);
    FILE *input;
    FILE *output;

    char line[100];

    input = fopen(source_file, "r");

    if (input == NULL)
    {
        printf("Error: Cannot open %s\n", source_file);
        return;
    }

    output = fopen(program_file, "w");

    if (output == NULL)
    {
        printf("Error: Cannot create %s\n", program_file);
        fclose(input);
        return;
    }

    /* ============================================================
     * FIRST PASS
     *
     * Find all labels and calculate their byte addresses.
     * ============================================================
     */

    FILE *pass1 = fopen(source_file, "r");

    if (pass1 == NULL)
    {
        printf("Error: Cannot open %s\n", source_file);
        return;
    }

    int address = 0;

    // char line[100];

    while (fgets(line, sizeof(line), pass1))
    {
        /* Remove comments */

        char *comment = strchr(line, '%');

        if (comment != NULL)
        {
            *comment = '\0';
        }

        /* Ignore blank lines */

        if (line[0] == '\0' || line[0] == '\n')
        {
            continue;
        }

        /* Check for label */

        if (line[0] == '.')
        {
            line[strcspn(line, "\r\n")] = '\0';

            if (label_count >= MAX_LABELS)
            {
                printf("Error: Too many labels.\n");
                fclose(pass1);
                return;
            }

            strcpy(labels[label_count].name, line);

            labels[label_count].address = address;

            printf("LABEL: %s -> address %d\n",
                   labels[label_count].name,
                   address);

            label_count++;

            continue;
        }

        /*
         * Every non-label instruction occupies
         * exactly four bytes.
         */

        address += 4;
    }

    fclose(pass1);

    int current_address = 0;
    while (fgets(line, sizeof(line), input))
    {
        int dest;
        int src1;
        int src2;
        int constant;

        char operation;

        /*
         * Remove comments.
         *
         * Anything after '%' is ignored.
         */

        char *comment = strchr(line, '%');

        if (comment != NULL)
        {
            *comment = '\0';
        }

        normalize_virtual_registers(line);

        /*
         * Skip empty lines
         */

        if (line[0] == '\0' || line[0] == '\n')
        {
            continue;
        }

        /* Labels are handled in the first pass. They do not generate bytecode. */
        if (line[0] == '.')
        {
            continue;
        }


        /* ============================================================
         * SHARED-MEMORY DECLARATION
         *
         * Syntax:
         *     SHARED 512 512
         *
         * The directive is metadata rather than an ordinary ALU instruction.
         * We still emit a four-byte 0xF0 record so the generated binary
         * carries the declaration.  The OS reads it while loading the task
         * and maps the declared data pages to a shared physical frame.
         * ============================================================ */
        {
            int shared_addr, shared_size;
            if (sscanf(line, "SHARED %d %d", &shared_addr, &shared_size) == 2) {
                if (shared_addr < 0 || shared_addr >= 4096 || shared_size <= 0 ||
                    shared_addr + shared_size > 4096 || shared_addr % 512 != 0 ||
                    shared_size % 512 != 0) {
                    printf("Error: SHARED address/size must be page aligned and inside data memory.\n");
                    fclose(input); fclose(output); return;
                }
                fprintf(output, "%02X %02X %02X %02X\n", 0xF0,
                        shared_addr / 512, shared_size / 512, 0x03);
                current_address += 4;
                continue;
            }
        }

        /* =====================================================
           PRINT

           Print x5
           Bytecode: 08 00 00 05
           ===================================================== */
        if (sscanf(line, "Print x%d", &src2) == 1)
        {
            if (src2 < 0 || src2 > 255)
            {
                printf("Error: Invalid register in Print.\n");
                fclose(input);
                fclose(output);
                return;
            }
            fprintf(output, "%02X %02X %02X %02X\n", 0x08, 0, 0, src2);
            current_address += 4;
            continue;
        }

        /* =====================================================
           LEGACY READ

           Read x1, 0

           Opcode = 0x05
           ===================================================== */

        if (sscanf(line, "Read x%d, %d", &dest, &constant) == 2)
        {
            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    0x0D,
                    dest,
                    0,
                    constant);
            current_address += 4;
            continue;
        }

        /* =====================================================
           LEGACY WRITE

           Write x1, 20

           Opcode = 0x06
           ===================================================== */

        if (sscanf(line, "Write x%d, %d", &dest, &constant) == 2)
        {
            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    0x0E,
                    0,
                    dest,
                    constant);
            current_address += 4;
            continue;
        }

        /* ============================================================
         * MEMORY READ - VARIABLE ADDRESS
         *
         * x1 = [x2]
         *
         * Opcode: 0x05
         *
         * Bytecode:
         * 05 dest address_register 00
         * ============================================================
         */

        if (sscanf(line, "x%d = [x%d]", &dest, &src1) == 2)
        {
            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    0x05,
                    dest,
                    src1,
                    0);
            current_address += 4;
            continue;
        }

        /* ============================================================
         * MEMORY READ - CONSTANT ADDRESS
         *
         * x1 = [100]
         *
         * Opcode: 0x0D
         *
         * Bytecode:
         * 0D dest 00 address
         * ============================================================
         */

        if (sscanf(line, "x%d = [%d]", &dest, &src1) == 2)
        {
            if (src1 < 0 || src1 > 255)
            {
                printf("Error: Memory address must be 0-255.\n");
                fclose(input);
                fclose(output);
                return;
            }

            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    0x0D,
                    dest,
                    0,
                    src1);
            current_address += 4;
            continue;
        }

        /* ============================================================
         * MEMORY WRITE - VARIABLE ADDRESS
         *
         * [x1] = x2
         *
         * Opcode: 0x06
         *
         * Bytecode:
         * 06 00 value_register address_register
         * ============================================================
         */

        if (sscanf(line, "[x%d] = x%d", &dest, &src1) == 2)
        {
            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    0x06,
                    0,
                    src1,
                    dest);

            current_address += 4;
            continue;
        }

        /* ============================================================
         * MEMORY WRITE - CONSTANT ADDRESS
         *
         * [100] = x2
         *
         * Opcode: 0x0E
         *
         * Bytecode:
         * 0E 00 value_register address
         * ============================================================
         */

        if (sscanf(line, "[%d] = x%d", &src1, &dest) == 2)
        {
            if (src1 < 0 || src1 > 255)
            {
                printf("Error: Memory address must be 0-255.\n");
                fclose(input);
                fclose(output);
                return;
            }

            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    0x0E,
                    0,
                    dest,
                    src1);
            current_address += 4;
            continue;
        }

        /* ============================================================
         * VECTOR MEMORY READ
         *
         * v1 = [x2]     -> 8 consecutive 32-bit elements
         * v1 = [32]
         * ============================================================
         */
        if (sscanf(line, "v%d = [x%d]", &dest, &src1) == 2)
        {
            if (dest < 0 || dest > 31 || src1 < 0 || src1 > 255)
            {
                printf("Error: Invalid vector/register number.\n");
                fclose(input); fclose(output); return;
            }
            fprintf(output, "%02X %02X %02X %02X\n", 0x25, dest, src1, 0);
            current_address += 4;
            continue;
        }

        if (sscanf(line, "v%d = [%d]", &dest, &constant) == 2)
        {
            if (dest < 0 || dest > 31 || constant < 0 || constant > 255)
            {
                printf("Error: Invalid vector/address.\n");
                fclose(input); fclose(output); return;
            }
            fprintf(output, "%02X %02X %02X %02X\n", 0x2C, dest, 0, constant);
            current_address += 4;
            continue;
        }

        /* ============================================================
         * VECTOR MEMORY WRITE
         *
         * [x2] = v1
         * [32] = v1
         * ============================================================
         */
        if (sscanf(line, "[x%d] = v%d", &src1, &dest) == 2)
        {
            if (dest < 0 || dest > 31 || src1 < 0 || src1 > 255)
            {
                printf("Error: Invalid vector/register number.\n");
                fclose(input); fclose(output); return;
            }
            fprintf(output, "%02X %02X %02X %02X\n", 0x26, 0, dest, src1);
            current_address += 4;
            continue;
        }

        if (sscanf(line, "[%d] = v%d", &constant, &dest) == 2)
        {
            if (dest < 0 || dest > 31 || constant < 0 || constant > 255)
            {
                printf("Error: Invalid vector/address.\n");
                fclose(input); fclose(output); return;
            }
            fprintf(output, "%02X %02X %02X %02X\n", 0x2E, 0, dest, constant);
            current_address += 4;
            continue;
        }

        /* ============================================================
         * VECTOR ARITHMETIC
         *
         * v3 = v1 + v4
         * v3 = v1 + x4
         * v3 = v1 + 15
         * ============================================================
         */
        if (sscanf(line, "v%d = v%d %c v%d", &dest, &src1, &operation, &src2) == 4)
        {
            int vopcode = -1;
            if (operation == '+') vopcode = 0x21;
            else if (operation == '-') vopcode = 0x22;
            else if (operation == '*') vopcode = 0x23;
            if (vopcode < 0 || dest < 0 || dest > 31 || src1 < 0 || src1 > 31 || src2 < 0 || src2 > 31)
            {
                printf("Error: Invalid vector operation.\n");
                fclose(input); fclose(output); return;
            }
            fprintf(output, "%02X %02X %02X %02X\n", vopcode, dest, src1, src2);
            current_address += 4;
            continue;
        }

        if (sscanf(line, "v%d = v%d %c %d", &dest, &src1, &operation, &constant) == 4)
        {
            int vopcode = -1;
            if (operation == '+') vopcode = 0x29;
            else if (operation == '-') vopcode = 0x2A;
            else if (operation == '*') vopcode = 0x2B;
            if (vopcode < 0 || dest < 0 || dest > 31 || src1 < 0 || src1 > 31 || constant < 0 || constant > 255)
            {
                printf("Error: Invalid vector constant operation.\n");
                fclose(input); fclose(output); return;
            }
            fprintf(output, "%02X %02X %02X %02X\n", vopcode, dest, src1, constant);
            current_address += 4;
            continue;
        }

        /* =====================================================
           DATA MOVEMENT

           x1 = 100

           Opcode = 0x0F

           Format:

           opcode dest 0 constant

           0F 01 00 64
           ===================================================== */

        if (sscanf(line, "x%d = %d",
                   &dest,
                   &constant) == 2)
        {
            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    0x0F,
                    dest,
                    0,
                    constant);

            current_address += 4;
            continue;
        }

        /* =====================================================
           ARITHMETIC WITH VARIABLE

           x1 = x2 + x3

           ADD = 01
           SUB = 02
           MUL = 03
           DIV = 04
           ===================================================== */

        if (sscanf(line,
                   "x%d = x%d %c x%d",
                   &dest,
                   &src1,
                   &operation,
                   &src2) == 4)
        {
            int opcode = 0;

            switch (operation)
            {
            case '+':
                opcode = 0x01;
                break;

            case '-':
                opcode = 0x02;
                break;

            case '*':
                opcode = 0x03;
                break;

            case '/':
                opcode = 0x04;
                break;

            default:
                printf(
                    "Error: Unsupported operator %c\n",
                    operation);

                fclose(input);
                fclose(output);

                return;
            }

            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    opcode,
                    dest,
                    src1,
                    src2);
            current_address += 4;
            continue;
        }

        /* =====================================================
           ARITHMETIC WITH CONSTANT

           x1 = x2 + 10

           ADD constant = 09
           SUB constant = 0A
           MUL constant = 0B
           DIV constant = 0C
           ===================================================== */

        if (sscanf(line,
                   "x%d = x%d %c %d",
                   &dest,
                   &src1,
                   &operation,
                   &constant) == 4)
        {
            int opcode = 0;

            switch (operation)
            {
            case '+':
                opcode = 0x09;
                break;

            case '-':
                opcode = 0x0A;
                break;

            case '*':
                opcode = 0x0B;
                break;

            case '/':
                opcode = 0x0C;
                break;

            default:
                printf(
                    "Error: Unsupported operator %c\n",
                    operation);

                fclose(input);
                fclose(output);

                return;
            }

            fprintf(output,
                    "%02X %02X %02X %02X\n",
                    opcode,
                    dest,
                    src1,
                    constant);
            current_address += 4;
            continue;
        }

        /* ============================================================
         * BRANCH INSTRUCTIONS
         * ============================================================
         */

        char branch_condition[10];
        char label_name[50];

        /*
         * Try to parse:
         *
         * BEQ .loop
         * BGE .exit
         * BAL .loop
         */

        if (sscanf(line, "%s %s", branch_condition, label_name) == 2)
        {
            int branch_opcode = -1;

            if (strcmp(branch_condition, "BEQ") == 0)
                branch_opcode = 0x10;

            else if (strcmp(branch_condition, "BNE") == 0)
                branch_opcode = 0x11;

            else if (strcmp(branch_condition, "BCS") == 0)
                branch_opcode = 0x12;

            else if (strcmp(branch_condition, "BCC") == 0)
                branch_opcode = 0x13;

            else if (strcmp(branch_condition, "BMI") == 0)
                branch_opcode = 0x14;

            else if (strcmp(branch_condition, "BPL") == 0)
                branch_opcode = 0x15;

            else if (strcmp(branch_condition, "BVS") == 0)
                branch_opcode = 0x16;

            else if (strcmp(branch_condition, "BVC") == 0)
                branch_opcode = 0x17;

            else if (strcmp(branch_condition, "BHI") == 0)
                branch_opcode = 0x18;

            else if (strcmp(branch_condition, "BLS") == 0)
                branch_opcode = 0x19;

            else if (strcmp(branch_condition, "BGE") == 0)
                branch_opcode = 0x1A;

            else if (strcmp(branch_condition, "BLT") == 0)
                branch_opcode = 0x1B;

            else if (strcmp(branch_condition, "BGT") == 0)
                branch_opcode = 0x1C;

            else if (strcmp(branch_condition, "BLE") == 0)
                branch_opcode = 0x1D;

            else if (strcmp(branch_condition, "BAL") == 0)
                branch_opcode = 0x1E;

            if (branch_opcode != -1)
            {
                int target_address = find_label(label_name);

                if (target_address == -1)
                {
                    printf("Error: Label %s not found.\n",
                           label_name);

                    fclose(input);
                    fclose(output);

                    return;
                }

                /*
                 * PC after fetch already points to
                 * the next instruction.
                 *
                 * Therefore:
                 *
                 * relative offset =
                 * target - current_instruction_address
                 */

                int offset = target_address - (current_address + 4);

                printf("BRANCH: %s -> target=%d current=%d offset=%d\n",
                       label_name,
                       target_address,
                       current_address,
                       offset);

                /*
                 * Offset must fit into one signed byte.
                 */

                if (offset < -128 || offset > 127)
                {
                    printf("Error: Branch offset out of range.\n");

                    fclose(input);
                    fclose(output);

                    return;
                }

                fprintf(output,
                        "%02X 00 00 %02X\n",
                        branch_opcode,
                        (unsigned char)offset);

                current_address += 4;

                continue;
            }
        }

        /*
         * If no instruction matched,
         * report the line.
         */

        printf(
            "Warning: Could not compile line: %s\n",
            line);
    }

    /* =========================================================
       HALT

       00 00 00 00
       ========================================================= */

    fprintf(output,
            "00 00 00 00\n");

    fclose(input);
    fclose(output);

    printf("Compilation Successful.\n");
}
