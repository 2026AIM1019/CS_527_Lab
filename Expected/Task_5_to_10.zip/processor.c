/*
 * Processor implementation.
 *
 * This file contains both the architectural ISA execution and the simulated
 * microarchitectural structures (TLB, cache and five-stage timing model).
 * Keeping them together makes it easy to compare functional behaviour with
 * the timing counters produced by the same instruction stream.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <string.h>
#include <time.h>
#include "processor.h"

/* -------------------------------------------------------------------------
 * CPU state
 * -------------------------------------------------------------------------
 *
 * Every processor slot owns a complete register context.  Consequently the
 * OS can suspend a process and later resume it without copying the context
 * into a separate kernel structure: the context stays in the slot until the
 * process is dispatched again.  The statistics below are deliberately kept
 * per slot so that the performance utility can compare processes.
 */
int32_t Register[NP][256];
int32_t VectorRegister[NP][32][8];
int PC[NP];
int opcode, dest, src1, src2;
int Z[NP], N[NP], C[NP], V[NP];
int process_pid[NP];
int end_of_simulation[NP];
int proc_id = 0;
FILE *fd_log = NULL;

#define TLB_ENTRIES 8
#define CACHE_LINES 16
#define CACHE_LINE_SIZE 16
#define PIPELINE_STAGES 5

typedef struct {
    int valid;
    int pid;
    int logical_page;
    int frame;
} TLBEntry;

typedef struct {
    int valid;
    int pid;
    int tag;
    unsigned char data[CACHE_LINE_SIZE];
    unsigned long last_used;
} CacheLine;

static TLBEntry tlb[NP][TLB_ENTRIES];
static CacheLine cache_data[NP][CACHE_LINES];
static unsigned long cache_clock[NP];
static ProcessorStats stats[NP];

static unsigned long now_ns(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (unsigned long)ts.tv_sec * 1000000000UL + (unsigned long)ts.tv_nsec;
}

void processor_stats_reset(int id)
{
    if (id < 0 || id >= NP) return;
    memset(&stats[id], 0, sizeof(stats[id]));
    memset(tlb[id], 0, sizeof(tlb[id]));
    memset(cache_data[id], 0, sizeof(cache_data[id]));
    cache_clock[id] = 0;
}

const ProcessorStats *processor_get_stats(int id)
{
    return (id >= 0 && id < NP) ? &stats[id] : NULL;
}

void processor_invalidate_translation_cache(int id)
{
    if (id >= 0 && id < NP) memset(tlb[id], 0, sizeof(tlb[id]));
}

void processor_invalidate_cache(int id)
{
    if (id >= 0 && id < NP) memset(cache_data[id], 0, sizeof(cache_data[id]));
}

static void update_ZN(int id, int32_t r)
{
    Z[id] = (r == 0);
    N[id] = (((uint32_t)r & 0x80000000U) != 0);
}

static void update_add_flags(int id, int32_t a, int32_t b, int32_t r)
{
    uint32_t ua=(uint32_t)a, ub=(uint32_t)b, ur=(uint32_t)r;
    update_ZN(id,r);
    C[id]=(ur<ua || ur<ub);
    V[id]=((a>=0 && b>=0 && r<0) || (a<0 && b<0 && r>=0));
}

static void update_sub_flags(int id, int32_t a, int32_t b, int32_t r)
{
    update_ZN(id,r);
    C[id]=(a>b);
    V[id]=((a>=0 && b<0 && r<0) || (a<0 && b>=0 && r>=0));
}

static int branch_condition(int id, int op)
{
    switch(op) {
        case 0x10:return Z[id]==1; case 0x11:return Z[id]==0;
        case 0x12:return C[id]==1; case 0x13:return C[id]==0;
        case 0x14:return N[id]==1; case 0x15:return N[id]==0;
        case 0x16:return V[id]==1; case 0x17:return V[id]==0;
        case 0x18:return C[id]==1&&Z[id]==0; case 0x19:return C[id]==0||Z[id]==1;
        case 0x1A:return N[id]==V[id]; case 0x1B:return N[id]!=V[id];
        case 0x1C:return Z[id]==0&&N[id]==V[id]; case 0x1D:return Z[id]==1||N[id]!=V[id];
        case 0x1E:return 1;
        default:return 0;
    }
}

void reset(int id)
{
    if(id<0||id>=NP) return;
    memset(Register[id],0,sizeof(Register[id]));
    memset(VectorRegister[id],0,sizeof(VectorRegister[id]));
    PC[id]=0;
    end_of_simulation[id]=0;
    Z[id]=N[id]=C[id]=V[id]=0;
    process_pid[id]=0;
    processor_stats_reset(id);
}

/*
 * A tiny 8-entry fully-associative TLB.
 *
 * The PID is part of the tag.  This is important: logical page 0 belonging
 * to PID 3 must never accidentally reuse PID 4's translation.
 */
static int tlb_lookup(int id, int pid, int logical_page, int *frame)
{
    for (int i=0;i<TLB_ENTRIES;i++) {
        if (tlb[id][i].valid && tlb[id][i].pid==pid &&
            tlb[id][i].logical_page==logical_page) {
            *frame=tlb[id][i].frame;
            stats[id].tlb_hits++;
            return 1;
        }
    }
    stats[id].tlb_misses++;
    return 0;
}

static void tlb_insert(int id, int pid, int logical_page, int frame)
{
    int victim=0;
    for(int i=0;i<TLB_ENTRIES;i++) if(!tlb[id][i].valid){victim=i;break;}
    tlb[id][victim]=(TLBEntry){1,pid,logical_page,frame};
}

/* Translate once through the TLB. Permission checks remain in the memory
 * manager because a stale TLB must not become a way to bypass protection. */
static int cpu_translate(int id, int logical, MemoryAccess access)
{
    int page = (access==ACCESS_EXEC) ? logical/PAGESIZE :
               logical/PAGESIZE + INSTRUCTION_LOGICAL_SIZE/PAGESIZE;
    int offset=logical%PAGESIZE;
    int frame=-1;
    int pid=process_pid[id];

    if (page<0 || page>=NUM_LOGICAL_PAGES) return -1;
    if (!tlb_lookup(id,pid,page,&frame)) {
        int p=translate_address(id,logical,access);
        if(p<0) return -1;
        frame=p/PAGESIZE;
        tlb_insert(id,pid,page,frame);
    } else {
        /* Check the current PTE permissions even on a TLB hit. */
        int p=translate_address(id,logical,access);
        if(p<0) return -1;
    }
    return frame*PAGESIZE+offset;
}

/* Direct-mapped write-through cache.  Physical address is part of the tag,
 * while PID is also retained to make the cache safe if a frame is recycled. */
static int cache_index(int physical) { return (physical/CACHE_LINE_SIZE)%CACHE_LINES; }
static int cache_tag(int physical) { return physical/CACHE_LINE_SIZE; }

static unsigned char cache_read_byte(int id, int physical)
{
    int idx=cache_index(physical), tag=cache_tag(physical), off=physical%CACHE_LINE_SIZE;
    CacheLine *line=&cache_data[id][idx];
    stats[id].memory_accesses++;
    if(line->valid && line->pid==process_pid[id] && line->tag==tag) {
        stats[id].cache_hits++;
        return line->data[off];
    }
    stats[id].cache_misses++;
    line->valid=1; line->pid=process_pid[id]; line->tag=tag; line->last_used=++cache_clock[id];
    for(int i=0;i<CACHE_LINE_SIZE;i++) {
        int p=(physical/CACHE_LINE_SIZE)*CACHE_LINE_SIZE+i;
        line->data[i]=(p>=0&&p<MEMSIZE)?memory[p]:0;
    }
    return line->data[off];
}

static void cache_write_byte(int id, int physical, unsigned char value)
{
    int idx=cache_index(physical), tag=cache_tag(physical), off=physical%CACHE_LINE_SIZE;
    CacheLine *line=&cache_data[id][idx];
    stats[id].memory_accesses++;
    if(!(line->valid && line->pid==process_pid[id] && line->tag==tag)) {
        stats[id].cache_misses++;
        line->valid=1; line->pid=process_pid[id]; line->tag=tag; line->last_used=++cache_clock[id];
        for(int i=0;i<CACHE_LINE_SIZE;i++) {
            int p=(physical/CACHE_LINE_SIZE)*CACHE_LINE_SIZE+i;
            line->data[i]=(p>=0&&p<MEMSIZE)?memory[p]:0;
        }
    } else stats[id].cache_hits++;
    line->data[off]=value;
    /* Write-through keeps physical memory immediately coherent for other
     * processors and for the OS page-management code. */
    memory[physical]=value;
}

void fetch(int id)
{
    int p[4];
    proc_id=id;
    if(PC[id]<0 || PC[id]+3>=INSTRUCTION_LOGICAL_SIZE){end_of_simulation[id]=1;return;}
    for(int i=0;i<4;i++) {
        p[i]=cpu_translate(id,PC[id]+i,ACCESS_EXEC);
        if(p[i]<0){end_of_simulation[id]=1;return;}
    }
    opcode=cache_read_byte(id,p[0]);
    dest=cache_read_byte(id,p[1]);
    src1=cache_read_byte(id,p[2]);
    src2=cache_read_byte(id,p[3]);
    PC[id]+=4;
}

void decode(void) { /* The ISA is fixed-width; fetch already extracted fields. */ }

static void log_print(int id,int reg)
{
    if(fd_log){
        fprintf(fd_log,"[PRINT] Process id: %d : x%d : %08X\n",process_pid[id],reg,(uint32_t)Register[id][reg]);
        fflush(fd_log);
    }
}
void set_processor_pid(int id,int pid)
{
    if(id>=0&&id<NP) { process_pid[id]=pid; processor_invalidate_translation_cache(id); processor_invalidate_cache(id); }
}

void execute(int id)
{
    int32_t a,b,r; int i,address,taken;
    proc_id=id;
    switch(opcode){
    case 0x00:end_of_simulation[id]=1;break;
    case 0x01:a=Register[id][src1];b=Register[id][src2];r=a+b;Register[id][dest]=r;update_add_flags(id,a,b,r);break;
    case 0x02:a=Register[id][src1];b=Register[id][src2];r=a-b;Register[id][dest]=r;update_sub_flags(id,a,b,r);break;
    case 0x03:Register[id][dest]=Register[id][src1]*Register[id][src2];break;
    case 0x04:a=Register[id][src1];b=Register[id][src2];if(b==0||(a==INT32_MIN&&b==-1)){fprintf(stderr,"Process %d: invalid division\n",id);end_of_simulation[id]=1;}else Register[id][dest]=a/b;break;
    case 0x05:address=Register[id][src1];Register[id][dest]=read_memory_32(id,address);break;
    case 0x06:address=Register[id][src2];write_memory_32(id,address,Register[id][src1]);break;
    case 0x07:Register[id][dest]=Register[id][src1];break;
    case 0x08:log_print(id,src2);break;
    case 0x09:a=Register[id][src1];b=(unsigned char)src2;r=a+b;Register[id][dest]=r;update_add_flags(id,a,b,r);break;
    case 0x0A:a=Register[id][src1];b=(unsigned char)src2;r=a-b;Register[id][dest]=r;update_sub_flags(id,a,b,r);break;
    case 0x0B:Register[id][dest]=Register[id][src1]*(unsigned char)src2;break;
    case 0x0C:a=Register[id][src1];b=(unsigned char)src2;if(!b)end_of_simulation[id]=1;else Register[id][dest]=a/b;break;
    case 0x0D:Register[id][dest]=read_memory_32(id,src2);break;
    case 0x0E:write_memory_32(id,src2,Register[id][src1]);break;
    case 0x0F:Register[id][dest]=(unsigned char)src2;break;
    case 0x10:case 0x11:case 0x12:case 0x13:case 0x14:case 0x15:case 0x16:case 0x17:
    case 0x18:case 0x19:case 0x1A:case 0x1B:case 0x1C:case 0x1D:case 0x1E:
        stats[id].branch_count++;taken=branch_condition(id,opcode);if(taken){stats[id].branch_taken++;PC[id]+=(int8_t)src2;}break;
    case 0x21:case 0x22:case 0x23:
        for(i=0;i<8;i++) {
            VectorRegister[id][dest][i]=(opcode==0x21)?VectorRegister[id][src1][i]+VectorRegister[id][src2][i]:(opcode==0x22)?VectorRegister[id][src1][i]-VectorRegister[id][src2][i]:VectorRegister[id][src1][i]*VectorRegister[id][src2][i];
        }
        break;
    case 0x29:case 0x2A:case 0x2B:b=(unsigned char)src2;for(i=0;i<8;i++)VectorRegister[id][dest][i]=(opcode==0x29)?VectorRegister[id][src1][i]+b:(opcode==0x2A)?VectorRegister[id][src1][i]-b:VectorRegister[id][src1][i]*b;break;
    case 0x25:address=Register[id][src1];for(i=0;i<8;i++)VectorRegister[id][dest][i]=read_memory_32(id,address+4*i);break;
    case 0x2C:address=src2;for(i=0;i<8;i++)VectorRegister[id][dest][i]=read_memory_32(id,address+4*i);break;
    case 0x26:address=Register[id][src2];for(i=0;i<8;i++)write_memory_32(id,address+4*i,VectorRegister[id][src1][i]);break;
    case 0x2E:address=src2;for(i=0;i<8;i++)write_memory_32(id,address+4*i,VectorRegister[id][src1][i]);break;
    /* 0xF0 is compiler-generated shared-memory metadata. It is deliberately
     * a no-op at run time; the OS consumes it while loading the task. */
    case 0xF0:break;
    default:fprintf(stderr,"Process %d: unknown opcode 0x%02X\n",id,opcode);end_of_simulation[id]=1;break;
    }
}

int processor_cached_read32(int id, int address, int32_t *out)
{
    uint32_t value=0;
    if(!out || id<0 || id>=NP || address<0 || address+3>=DATA_LOGICAL_SIZE) return -1;
    for(int i=0;i<4;i++) {
        int p=cpu_translate(id,address+i,ACCESS_READ);
        if(p<0) return -1;
        value |= (uint32_t)cache_read_byte(id,p) << (8*i);
    }
    *out=(int32_t)value;
    return 0;
}

int processor_cached_write32(int id, int address, int32_t value)
{
    uint32_t v=(uint32_t)value;
    if(id<0||id>=NP||address<0||address+3>=DATA_LOGICAL_SIZE) return -1;
    for(int i=0;i<4;i++) {
        int p=cpu_translate(id,address+i,ACCESS_WRITE);
        if(p<0) return -1;
        cache_write_byte(id,p,(unsigned char)((v>>(8*i))&0xff));
    }
    return 0;
}

void process_instructions(int id,int instruction_count)
{
    unsigned long start=now_ns();
    if(id<0||id>=NP)return;
    for(int i=0;i<instruction_count&&!end_of_simulation[id];i++){
        /* A five-stage pipeline has four fill cycles. After the pipeline is
         * full, one instruction can retire each cycle. Data-cache/TLB misses
         * are modelled as stalls. This keeps the architectural execution
         * deterministic while exposing realistic timing effects. */
        fetch(id);
        if(end_of_simulation[id])break;
        decode();execute(id);
        stats[id].instructions++;
        stats[id].pipeline_cycles += 1;
        stats[id].total_cycles += 1;
        stats[id].pipeline_stalls += (stats[id].tlb_misses ? 0 : 0);
    }
    /* Pipeline fill/drain overhead is charged once per scheduling slice. */
    if(stats[id].instructions) stats[id].pipeline_cycles += PIPELINE_STAGES-1;
    stats[id].total_cycles += (PIPELINE_STAGES-1);
    stats[id].total_cycles += (stats[id].tlb_misses + stats[id].cache_misses)*5;
    stats[id].pipeline_stalls += (stats[id].tlb_misses + stats[id].cache_misses)*5;
    stats[id].wall_ns += now_ns()-start;
    { struct timespec ts={0,10000}; nanosleep(&ts,NULL); }
}

void processor_dump_stats(FILE *out,int id)
{
    const ProcessorStats *s=processor_get_stats(id);
    if(!out||!s)return;
    fprintf(out,"PID %d / processor %d\n",process_pid[id],id);
    fprintf(out,"  instructions       : %lu\n",s->instructions);
    fprintf(out,"  cycles             : %lu\n",s->total_cycles);
    fprintf(out,"  pipeline cycles    : %lu\n",s->pipeline_cycles);
    fprintf(out,"  pipeline stalls    : %lu\n",s->pipeline_stalls);
    fprintf(out,"  TLB hits/misses    : %lu / %lu\n",s->tlb_hits,s->tlb_misses);
    fprintf(out,"  cache hits/misses  : %lu / %lu\n",s->cache_hits,s->cache_misses);
    fprintf(out,"  memory accesses    : %lu\n",s->memory_accesses);
    fprintf(out,"  branches/taken     : %lu / %lu\n",s->branch_count,s->branch_taken);
    fprintf(out,"  wall time (us)     : %.2f\n",s->wall_ns/1000.0);
}
