# Virtual-register allocation report

The compiler treats `rN` as a virtual integer register. `first` and `last` are bytecode addresses of its live interval.

| Virtual | First | Last | Uses | Physical colour | Spill |
|---:|---:|---:|---:|---:|:---:|

## Algorithm

1. Scan the source and record first/last use (liveness intervals).
2. Colour overlapping intervals with different physical registers.
3. Choose the lowest free colour, making the result deterministic.
4. Intervals for which all 256 colours are occupied are marked as spill candidates.

Spill candidates are intentionally reported rather than silently corrupting a program; the supplied ISA has no dedicated stack/spill opcode, so the OS data space is the natural location for a future spill pass.

Spill candidates: 0
