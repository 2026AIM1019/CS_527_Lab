/*
 * Physical memory and MMU implementation for the extended CS527 machine.
 *
 * A useful mental model is: logical address -> PTE in physical frame 0 ->
 * physical frame + offset -> cache/RAM.  Permissions are checked during the
 * translation so the page table is also the protection boundary.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/select.h>
#include "memory.h"
#include "processor.h"

/*
 * Physical memory is the ONLY byte-addressable storage used by the CPU.
 *
 * Frame 0 is special: it contains the page tables.  This is deliberately
 * different from the earlier Lab-5 implementation where pageTable[][] was
 * an ordinary C array owned by the OS.  A real MMU would fetch PTEs from
 * memory, and this version follows that idea.
 */
unsigned char memory[MEMSIZE];

/* Reference count for each physical frame.  The page table itself lives in
 * frame 0, so frame 0 is never given to a process.  Shared frames can have
 * more than one mapping. */
static unsigned char frame_used[NUM_PHYSICAL_PAGES];
static unsigned short frame_refcount[NUM_PHYSICAL_PAGES];

/* Eight data pages + two instruction pages = ten PTE bytes per process. */
#define PT_BYTES_PER_PROCESS NUM_LOGICAL_PAGES
#define PT_OFFSET(pid, page) ((pid) * PT_BYTES_PER_PROCESS + (page))

static unsigned char *pte_ptr(int proc_id, int page)
{
    if (proc_id < 0 || proc_id >= NP || page < 0 || page >= NUM_LOGICAL_PAGES)
        return NULL;
    return &memory[PT_OFFSET(proc_id, page)];
}

static int page_index(int isFetch, int address)
{
    if (address < 0) return -1;
    return isFetch
        ? address / PAGESIZE
        : address / PAGESIZE + INSTRUCTION_LOGICAL_SIZE / PAGESIZE;
}

static int page_entry_frame(unsigned char pte)
{
    return (int)(pte & PTE_FRAME_MASK);
}

void memory_system_init(void)
{
    memset(memory, 0, sizeof(memory));
    memset(frame_used, 0, sizeof(frame_used));
    memset(frame_refcount, 0, sizeof(frame_refcount));

    /* Frame 0 is the physical page-table frame and belongs to the OS. */
    frame_used[0] = 1;
    frame_refcount[0] = 1;
}

int get_page_frame(int proc_id, int logical_page_index)
{
    unsigned char *pte = pte_ptr(proc_id, logical_page_index);
    return pte ? page_entry_frame(*pte) : -1;
}

unsigned char get_page_entry(int proc_id, int logical_page_index)
{
    unsigned char *pte = pte_ptr(proc_id, logical_page_index);
    return pte ? *pte : 0;
}

/*
 * Allocate the first free physical frame.
 *
 * Frame 0 is intentionally skipped.  The function is small, but keeping it
 * centralised makes the memory manager much easier to reason about.
 */
int getFreePage(void)
{
    for (int frame = 1; frame < NUM_PHYSICAL_PAGES; ++frame) {
        if (!frame_used[frame]) {
            frame_used[frame] = 1;
            frame_refcount[frame] = 1;
            memset(memory + frame * PAGESIZE, 0, PAGESIZE);
            return frame;
        }
    }
    fprintf(stderr, "ERROR: No free physical frame available\n");
    return -1;
}

static void retain_frame(int frame)
{
    if (frame > 0 && frame < NUM_PHYSICAL_PAGES) {
        frame_used[frame] = 1;
        ++frame_refcount[frame];
    }
}

static void release_frame(int frame)
{
    if (frame <= 0 || frame >= NUM_PHYSICAL_PAGES) return;
    if (frame_refcount[frame] > 0) --frame_refcount[frame];
    if (frame_refcount[frame] == 0) {
        frame_used[frame] = 0;
        memset(memory + frame * PAGESIZE, 0, PAGESIZE);
    }
}

void releaseProcessPages(int proc_id)
{
    if (proc_id < 0 || proc_id >= NP) return;

    for (int page = 0; page < NUM_LOGICAL_PAGES; ++page) {
        unsigned char *pte = pte_ptr(proc_id, page);
        int frame = page_entry_frame(*pte);
        if (frame > 0) release_frame(frame);
        *pte = 0;
    }
}

/*
 * Translate a logical address.
 *
 * access=EXEC is used for instruction fetches, READ for loads, and WRITE for
 * stores.  The permission bits therefore become a real protection boundary
 * rather than merely information printed in a diagnostic table.
 */
int translate_address(int proc_id, int address, MemoryAccess access)
{
    int isFetch = (access == ACCESS_EXEC);
    int page;
    int offset;
    int frame;
    unsigned char pte;
    unsigned char required;

    if (proc_id < 0 || proc_id >= NP || address < 0) {
        fprintf(stderr, "MMU ERROR: invalid process/address (%d, %d)\n", proc_id, address);
        return -1;
    }

    if (isFetch) {
        if (address >= INSTRUCTION_LOGICAL_SIZE) {
            fprintf(stderr, "MMU ERROR: instruction address %d out of range\n", address);
            return -1;
        }
    } else if (address >= DATA_LOGICAL_SIZE) {
        fprintf(stderr, "MMU ERROR: data address %d out of range\n", address);
        return -1;
    }

    page = page_index(isFetch, address);
    if (page < 0 || page >= NUM_LOGICAL_PAGES) return -1;

    pte = get_page_entry(proc_id, page);
    frame = page_entry_frame(pte);
    if (frame <= 0 || frame >= NUM_PHYSICAL_PAGES) {
        fprintf(stderr, "MMU ERROR: PID slot %d page %d is unmapped\n", proc_id, page);
        return -1;
    }

    required = (access == ACCESS_EXEC) ? PTE_EXEC :
               (access == ACCESS_WRITE ? PTE_WRITE : PTE_READ);
    if ((pte & required) == 0) {
        fprintf(stderr, "MMU PROTECTION ERROR: slot=%d page=%d access=%s\n",
                proc_id, page,
                access == ACCESS_EXEC ? "EXEC" :
                access == ACCESS_WRITE ? "WRITE" : "READ");
        return -1;
    }

    offset = address % PAGESIZE;
    return frame * PAGESIZE + offset;
}

int getPhysicallAddress(int proc_id, int isFetch, int address)
{
    return translate_address(proc_id, address, isFetch ? ACCESS_EXEC : ACCESS_READ);
}

/* Read one byte from a text file containing hexadecimal byte values. */
static int load_region(int proc_id, const char *file_name,
                       int isFetch, int max_bytes)
{
    FILE *fp = fopen(file_name, "r");
    int value;
    int logical_offset = 0;
    int previous_page = -1;

    if (!fp) {
        fprintf(stderr, "OS: cannot open %s\n", file_name);
        return -1;
    }

    while (logical_offset < max_bytes && fscanf(fp, "%x", &value) == 1) {
        int page = page_index(isFetch, logical_offset);
        unsigned char *pte = pte_ptr(proc_id, page);
        int frame;
        int physical;

        if (!pte || page < 0 || page >= NUM_LOGICAL_PAGES) {
            fclose(fp);
            return -1;
        }

        /* Allocate one frame when the logical address enters a new page. */
        if (page != previous_page && page_entry_frame(*pte) == 0) {
            frame = getFreePage();
            if (frame < 0) {
                fclose(fp);
                return -2;
            }
            *pte = (unsigned char)frame |
                   (isFetch ? (PTE_READ | PTE_EXEC) : (PTE_READ | PTE_WRITE));
            previous_page = page;
        }

        physical = translate_address(proc_id, logical_offset,
                                     isFetch ? ACCESS_EXEC : ACCESS_WRITE);
        if (physical < 0) {
            fclose(fp);
            return -1;
        }
        memory[physical] = (unsigned char)value;
        ++logical_offset;
    }

    fclose(fp);
    return logical_offset;
}

int initialize(int proc_id, const char *program_file, const char *data_file)
{
    int rc;
    if (proc_id < 0 || proc_id >= NP) return -1;

    releaseProcessPages(proc_id);

    rc = load_region(proc_id, program_file, 1, INSTRUCTION_LOGICAL_SIZE);
    if (rc < 0) {
        releaseProcessPages(proc_id);
        return rc;
    }
    rc = load_region(proc_id, data_file, 0, DATA_LOGICAL_SIZE);
    if (rc < 0) {
        releaseProcessPages(proc_id);
        return rc;
    }
    return 0;
}

int finalize(int proc_id, const char *data_file)
{
    FILE *fp;
    if (proc_id < 0 || proc_id >= NP) return -1;

    fp = fopen(data_file, "w");
    if (!fp) {
        fprintf(stderr, "OS: cannot write data %s\n", data_file);
        return -1;
    }

    /* Reconstruct the logical data space one byte at a time. */
    for (int logical = 0; logical < DATA_LOGICAL_SIZE; ++logical) {
        int page = page_index(0, logical);
        int frame = get_page_frame(proc_id, page);
        int physical = frame > 0 ? frame * PAGESIZE + (logical % PAGESIZE) : -1;
        unsigned char value = physical >= 0 ? memory[physical] : 0;
        fprintf(fp, "%02X%s", value, (logical % 4 == 3) ? "\n" : " ");
    }
    fclose(fp);

    releaseProcessPages(proc_id);
    return 0;
}

int32_t read_memory_32(int proc_id, int address)
{
    int32_t value=0;
    if(memory_is_mmio(address)) return mmio_read(proc_id,address);
    if(processor_cached_read32(proc_id,address,&value)!=0){
        fprintf(stderr,"Memory read error: proc=%d address=%d\n",proc_id,address);
        return 0;
    }
    return value;
}

void write_memory_32(int proc_id, int address, int32_t value)
{
    if(memory_is_mmio(address)){mmio_write(proc_id,address,value);return;}
    if(processor_cached_write32(proc_id,address,value)!=0)
        fprintf(stderr,"Memory write error: proc=%d address=%d\n",proc_id,address);
}

/*
 * Shared memory is represented by making multiple PTEs point at the same
 * physical frame.  The reference count prevents one process from freeing a
 * frame that another process is still using.
 */
int memory_share_region(int proc_id, int logical_address, int size, int writable)
{
    int first_page, pages;
    if (proc_id < 0 || proc_id >= NP || logical_address < 0 || size <= 0)
        return -1;
    if (logical_address >= DATA_LOGICAL_SIZE) return -1;

    first_page = logical_address / PAGESIZE + INSTRUCTION_LOGICAL_SIZE / PAGESIZE;
    pages = (size + PAGESIZE - 1) / PAGESIZE;
    if (first_page + pages > NUM_LOGICAL_PAGES) return -1;

    /*
     * This API is used after a process has been loaded.  For a first owner,
     * the existing private frames simply become shared.  For later owners,
     * the caller can pass the same logical range and the OS-level sharing
     * code will replace the private frame with the owner's frame.
     */
    for (int i = 0; i < pages; ++i) {
        unsigned char *pte = pte_ptr(proc_id, first_page + i);
        if (!pte) return -1;
        /* A shared declaration is also a request to create the page if the
         * input data file did not contain bytes for that page.  The new page
         * is zero-filled by getFreePage(), just like normal data memory. */
        if (page_entry_frame(*pte) == 0) {
            int frame=getFreePage();
            if(frame<0) return -1;
            *pte=(unsigned char)frame | PTE_READ | PTE_WRITE;
        }
        *pte |= PTE_SHARED | PTE_READ;
        if (writable) *pte |= PTE_WRITE;
        else *pte &= (unsigned char)~PTE_WRITE;
    }
    return 0;
}

int memory_map_shared_page(int proc_id, int logical_page_index, int frame, int writable)
{
    unsigned char *pte = pte_ptr(proc_id, logical_page_index);
    if (!pte || frame <= 0 || frame >= NUM_PHYSICAL_PAGES || !frame_used[frame]) return -1;
    /* Drop the process's old private reference before acquiring the shared one. */
    int old = page_entry_frame(*pte);
    if (old == frame) { *pte |= PTE_SHARED | PTE_READ; if (writable) *pte |= PTE_WRITE; return 0; }
    if (old > 0) release_frame(old);
    retain_frame(frame);
    *pte = (unsigned char)frame | PTE_READ | PTE_SHARED | (writable ? PTE_WRITE : 0);
    return 0;
}

int memory_is_shared(int proc_id, int logical_address)
{
    int page = page_index(0, logical_address);
    return page >= 0 && page < NUM_LOGICAL_PAGES &&
           (get_page_entry(proc_id, page) & PTE_SHARED) != 0;
}

int memory_is_mmio(int address)
{
    return (address >= MMIO_BASE && address < MMIO_BASE + 0x20) || address == MMIO_PID;
}

int32_t mmio_read(int proc_id, int address)
{
    if (address == MMIO_STATUS) {
        /* Bit 0 says that at least one input byte is ready. */
        fd_set set;
        struct timeval tv = {0, 0};
        FD_ZERO(&set);
        FD_SET(STDIN_FILENO, &set);
        return select(STDIN_FILENO + 1, &set, NULL, NULL, &tv) > 0 ? 1 : 0;
    }
    if (address == MMIO_INPUT) {
        unsigned char ch;
        if (read(STDIN_FILENO, &ch, 1) == 1) return ch;
        return 0;
    }
    if (address == MMIO_TIMER) return (int32_t)clock();
    if (address == MMIO_PID) return proc_id;
    return 0;
}

void mmio_write(int proc_id, int address, int32_t value)
{
    (void)proc_id;
    if (address == MMIO_OUTPUT) {
        putchar((unsigned char)value);
        fflush(stdout);
    }
}

void dump_memory_map(FILE *out)
{
    if (!out) return;
    fprintf(out, "Physical memory map: %d bytes, %d-byte frames\n", MEMSIZE, PAGESIZE);
    fprintf(out, "Frame 0: RESERVED (page tables)\n");
    for (int frame = 1; frame < NUM_PHYSICAL_PAGES; ++frame) {
        fprintf(out, "Frame %2d: %s, references=%u\n", frame,
                frame_used[frame] ? "ALLOCATED" : "FREE",
                frame_refcount[frame]);
    }
}

void dump_process_memory_map(FILE *out, int proc_id, int pid)
{
    if (!out || proc_id < 0 || proc_id >= NP) return;
    fprintf(out, "PID %d (processor slot %d) page table\n", pid, proc_id);
    for (int page = 0; page < NUM_LOGICAL_PAGES; ++page) {
        unsigned char pte = get_page_entry(proc_id, page);
        int frame = page_entry_frame(pte);
        if (frame) {
            fprintf(out, "  LPage %2d -> Frame %2d  [%c%c%c]%s\n", page, frame,
                    (pte & PTE_READ) ? 'R' : '-',
                    (pte & PTE_WRITE) ? 'W' : '-',
                    (pte & PTE_EXEC) ? 'X' : '-',
                    (pte & PTE_SHARED) ? " SHARED" : "");
        } else {
            fprintf(out, "  LPage %2d -> UNMAPPED\n", page);
        }
    }
}
