/*
 * Extended CS527 operating system.
 *
 * The OS is intentionally written as a small teaching kernel: it owns the
 * process table, chooses which PID receives a time slice, interprets compiler
 * metadata, and exposes diagnostic commands.  It does not execute user
 * instructions itself; that responsibility remains in processor.c.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>
#include <time.h>
#include <stdarg.h>
#include <ctype.h>
#include "os.h"
#include "compiler.h"
#include "memory.h"
#include "processor.h"

typedef enum { UNUSED=0, READY=1, RUNNING=2, WAITING=3 } State;

typedef struct {
    int pid;
    int proc_id;
    State state;
    char program_file[512];
    char data_file[512];
    char generated_program[512];
    unsigned long dispatches;
    unsigned long instructions;
} Task;

static Task tasks[MAX_PROCESSES];
static int next_pid=1;
static int proc_pid[NP];
static int shell_exit=0;
static char shell_line[1024];
static int shell_len=0;
static int prompt_shown=0;
static int demo_mode=0;
static unsigned long scheduler_round=0;

/*
 * Shared-region directory.  A region is identified by its logical data
 * address and page count.  Its first owner supplies the physical frame(s);
 * later owners map the same frames into their page tables.
 */
typedef struct { int valid; int logical_page; int pages; int frames[8]; int writable; int owner_pid; } SharedRegion;
static SharedRegion shared_regions[16];

/* Keep a small completed-process history so `perf` remains useful even
 * after a process has finished and its processor slot has been freed. */
typedef struct { int valid; int pid; ProcessorStats stats; } CompletedStats;
static CompletedStats completed[MAX_PROCESSES];

static void log_event(const char *fmt,...)
{
    if (!fd_log) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(fd_log, fmt, ap);
    va_end(ap);
    fflush(fd_log);
}
static void msleep(unsigned usec){struct timespec ts={usec/1000000U,(long)(usec%1000000U)*1000L};nanosleep(&ts,NULL);}
static int find_free_proc(void){for(int i=0;i<NP;i++)if(proc_pid[i]==0)return i;return -1;}
static Task *find_task(int pid){for(int i=0;i<MAX_PROCESSES;i++)if(tasks[i].state!=UNUSED&&tasks[i].pid==pid)return &tasks[i];return NULL;}
static int file_readable(const char *p){FILE*f=fopen(p,"r");if(!f)return 0;fclose(f);return 1;}
static int copy_file(const char*a,const char*b){FILE*x=fopen(a,"rb"),*y;char buf[4096];size_t n;if(!x)return 0;y=fopen(b,"wb");if(!y){fclose(x);return 0;}while((n=fread(buf,1,sizeof(buf),x))){if(fwrite(buf,1,n,y)!=n){fclose(x);fclose(y);return 0;}}fclose(x);fclose(y);return 1;}
static void sibling_path(const char *source,const char *name,char*out,size_t n){const char*s=strrchr(source,'/');if(s){size_t k=(size_t)(s-source);if(k+1+strlen(name)+1<=n){memcpy(out,source,k);out[k]='/';strcpy(out+k+1,name);return;}}snprintf(out,n,"%s",name);}

/*
 * Establish shared physical mappings after normal loading.  The first task
 * keeps its allocated frames; subsequent tasks drop their private mapping
 * and point at the owner's frames.  This is the key OS side of IPC.
 */
static void apply_shared_regions(int pid,int proc_id,const char *program)
{
    FILE*f=fopen(program,"r");int a,b,c,d;
    if(!f)return;
    while(fscanf(f,"%x %x %x %x",&a,&b,&c,&d)==4){
        if(a!=0xF0)continue;
        int first_data_page=b; int pages=c; int writable=(d&2)!=0;
        int logical=first_data_page*PAGESIZE;
        if(pages<=0||pages>8)continue;
        int r=-1;
        for(int i=0;i<16;i++)if(shared_regions[i].valid&&shared_regions[i].logical_page==first_data_page&&shared_regions[i].pages==pages){r=i;break;}
        if(r<0){
            for(int i=0;i<16;i++)if(!shared_regions[i].valid){r=i;break;}
            if(r<0)continue;
            shared_regions[r].valid=1;shared_regions[r].logical_page=first_data_page;shared_regions[r].pages=pages;shared_regions[r].writable=writable;shared_regions[r].owner_pid=pid;
            /* Ask the memory manager to create/mark the pages first.  This is
             * important when the data file does not contain bytes for the
             * declared shared page; the declaration itself must allocate it. */
            if (memory_share_region(proc_id,logical,pages*PAGESIZE,writable)!=0) {
                shared_regions[r].valid=0;
                continue;
            }
            for(int i=0;i<pages;i++)
                shared_regions[r].frames[i]=get_page_frame(proc_id,INSTRUCTION_LOGICAL_SIZE/PAGESIZE+first_data_page+i);
            log_event("[IPC] PID %d created shared region data=0x%X pages=%d\n",pid,logical,pages);
        }else{
            /* Map the same physical frame by changing PTE bytes indirectly
             * through the public helper.  We need the exact frame, so this
             * operation is implemented here using the page-entry interface. */
            int first=INSTRUCTION_LOGICAL_SIZE/PAGESIZE+first_data_page;
            for(int i=0;i<pages;i++){
                int old=get_page_frame(proc_id,first+i);
                int shared_frame=shared_regions[r].frames[i];
                if(old==shared_frame)continue;
                /* memory_share_region marks the page shared; replacing the
                 * PTE itself is exposed by memory_map_shared_page below. */
                memory_map_shared_page(proc_id,first+i,shared_frame,writable);
            }
            log_event("[IPC] PID %d joined shared region data=0x%X pages=%d owner=%d\n",pid,logical,pages,shared_regions[r].owner_pid);
        }
    }
    fclose(f);
}

void os_init(void)
{
    memset(tasks,0,sizeof(tasks));
    memset(proc_pid,0,sizeof(proc_pid));
    memset(shared_regions,0,sizeof(shared_regions));
    memset(completed,0,sizeof(completed));
    next_pid=1;shell_exit=0;shell_len=0;prompt_shown=0;scheduler_round=0;demo_mode=(getenv("OS_DEMO")!=NULL);
    memory_system_init();
    fd_log=fopen("process.log","w");
    if(fd_log){log_event("============================================================\n");log_event(" CS527 EXTENDED MINI-COMPUTER PROCESS LOG\n");log_event("============================================================\n");log_event("[OS] NP=%d TIME_SLICE=%d\n",NP,TIME_SLICE);}
}

int loader(const char *program_file,const char *data_file)
{
    int p=find_free_proc(),slot=-1;char generated[512]={0},program_byte[512];
    if(!program_file||!data_file||!*program_file||!*data_file)return -1;
    if(!file_readable(program_file)||!file_readable(data_file)){fprintf(stderr,"[Loader] Cannot open input file.\n");return -1;}
    if(next_pid>MAX_PROCESSES)return -1;
    for(int i=0;i<MAX_PROCESSES;i++)if(tasks[i].state==UNUSED){slot=i;break;}
    if(slot<0)return -1;
    const char*dot=strrchr(program_file,'.');int source=dot&&strcmp(dot,".txt")==0;
    if(source){
        sibling_path(program_file,"program.byte",program_byte,sizeof(program_byte));
        compile(program_file,program_byte);
        if (snprintf(generated,sizeof(generated),"%s.pid%d",program_byte,next_pid) >= (int)sizeof(generated)) {
            fprintf(stderr,"OS: generated bytecode path is too long\n");
            return -1;
        }
        if(!copy_file(program_byte,generated)) return -1;
        program_file=generated;
    }
    tasks[slot].pid=next_pid++;tasks[slot].proc_id=-1;tasks[slot].state=(p>=0)?RUNNING:WAITING;
    snprintf(tasks[slot].program_file,sizeof(tasks[slot].program_file),"%s",program_file);snprintf(tasks[slot].data_file,sizeof(tasks[slot].data_file),"%s",data_file);snprintf(tasks[slot].generated_program,sizeof(tasks[slot].generated_program),"%s",generated);
    if(p>=0 && initialize(p,program_file,data_file)==0){
        proc_pid[p]=tasks[slot].pid;tasks[slot].proc_id=p;reset(p);set_processor_pid(p,tasks[slot].pid);apply_shared_regions(tasks[slot].pid,p,program_file);
        printf("[OS] Loaded PID %d on processor %d\n",tasks[slot].pid,p);log_event("[STATE] PID %d -> RUNNING P%d\n",tasks[slot].pid,p);
    }else{
        tasks[slot].state=WAITING;printf("[OS] PID %d placed in WAITING queue\n",tasks[slot].pid);log_event("[STATE] PID %d -> WAITING\n",tasks[slot].pid);
    }
    fflush(stdout);return tasks[slot].pid;
}

static void promote_waiting(void)
{
    for(int p=0;p<NP;p++)if(proc_pid[p]==0)for(int i=0;i<MAX_PROCESSES;i++)if(tasks[i].state==WAITING){
        if(initialize(p,tasks[i].program_file,tasks[i].data_file)!=0)continue;
        proc_pid[p]=tasks[i].pid;tasks[i].proc_id=p;tasks[i].state=RUNNING;reset(p);set_processor_pid(p,tasks[i].pid);apply_shared_regions(tasks[i].pid,p,tasks[i].program_file);
        printf("[OS] Dispatched PID %d from WAITING queue to processor %d\n",tasks[i].pid,p);log_event("[STATE] PID %d WAITING -> RUNNING P%d\n",tasks[i].pid,p);break;
    }
}
static void reap_finished(void)
{
    for(int p=0;p<NP;p++)if(proc_pid[p]&&end_of_simulation[p]){
        Task*t=find_task(proc_pid[p]);if(!t){proc_pid[p]=0;continue;}
        /* Before releasing this task's pages, transfer ownership of any
         * shared region to another still-running mapper.  If nobody maps the
         * region, invalidate its directory entry so a future task becomes a
         * fresh owner instead of referencing a freed physical frame. */
        for (int r=0; r<16; ++r) {
            if (!shared_regions[r].valid || shared_regions[r].owner_pid != t->pid) continue;
            int new_owner=-1;
            for (int q=0; q<MAX_PROCESSES; ++q) {
                if (tasks[q].state!=UNUSED && tasks[q].pid!=t->pid && tasks[q].proc_id>=0 &&
                    memory_is_shared(tasks[q].proc_id, shared_regions[r].logical_page*PAGESIZE)) {
                    new_owner=tasks[q].pid; break;
                }
            }
            if (new_owner>0) shared_regions[r].owner_pid=new_owner;
            else shared_regions[r].valid=0;
        }
        finalize(p,t->data_file);
        /* Save performance counters before reset/reuse of this processor slot. */
        completed[t->pid-1].valid=1;
        completed[t->pid-1].pid=t->pid;
        completed[t->pid-1].stats=*processor_get_stats(p);
        printf("[OS] PID %d finished on processor %d\n",t->pid,p);
        log_event("[FINISH] PID %d P%d instructions=%lu\n",t->pid,p,processor_get_stats(p)->instructions);
        if (t->generated_program[0]) unlink(t->generated_program);
        t->state=UNUSED;
        t->proc_id=-1;
        proc_pid[p]=0;
    }
}

/* ----------------------------- Utilities ------------------------------ */
static void utility_memmap(void){FILE*f=fopen("memory_map.txt","w");if(!f)return;dump_memory_map(stdout);dump_memory_map(f);for(int i=0;i<NP;i++)if(proc_pid[i]){Task*t=find_task(proc_pid[i]);if(t)dump_process_memory_map(stdout,i,t->pid);}fclose(f);printf("[UTIL] memory_map.txt written.\n");}
static void utility_perf(void)
{
    FILE*f=fopen("performance.log","w");
    if(!f)return;
    fprintf(f,"# Process performance report\n");
    for(int p=0;p<NP;p++) if(proc_pid[p]) { processor_dump_stats(stdout,p); processor_dump_stats(f,p); }
    /* Completed records are also printed, making this a useful post-mortem tool. */
    for(int i=0;i<MAX_PROCESSES;i++) if(completed[i].valid) {
        fprintf(stdout,"PID %d (completed)\n  instructions=%lu cycles=%lu TLB=%lu/%lu cache=%lu/%lu pipeline_stalls=%lu\n",
                completed[i].pid,completed[i].stats.instructions,completed[i].stats.total_cycles,
                completed[i].stats.tlb_hits,completed[i].stats.tlb_misses,
                completed[i].stats.cache_hits,completed[i].stats.cache_misses,completed[i].stats.pipeline_stalls);
        fprintf(f,"PID %d (completed)\n  instructions=%lu\n  cycles=%lu\n  pipeline_cycles=%lu\n  pipeline_stalls=%lu\n  TLB hits/misses=%lu/%lu\n  cache hits/misses=%lu/%lu\n  memory accesses=%lu\n  branches/taken=%lu/%lu\n  wall_us=%.2f\n\n",
                completed[i].pid,completed[i].stats.instructions,completed[i].stats.total_cycles,
                completed[i].stats.pipeline_cycles,completed[i].stats.pipeline_stalls,
                completed[i].stats.tlb_hits,completed[i].stats.tlb_misses,
                completed[i].stats.cache_hits,completed[i].stats.cache_misses,completed[i].stats.memory_accesses,
                completed[i].stats.branch_count,completed[i].stats.branch_taken,completed[i].stats.wall_ns/1000.0);
    }
    fclose(f);printf("[UTIL] performance.log written.\n");
}
static void utility_cache(void){printf("[UTIL] Cache: 16 direct-mapped lines, 16 bytes/line, write-through.\n");for(int p=0;p<NP;p++)if(proc_pid[p]){const ProcessorStats*s=processor_get_stats(p);printf("  P%d PID%d hits=%lu misses=%lu\n",p,proc_pid[p],s->cache_hits,s->cache_misses);}}
static void utility_tlb(void){printf("[UTIL] TLB: 8 entries per processor, PID+logical-page tagged.\n");for(int p=0;p<NP;p++)if(proc_pid[p]){const ProcessorStats*s=processor_get_stats(p);printf("  P%d PID%d hits=%lu misses=%lu\n",p,proc_pid[p],s->tlb_hits,s->tlb_misses);}}
static void utility_help(void){printf("Commands: <program.txt> <data.byte>, memmap, perf, cache, tlb, help, exit\n");}

void shell(void)
{
    fd_set set;struct timeval tv={0,0};char ch;if(shell_exit)return;if(!prompt_shown){printf("$ ");fflush(stdout);prompt_shown=1;}
    FD_ZERO(&set);FD_SET(STDIN_FILENO,&set);if(select(STDIN_FILENO+1,&set,NULL,NULL,&tv)<=0)return;
    while(read(STDIN_FILENO,&ch,1)==1){if(ch=='\r')continue;if(ch!='\n'){if(shell_len<(int)sizeof(shell_line)-1)shell_line[shell_len++]=ch;continue;}
        shell_line[shell_len]='\0';char local[1024];snprintf(local,sizeof(local),"%s",shell_line);shell_len=0;char*s=local;while(isspace((unsigned char)*s))s++;if(*s=='$')s++;while(isspace((unsigned char)*s))s++;
        if(!strcmp(s,"exit")){shell_exit=1;printf("[OS] Shell exiting; existing tasks continue.\n");prompt_shown=0;return;}
        if(!strcmp(s,"memmap")){utility_memmap();prompt_shown=0;return;} if(!strcmp(s,"perf")){utility_perf();prompt_shown=0;return;} if(!strcmp(s,"cache")){utility_cache();prompt_shown=0;return;} if(!strcmp(s,"tlb")){utility_tlb();prompt_shown=0;return;} if(!strcmp(s,"help")){utility_help();prompt_shown=0;return;}
        char*a=strtok(s," \t"),*b=strtok(NULL," \t"),*extra=strtok(NULL," \t");if(!a||!b||extra){fprintf(stderr,"[Shell] Use: <program.txt> <data.byte>\n");prompt_shown=0;return;}int pid=loader(a,b);if(pid>0)printf("[OS] PID %d accepted\n",pid);prompt_shown=0;return;
    }
    shell_exit=1;
}

void scheduler(void)
{
    while(1){int active=0;++scheduler_round;promote_waiting();
        for(int p=0;p<NP;p++)if(proc_pid[p]){active=1;Task*t=find_task(proc_pid[p]);if(t)t->state=RUNNING;process_instructions(p,TIME_SLICE);if(t)t->instructions=processor_get_stats(p)->instructions;if(!end_of_simulation[p]&&t)t->state=READY;}
        reap_finished();promote_waiting();shell();for(int p=0;p<NP;p++)if(proc_pid[p])active=1;if(shell_exit&&!active)break;msleep(1000);
    }
    if(fd_log){log_event("[OS] Scheduler stopped after %lu rounds.\n",scheduler_round);fclose(fd_log);fd_log=NULL;}
}
int os_should_exit(void){return shell_exit;}
