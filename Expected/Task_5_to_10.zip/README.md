# CS527 Extended Mini-Computer

This is the supplied CS527 Lab-5 simulator extended with tasks 5-10: utilities, TLB/cache/timing, pipelining, shared-memory IPC, page-table security, memory-mapped I/O, and virtual-register analysis.

## Build

Requirements: GCC, GNU Make, and Python 3 for the supplied tests.

```bash
make clean
make
```

This creates:

```text
./executable
```

## Run with a program from the command line

Give the program and data files as a pair:

```bash
./executable tests/test_01/program.txt tests/test_01/data.byte
```

The loader compiles `.txt` source files automatically. When you do not want to add another task, provide shell input:

```text
exit
```

For example:

```bash
echo exit | ./executable tests/vector_array_add/program.txt tests/vector_array_add/data.byte
```

## Interactive input

Start the simulator with no task arguments:

```bash
./executable
```

The shell displays:

```text
$ 
```

Enter exactly two filenames:

```text
$ tests/test_01/program.txt tests/test_01/data.byte
```

You can add several tasks:

```text
$ tests/test_01/program.txt tests/test_01/data.byte
$ tests/test_02/program.txt tests/test_02/data.byte
$ tests/vector_fir/program.txt tests/vector_fir/data.byte
```

When finished adding tasks, type:

```text
$ exit
```

`exit` stops new input; it does not terminate processes that are already running.

## Shell utilities

### View memory maps

```text
$ memmap
```

Displays physical frames, process page mappings, permissions and shared status. It also writes `memory_map.txt`.

### View process performance

```text
$ perf
```

Displays/writes `performance.log` containing:

- instructions;
- total cycles;
- pipeline cycles and stalls;
- TLB hits/misses;
- cache hits/misses;
- memory accesses;
- branch statistics;
- wall time.

### View cache statistics

```text
$ cache
```

### View TLB statistics

```text
$ tlb
```

### Show commands

```text
$ help
```

## Existing regression tests

Run all supplied tests:

```bash
make test
```

Run the original multiprocessing demonstration:

```bash
make demo
```

## Shared-memory IPC

Declare a page-aligned shared region in a source program:

```text
SHARED 512 512
```

The first number is the logical data address and the second is the number of bytes. Both must be multiples of 512 and stay within the 4096-byte data address space.

Two processes that declare the same region can be mapped to the same physical frame(s). The compiler emits a `0xF0` metadata record and the OS consumes it during loading.

## Memory-mapped I/O

Reserved logical data addresses:

```text
0xF0  status/input state
0xF4  input byte
0xF8  output byte
0xFC  timer
0xEC  processor slot
```

Normal load/store instructions can use these addresses. The memory system recognizes them and invokes the simulated device instead of ordinary RAM.

For example, a program can place `248` (`0xF8`) in a register and store a value through the normal memory-write instruction; the low byte is printed to the simulator console.

## Virtual registers

The compiler accepts `rN` as a virtual integer-register spelling. Example:

```text
r1 = 10
r2 = 20
r3 = r1 + r2
Print r3
```

Representable virtual registers are mapped to physical `xN` registers before bytecode generation. The compiler also performs liveness-interval analysis and graph-colouring allocation and writes:

```text
program.byte.registers.md
```

The report identifies physical colours and spill candidates. Because the supplied ISA has no dedicated spill opcode, a case requiring more than the available physical colours is reported rather than generating an incompatible binary.

## Generated files

The simulator may create:

```text
program.byte
program.byte.pidN
program.byte.registers.md
process.log
memory_map.txt
performance.log
```

PID-specific temporary bytecode is removed after the task finishes.

## Architecture details

### Physical memory

```text
MEMSIZE  = 8192 bytes
PAGESIZE = 512 bytes
Frames   = 16
Frame 0  = reserved for page tables
```

### Page-table entry

```text
bits 0..3 = frame
bit 4     = R
bit 5     = W
bit 6     = X
bit 7     = SHARED
```

### Cache

16 direct-mapped lines, 16 bytes per line, physically tagged, write-through.

### TLB

8 entries per processor, tagged by PID and logical page.

### Pipeline

Five stages:

```text
IF -> ID -> EX -> MEM -> WB
```

See `INTUITION_AND_PROCESS.md` for the complete intuition and implementation process.
