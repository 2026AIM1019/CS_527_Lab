# Intuition and complete implementation process

This document explains the extended CS527 mini-computer. The supplied Lab-5 project already implemented paging, an MMU, a four-slot processor model, vectors, the scheduler and the shell. The new work is layered on that baseline.

## 1. System idea

```text
User source -> Compiler -> Bytecode + metadata
                         |
                         v
                 OS / Loader / Scheduler
                         |
                         v
              Processor: IF -> ID -> EX -> MEM -> WB
                         |
                    TLB -> MMU -> Cache
                         |
                         v
                  Physical memory
                 /      |       \
          page tables  RAM      MMIO
           frame 0
```

The central design principle is that each layer has one responsibility. The compiler describes program requirements, the OS owns resource allocation and scheduling, the MMU performs translation/protection, and the processor executes instructions while collecting timing statistics.

## 2. Utilities (Task 5)

The shell exposes `memmap`, `perf`, `cache`, `tlb` and `help`.

`memmap` shows physical frame allocation and the logical-page-to-frame mapping of active tasks. It also writes `memory_map.txt`.

`perf` shows instruction count, total cycles, pipeline cycles/stalls, TLB/cache hits and misses, memory accesses, branches and wall time. It also writes `performance.log`.

These utilities sit in the OS because the OS has the system-wide view needed to inspect all processes.

## 3. TLB and cache (Task 6)

### TLB

An 8-entry TLB caches:

```text
PID + logical page -> physical frame
```

The PID is part of the lookup key. This prevents a context switch from accidentally using a translation belonging to another process.

A miss performs a real page-table translation and then fills the TLB.

### Cache

The processor has a 16-line direct-mapped cache with 16-byte lines. It is physically tagged and write-through.

Physical tagging is important because two processes can map different logical addresses to the same physical frame. Write-through memory makes the OS's physical-memory view immediately consistent.

### Timing

The processor counts cache/TLB misses and adds miss penalties to a simulated cycle count. Thus the `perf` output makes locality and translation overhead visible without changing the architectural result of a program.

## 4. Pipelining (Task 7)

The timing model represents a five-stage in-order pipeline:

```text
IF -> ID -> EX -> MEM -> WB
```

Architectural execution remains in program order so old Lab-5 programs keep deterministic behaviour. Pipeline fill/drain overhead and memory-system stalls are reflected in the timing counters.

The purpose is to make the performance effect of pipelining and memory hierarchy measurable while avoiding a second, independently implemented ISA semantics engine.

## 5. Shared-memory IPC (Task 8)

A program can declare a page-aligned shared region:

```text
SHARED 512 512
```

The compiler emits a four-byte `0xF0` metadata record. It is a no-op to the processor but is consumed by the OS loader.

The first process becomes the owner of the shared region. Later processes declaring the same logical region are mapped to the owner's physical frame(s):

```text
PID 1 logical page ----> physical frame 7 <---- PID 2 logical page
```

Reference counting keeps a shared frame alive while any process still maps it.

This spans the required layers: programming construct (`SHARED`), ISA metadata (`0xF0`), compiler emission, and OS page-table sharing.

## 6. Page-table storage and security (Task 9)

The page table is physically stored in frame 0. Each PTE is one byte:

```text
bits 0..3 : physical frame number
bit 4     : READ
bit 5     : WRITE
bit 6     : EXECUTE
bit 7     : SHARED
```

Instruction pages are loaded as `R-X`; data pages as `RW-`.

The MMU receives an explicit access type: READ, WRITE or EXEC. It checks the PTE before returning a physical address. Therefore a write to code, or an instruction fetch from data, is rejected.

## 7. Memory-mapped I/O

A small range of logical data addresses is interpreted as device registers instead of normal RAM:

| Address | Meaning |
|---|---|
| `0xF0` | input/status register |
| `0xF4` | input byte |
| `0xF8` | output byte |
| `0xFC` | timer |
| `0xEC` | processor-slot identifier |

For example, a store to `0xF8` sends the low byte to the simulated console. The CPU uses its normal load/store instruction; the memory subsystem decides whether the address is RAM or an I/O device.

## 8. Virtual registers, liveness and graph colouring (Task 10)

The compiler accepts `rN` as a virtual-register spelling. Representable virtual registers are mapped to the physical ISA spelling `xN` before the existing bytecode parser runs.

A separate analysis pass records each virtual register's first use, last use and number of uses. The intervals are coloured greedily: two overlapping intervals receive different colours, while non-overlapping intervals can reuse a colour. A colour corresponds to a physical register.

The compiler writes a report named `<program.byte>.registers.md`.

If all 256 colours are occupied, the interval is reported as a spill candidate. The supplied ISA has no dedicated spill instruction or stack opcode, so silently inventing one would make the resulting binary incompatible with the stated ISA. The implementation therefore reports the condition explicitly and documents the data-memory spill location as the next compiler extension.

## 9. Context switching

Each processor slot keeps its complete architectural context: integer registers, vector registers, PC and flags. The scheduler gives a process a fixed time slice and later resumes that context.

TLB entries are invalidated when a new PID is assigned to a slot. Cache entries carry process identity, preventing stale data from a previous process from being interpreted as the current process's data.

## 10. Complete execution flow

1. Shell receives `program.txt data.byte`.
2. Loader invokes the compiler for source input.
3. Compiler creates bytecode and optional shared-memory metadata.
4. Compiler creates the virtual-register analysis report.
5. OS allocates instruction/data frames.
6. OS reads shared metadata and creates or joins shared mappings.
7. CPU context is reset.
8. Scheduler runs a time slice.
9. Fetch translates instruction addresses through TLB/MMU/cache.
10. Decode identifies the fixed four-byte instruction.
11. Execute performs the ISA operation.
12. Data accesses use the same translation/cache path; MMIO addresses are redirected to devices.
13. Timing counters record pipeline and memory-system costs.
14. On halt, the OS writes the logical data image back to the task's data file.
15. Physical frames are released or retained by reference counting for shared mappings.

## 11. Why the extension is safe

The original Lab-5 instruction encodings remain unchanged. New behaviour is attached to the processor/memory/OS boundaries. Existing regression programs therefore continue to use the same ISA while the new mechanisms expose additional system behaviour and measurements.
