# Task 3 — Store the Page Table in Physical Memory

## 1. What was changed?

The original Lab 5 implementation maintained the complete page table in an
OS-side C array:

```c
pageTable[process][logical_page]
```

For this task, the **page table itself is now stored inside physical memory**.
The OS no longer keeps the logical-page → physical-frame entries in a normal
page-table data structure.

The only small OS-side bookkeeping value retained for each processor slot is
the **physical frame number where that process's page table starts**. The actual
page-table entries are bytes inside `memory[]`.

---

## 2. Why store the page table in physical memory?

Think about what the page table represents:

```text
Logical Page Number  --->  Physical Frame Number
```

For example, suppose a process has:

```text
Logical instruction page 0 -> physical frame 5
Logical instruction page 1 -> physical frame 9
Logical data page 0        -> physical frame 3
```

The page table contains approximately:

```text
Page 0 -> 5
Page 1 -> 9
Page 2 -> 3
...
```

Previously these mappings were stored in a C array owned by the OS. The new
design makes the page table a real memory-resident object, just like other
memory used by the simulated computer.

This is closer to how an actual operating system works: page tables are data
structures placed in memory, and hardware/MMU logic uses their memory-resident
contents to perform address translation.

---

## 3. Physical memory layout

The project uses:

```text
MEMSIZE  = 8192 bytes
PAGESIZE = 512 bytes
```

Therefore:

```text
8192 / 512 = 16 physical frames
```

Frame 0 remains reserved.

For every resident process, one additional physical frame is allocated for
its page table.

A page table needs only 10 entries:

```text
2 instruction pages + 8 data pages = 10 entries
```

One byte is enough for every entry because the machine has only 16 physical
frames. Therefore the 10-byte page table easily fits inside one 512-byte
physical frame.

The rest of that 512-byte page-table frame is currently unused/reserved for
that page table.

---

## 4. Important design idea

There are two different things that must not be confused:

### Page-table location

The OS needs to know where the page table is located so that it can find it.
The implementation therefore keeps:

```c
static int page_table_frame[NP];
```

This is **not the page table itself**. It only says:

```text
processor/process slot 0 -> page table is in frame 7
processor/process slot 1 -> page table is in frame 4
...
```

### Page-table contents

The actual entries are stored in:

```c
memory[page_table_frame[proc_id] * PAGESIZE + index]
```

So the mapping entries are physically inside the simulated RAM.

---

## 5. Initialization process

When a new process is loaded:

```text
loader()
   |
   v
initialize()
   |
   +--> allocate one physical frame for page table
   |
   +--> clear page-table frame
   |
   +--> load program pages
   |       |
   |       +--> allocate physical frame
   |       +--> write frame number into page table in memory
   |       +--> copy program bytes into physical frame
   |
   +--> load data pages
           |
           +--> allocate physical frame
           +--> write frame number into page table in memory
           +--> copy data bytes into physical frame
```

The page table is therefore created before the program and data pages are
loaded.

---

## 6. Address translation process

Suppose the processor wants to access logical address `600` in data memory.

First calculate the logical page:

```text
600 / 512 = 1
```

Data starts after the two instruction pages, so the page-table index becomes:

```text
1 + 2 = 3
```

The MMU reads entry 3 from the page table stored in physical memory.

Suppose entry 3 contains physical frame `8`.

The offset is:

```text
600 % 512 = 88
```

Therefore:

```text
physical address = 8 * 512 + 88
                 = 4184
```

The processor then accesses:

```c
memory[4184]
```

The processor never needs to know where the process's data was placed in
physical memory.

---

## 7. Instruction fetch

Instruction addresses use logical instruction pages 0 and 1.

For example:

```text
PC = 100
100 / 512 = 0
```

Therefore page-table entry 0 is read from the physical-memory page table.

For an instruction at:

```text
PC = 600
```

we get:

```text
600 / 512 = 1
```

so page-table entry 1 is used.

The processor's `fetch()` function already calls:

```c
getPhysicallAddress(proc_id, 1, PC)
```

Therefore instruction fetches automatically use the new memory-resident page
table.

---

## 8. Data access

Data logical addresses range from 0 to 4095.

The data pages occupy page-table entries 2 through 9 because the first two
entries belong to instruction memory.

For example:

```text
Data address = 0
Data page    = 0
PT index     = 2
```

and:

```text
Data address = 512
Data page    = 1
PT index     = 3
```

This is why accesses crossing the 512-byte boundary continue to work even
when the two logical pages are mapped to completely different physical
frames.

---

## 9. Process cleanup

When a process finishes, `finalize()` writes the logical data space back to
its data file using the page table.

After that, `releaseProcessPages()`:

1. Reads each page-table entry from physical memory.
2. Releases the corresponding program/data physical frames.
3. Clears the page-table entries.
4. Releases the physical frame occupied by the page table itself.

So the entire address space, including its page table, is returned to the
physical-memory free-frame pool.

---

## 10. Why this still works with multiple processes

Each process gets a separate page-table frame:

```text
Physical Memory
+-----------------------------+
| Frame 0: reserved           |
+-----------------------------+
| PID 1 page table            |
+-----------------------------+
| PID 1 program/data page     |
+-----------------------------+
| PID 2 page table            |
+-----------------------------+
| PID 2 program/data page     |
+-----------------------------+
| ...                         |
+-----------------------------+
```

The physical frames need not be contiguous.

For example:

```text
PID 1:
  PT page -> frame 2
  code    -> frame 7
  data    -> frame 5

PID 2:
  PT page -> frame 3
  code    -> frame 9
  data    -> frame 1
```

Each processor slot uses its own page-table location, so two processes can
have the same logical address but still access different physical memory.

---

## 11. Main difference from the previous implementation

### Before

```text
OS data structure

pageTable[pid][logical_page]
          |
          v
physical frame number
```

### Now

```text
OS remembers only:

page_table_frame[pid]
          |
          v
physical frame containing page table
          |
          v
memory[physical_address + logical_page]
          |
          v
physical frame number
```

This is the central idea of Task 3.

---

## 12. Files changed

### `memory.c`

Contains the new memory-resident page-table implementation. The important
functions are:

- `initialize()` — allocates a physical frame for the page table.
- `getPhysicallAddress()` — reads the page-table entry from physical memory.
- `releaseProcessPages()` — releases both mapped pages and the page-table
  frame.
- `load_region()` — populates page-table entries directly in physical memory.
- `finalize()` — reconstructs logical data through the page table.

### `memory.h`

No longer exposes a `pageTable[][]` array because the actual page table is no
longer an OS-side array.

---

## 13. Validation idea

The existing regression tests are still useful because they exercise the
complete path:

```text
program
  -> compiler
  -> bytecode
  -> loader
  -> physical-memory allocation
  -> memory-resident page table
  -> MMU translation
  -> processor execution
  -> physical-memory modification
  -> finalize
  -> logical data file
```

In particular, `lab5_mmu` accesses data around logical addresses 508 and 512.
That crosses a 512-byte page boundary and therefore verifies that the MMU is
really following page mappings instead of assuming one contiguous physical
region.
