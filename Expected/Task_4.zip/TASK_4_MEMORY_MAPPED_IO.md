# Task 4 — Memory-Mapped I/O

## 1. Intuition

Memory-mapped I/O (MMIO) means that an I/O device is controlled by reading and
writing special addresses, just like reading and writing normal memory.

Normally, a processor instruction such as:

```text
x4 = [x1]
```

means:

1. Read the address stored in `x1`.
2. Translate that logical data address to a physical RAM address.
3. Read four bytes from physical memory.
4. Put the resulting 32-bit value in `x4`.

With memory-mapped I/O, the same instruction can also access a device. The
processor does **not** need a new `READ_KEYBOARD` or `PRINT_CHARACTER`
instruction.

The address itself tells the memory system what should happen:

```text
                    +----------------------+
                    | Processor            |
                    |                      |
                    | load/store           |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Memory access layer  |
                    +----------+-----------+
                               |
                 +-------------+-------------+
                 |                           |
          normal data address          MMIO address
                 |                           |
                 v                           v
        +------------------+       +------------------+
        | MMU / page table |       | I/O device      |
        | translation      |       | registers       |
        +--------+---------+       +------------------+
                 |                           |
                 v                           +--> console input
        +------------------+                +--> console output
        | physical RAM     |
        +------------------+
```

This is the main idea implemented in this task.

---

## 2. MMIO address map used by this simulator

The normal logical data memory occupies addresses `0` through `4095`.
Therefore the simulator places its device registers immediately after that
range.

| Address | Name | Operation | Meaning |
|---|---|---|---|
| `0x1000` | `MMIO_INPUT_ADDR` | Read | Read one character from the console input device |
| `0x1004` | `MMIO_OUTPUT_ADDR` | Write | Write the low byte as a console character |
| `0x1008` | `MMIO_STATUS_ADDR` | Read | Bit 0 is `1` when input is available |

These addresses are **not** mapped to a physical RAM frame.

They are device registers handled by the MMIO code.

---

## 3. Why MMIO is implemented in `memory.c`

The existing processor already has two kinds of memory instructions:

```text
0x05 / 0x0D  -> memory read
0x06 / 0x0E  -> memory write
```

Instead of adding separate I/O opcodes, these instructions call:

```c
read_memory_32(...)
write_memory_32(...)
```

Those two functions now perform this check first:

```text
Is the address an MMIO address?
        |
      /   \
    yes    no
    |       |
    v       v
 device    normal MMU translation
 access    and physical RAM access
```

This keeps the processor simple and makes MMIO work for both variable-address
and constant-address memory operations.

---

## 4. Read path

Suppose the program executes:

```text
x4 = [x1]
```

and `x1` contains `0x1000`.

The complete flow is:

```text
1. Processor executes load instruction.
              |
              v
2. address = Register[x1]
              |
              v
3. address == 0x1000 ?
              |
             yes
              |
              v
4. mmio_read_32(0x1000)
              |
              v
5. Check MMIO_INPUT data source.
              |
              v
6. Return character as a 32-bit value.
              |
              v
7. Store result in x4.
```

For example, if the input character is `Z`:

```text
ASCII('Z') = 0x5A

x4 = 0x0000005A
```

The normal page-table translation is intentionally skipped because `0x1000`
is a device address rather than a RAM address.

---

## 5. Write path

Suppose:

```text
x2 = 0x1004
x4 = 0x0000005A
```

and the program executes:

```text
[x2] = x4
```

The flow is:

```text
1. Processor executes store instruction.
              |
              v
2. address = Register[x2]
              |
              v
3. address == 0x1004 ?
              |
             yes
              |
              v
4. mmio_write_32(0x1004, x4)
              |
              v
5. Take low 8 bits: 0x5A
              |
              v
6. Output character 'Z'
```

Therefore the same store instruction is being used as a device-output
operation.

---

## 6. Status register

The status register is at:

```text
0x1008
```

Reading it returns:

```text
1 -> input is available
0 -> input is not currently available
```

Only bit 0 is meaningful.

This gives a program a way to check whether a character is available before
performing an input read.

---

## 7. Interactive input and automated testing

There are two input sources.

### Normal interactive mode

When no deterministic test input is supplied, the MMIO input register checks
standard input without blocking the processor.

This is important because the OS shell also uses standard input.

### Automated testing

For repeatable tests, the environment variable:

```text
MMIO_INPUT
```

can provide the characters consumed by the simulated input device.

For example:

```bash
MMIO_INPUT=Z ./executable tests/task4_mmio/program.txt tests/task4_mmio/data.byte
```

The first MMIO input read returns `Z`.

This lets the automated test send the shell's separate `exit` command while
still supplying deterministic data to the simulated I/O device.

---

## 8. Example program

The test program stores the MMIO addresses in normal data memory:

```text
x1 = [0]       % x1 = 0x1000, input register
x2 = [4]       % x2 = 0x1004, output register
x3 = [8]       % x3 = 0x1008, status register

x4 = [x1]      % read one character from input device
x5 = [x3]      % read device status
[x2] = x4      % send character to output device

Print x4
Print x5
```

The first three data words contain:

```text
Data[0] = 0x00001000
Data[4] = 0x00001004
Data[8] = 0x00001008
```

The test therefore demonstrates that a normal program can obtain a device
address from memory and then access the device through the existing load/store
instructions.

---

## 9. Why the address is outside normal data memory

The existing Lab 5 logical data memory is:

```text
0x0000 -------------------- 0x0FFF
          normal RAM

0x1000 -> MMIO input
0x1004 -> MMIO output
0x1008 -> MMIO status
```

This avoids confusing device accesses with ordinary process data pages.

An MMIO access never consumes a physical frame and never creates a page-table
entry.

---

## 10. Interaction with Task 3 page tables

Task 3 requires the page table itself to be stored inside simulated physical
memory.

Task 4 does not remove or bypass that implementation for normal RAM.

The two paths are now:

```text
                 CPU memory instruction
                          |
                          v
                    logical address
                          |
                          v
                  +----------------+
                  | Is MMIO?       |
                  +-------+--------+
                      yes | no
                          |  \
                          |   \
                          v    v
                     MMIO device  MMU
                                  |
                                  v
                            page-table lookup
                                  |
                                  v
                             physical RAM
```

So Task 4 is an extension of the existing Task 3 memory architecture rather
than a replacement for it.

---

## 11. Error handling

Invalid MMIO operations are rejected with an error message.

For example, a read from an address that is not one of the defined MMIO
registers is not silently treated as a device access.

Normal invalid RAM addresses continue to be handled by the existing MMU
range checking.

---

## 12. Files changed for Task 4

### `memory.h`

Added the MMIO address definitions and the MMIO helper declarations.

### `memory.c`

Added:

- MMIO address detection.
- Console input device.
- Console output device.
- Input status register.
- Deterministic `MMIO_INPUT` test support.
- MMIO-aware 32-bit read/write paths.

Also improved final data reconstruction so unmapped trailing pages are treated
as zero without generating unnecessary MMU errors.

### `processor.c`

The existing load/store instructions continue to be used. Comments were added
to explain that these instructions can now reach either normal RAM or MMIO
devices depending on the address.

### `test_runner.py`

Added an automated Task 4 test that checks:

- MMIO input is read correctly.
- MMIO output is generated correctly.
- The status register reports input availability.
- The process log records MMIO operations.
- The character reaches the simulator's stdout.

### `tests/task4_mmio/`

Contains a small source program, input data, and expected bytecode for the
Task 4 demonstration.

---

## 13. Complete execution process

The complete system now works as follows:

```text
User program (.txt)
        |
        v
     Compiler
        |
        v
   program.byte
        |
        v
      Loader
        |
        v
  Process + page table
        |
        v
    Scheduler
        |
        v
     Processor
        |
        v
    Fetch / Decode / Execute
        |
        v
     Load / Store
        |
        v
    +---+----------------+
    |                    |
 normal RAM            MMIO
    |                    |
    v                    v
MMU translation      device register
    |                    |
    v              console input/output
physical memory
```

The important design principle is that **the processor does not need to know
the implementation details of the device**. It only performs a memory access.
The memory subsystem decides whether the address refers to RAM or to an MMIO
device.

---

## 14. Verification

The complete automated test suite was run after the implementation.

Result:

```text
12/12 tests passed
ALL TESTS PASSED
```

This includes all previous Lab 5 regression tests, the Task 3 physical-page-
table test, and the new Task 4 MMIO test.
