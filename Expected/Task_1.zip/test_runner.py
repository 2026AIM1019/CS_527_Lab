#!/usr/bin/env python3
import subprocess, struct, shutil, tempfile, os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXE = ROOT / "executable"
TESTS = ["test_01", "test_02", "test_03", "test_04", "test_05",
         "vector_array_add", "vector_fir"]

def bytes_of(p):
    return bytes(int(x, 16) & 255 for x in p.read_text().split())

def i32(b, a):
    return struct.unpack_from("<i", b, a)[0]

def run(cmd, inp=b"", timeout=15):
    return subprocess.run(cmd, cwd=ROOT, input=inp, text=False,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          timeout=timeout)

def build(np=1):
    r = run(["make", "clean"])
    if r.returncode:
        print(r.stdout.decode())
        return False
    r = run(["make", f"NP={np}"])
    if r.returncode:
        print(r.stdout.decode())
        return False
    print("[PASS] Build")
    return True

def check_bytecode(d):
    a, e = d / "program.byte", d / "expected_program.byte"
    return a.exists() and e.exists() and a.read_bytes() == e.read_bytes()

def check_result(name, d):
    b = bytes_of(d / "data.byte")
    if name.startswith("test_"):
        ex = {"test_01":[(16,55)], "test_02":[(16,70),(20,85)],
              "test_03":[(36,37)], "test_04":[(24,150)],
              "test_05":[(16,10),(20,40),(24,80)]}[name]
        return all(i32(b, a) == v for a, v in ex)

    n = i32(b, 0)
    if name == "vector_array_add":
        if n <= 0 or n % 8:
            return False
        A, B, C = 4, 4 + 4*n, 4 + 8*n
        return all(i32(b, C+4*i) == i32(b, A+4*i) + i32(b, B+4*i)
                   for i in range(n))

    weights = [i32(b, 4+4*i) for i in range(8)]
    inp = [i32(b, 36+4*i) for i in range(n)]
    return all(i32(b, 0x100+4*k) ==
               sum(inp[k+i]*weights[i] for i in range(8))
               for k in range(max(0, n-8)))

def run_regression():
    passed = 0
    for name in TESTS:
        d = ROOT / "tests" / name
        data = d / "data.byte"
        original = data.read_bytes()
        try:
            r = run([str(EXE), str(d/"program.txt"), str(data)], b"exit\n")
            ok = r.returncode == 0 and check_bytecode(d) and check_result(name, d)
            print(f"[PASS] {name}" if ok else f"[FAIL] {name}")
            if not ok:
                print(r.stdout.decode()[-2500:])
            passed += int(ok)
        finally:
            data.write_bytes(original)
    return passed

def lab4_print():
    d = ROOT / "tests" / "lab4_print"
    data = d / "data.byte"
    original = data.read_bytes()
    log = ROOT / "process.log"
    if log.exists():
        log.unlink()
    try:
        r = run([str(EXE), str(d/"program.txt"), str(data)], b"exit\n")
        text = log.read_text() if log.exists() else ""
        good = (r.returncode == 0 and
                "Process id:" in text and
                "x1 : 0000002A" in text and
                "x2 : 000000FF" in text)
        print("[PASS] lab4_print" if good else "[FAIL] lab4_print")
        if not good:
            print(r.stdout.decode()[-2500:])
        return good
    finally:
        data.write_bytes(original)

def lab4_multiprocess():
    # Rebuild with four CPUs for the Task 1a extension.
    if not build(4):
        return False

    d = ROOT / "tests" / "lab4_multiprocess"
    temp_dir = Path(tempfile.mkdtemp(prefix="lab5_mp_", dir=ROOT))
    files = []
    try:
        # One 512-byte data page per process keeps the six demo tasks
        # resident in the 15 allocatable physical frames.
        for i in range(1, 7):
            src = d / f"program{i}.txt"
            dst = temp_dir / f"data{i}.byte"
            dst.write_text(("00 " * 512).strip() + "\n")
            files += [str(src), str(dst)]

        log = ROOT / "process.log"
        if log.exists():
            log.unlink()

        r = run([str(EXE)] + files, b"exit\n", timeout=20)
        out = r.stdout.decode()
        logs = log.read_text() if log.exists() else ""

        # Four CPUs must be visible in the first dispatch round and the
        # remaining tasks must still run through the shared ready queue.
        dispatched = all(f"[DISPATCH] PID {i} -> CPU {i-1}" in logs for i in range(1, 5))
        printed = all(f"x1 : {0xC8+i:08X}" in logs for i in range(1, 7))
        context = "[CONTEXT] SAVE" in logs and "[CONTEXT] RESTORE" in logs
        good = r.returncode == 0 and dispatched and printed and context

        print("[PASS] lab4_multiprocess" if good else "[FAIL] lab4_multiprocess")
        if not good:
            print(out[-6000:])
            print("--- process.log ---")
            print(logs[-4000:])
        return good
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def single_processor_context_switch():
    # Rebuild with one CPU: this is the main requirement of the new task.
    if not build(1):
        return False

    d = ROOT / "tests" / "lab4_multiprocess"
    temp_dir = Path(tempfile.mkdtemp(prefix="lab5_sp_", dir=ROOT))
    files = []
    try:
        for i in range(1, 7):
            src = d / f"program{i}.txt"
            dst = temp_dir / f"data{i}.byte"
            dst.write_text(("00 " * 512).strip() + "\n")
            files += [str(src), str(dst)]

        log = ROOT / "process.log"
        if log.exists():
            log.unlink()

        r = run([str(EXE)] + files, b"exit\n", timeout=20)
        logs = log.read_text() if log.exists() else ""

        # Every task must run on CPU 0, but the log must prove that the
        # processor state was saved and restored between tasks/time slices.
        printed = all(f"x1 : {0xC8+i:08X}" in logs for i in range(1, 7))
        save = logs.count("[CONTEXT] SAVE") > 0
        restore = logs.count("[CONTEXT] RESTORE") > 0
        only_cpu0 = "CPU 1" not in logs and "CPU 2" not in logs and "CPU 3" not in logs
        good = r.returncode == 0 and printed and save and restore and only_cpu0

        print("[PASS] single_processor_context_switch" if good else "[FAIL] single_processor_context_switch")
        if not good:
            print(r.stdout.decode()[-6000:])
            print("--- process.log ---")
            print(logs[-4000:])
        return good
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def lab5_mmu():
    d = ROOT / "tests" / "lab5_mmu"
    data = d / "data.byte"
    original = data.read_bytes()
    log = ROOT / "process.log"
    if log.exists():
        log.unlink()
    try:
        r = run([str(EXE), str(d/"program.txt"), str(data)], b"exit\n")
        b = bytes_of(data)
        logs = log.read_text() if log.exists() else ""
        good = (r.returncode == 0 and
                check_bytecode(d) and
                i32(b, 508) == 123 and
                i32(b, 512) == 200 and
                "x7 : 0000007B" in logs and
                "x8 : 000000C8" in logs)
        print("[PASS] lab5_mmu" if good else "[FAIL] lab5_mmu")
        if not good:
            print(r.stdout.decode()[-3000:])
            print("--- process.log ---")
            print(logs[-2000:])
        return good
    finally:
        data.write_bytes(original)

def main():
    if not build(1):
        return 1
    passed = run_regression()
    passed += int(lab4_print())
    passed += int(single_processor_context_switch())
    passed += int(lab4_multiprocess())
    passed += int(lab5_mmu())

    total = len(TESTS) + 4
    print(f"\n{passed}/{total} tests passed")
    print("ALL TESTS PASSED" if passed == total else "SOME TESTS FAILED")
    return 0 if passed == total else 1

if __name__ == "__main__":
    raise SystemExit(main())
