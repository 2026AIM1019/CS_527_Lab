# Lab 5 Changes and Task 1 Extension

## Original Lab 5 functionality retained

- Vector registers and vector instructions.
- Print instruction and `process.log`.
- OS shell and loader.
- Shared physical memory.
- Logical-to-physical MMU translation.
- Page tables and physical-frame allocation.
- Task finalization and frame release.
- Existing scalar/vector/MMU regression tests.

## Task 1: single processor multitasking

The default build now uses:

```text
NP=1
```

The OS can still maintain many tasks. A task no longer permanently owns the only processor.

The scheduler uses a round-robin READY queue and gives each selected task `TIME_SLICE` instructions.

At the end of a non-finished time slice:

```text
CPU state -> Task.context
Task -> READY
CPU -> IDLE
```

Before a task runs again:

```text
Task.context -> CPU state
```

The saved context contains:

- 256 integer registers.
- 32 vector registers with 8 x 32-bit lanes each.
- PC.
- Z/N/C/V flags.
- End-of-simulation state.

## Task 1a: multiprocessor extension

The same source supports multiple processor instances through the compile-time `NP` setting.

For example:

```bash
make NP=4
```

creates four CPU instances.

The scheduler shares the READY queue among all CPUs. Tasks can be dispatched to different CPUs and can later resume on another CPU because their architectural context belongs to the task rather than to a particular processor.

## Important memory/MMU change

The page table is indexed by **task slot**, not processor ID:

```c
pageTable[MAX_PROCESSES][NUM_LOGICAL_PAGES]
```

The processor maintains a CPU-to-task memory-context mapping. This is necessary because a task can migrate from one CPU to another without changing its logical address space.

## Verification

`test_runner.py` verifies both modes:

1. `NP=1`: multiple tasks share CPU0 and the log must contain context SAVE/RESTORE events.
2. `NP=4`: four processors execute tasks from the shared READY queue.
3. Existing scalar, vector, Print, and MMU tests remain passing.
