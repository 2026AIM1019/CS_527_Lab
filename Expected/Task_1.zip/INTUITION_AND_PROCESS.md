# Intuition and Complete Process - Task 1

## 1. What is the actual problem?

The earlier design associated a running task with a processor. That is convenient for a multiprocessor simulator, but it does not demonstrate the basic operating-system idea of **context switching on a single processor**.

The new requirement is:

> Use one processor, but allow multiple tasks to make progress by saving the state of the currently running task and restoring the state of another task.

Then Task 1a asks us to extend the same idea to multiple processors.

The central idea is therefore:

```text
                 OPERATING SYSTEM
                        |
                 READY TASK QUEUE
                        |
             +----------+----------+
             |          |          |
            PID1       PID2       PID3 ...
             |
             v
        +------------+
        |   CPU      |
        | registers  |
        | PC + flags |
        +------------+
             |
          time slice
             |
             v
        SAVE CONTEXT
             |
             v
       another task
```

The CPU itself is temporary. The task's saved context is permanent until the task runs again.

---

# 2. Why context saving is necessary

Imagine two programs:

```text
Program A:
    x1 = 10
    x2 = 20
    x3 = x1 + x2
    ...

Program B:
    x1 = 100
    x2 = 200
    x3 = x1 + x2
    ...
```

A single CPU has only one physical set of working registers in our simulator.

If A is running and then B starts using the same registers, B would overwrite A's values.

Therefore before changing from A to B:

```text
CPU registers
     |
     | copy
     v
A's ProcessorContext
```

Then B's saved state is copied into the CPU:

```text
B's ProcessorContext
     |
     | copy
     v
CPU registers
```

When A runs again, the reverse operation restores A's old register values.

---

# 3. What exactly is a context?

A context is everything in the processor state that is necessary to continue a task correctly.

This project saves:

```text
Integer registers:
    x0 ... x255

Vector registers:
    v0 ... v31
    each vector has 8 x 32-bit elements

Program counter:
    PC

Condition flags:
    Z N C V

Execution status:
    end_of_simulation
```

The context is represented by `ProcessorContext` in `processor.h`.

The OS stores one `ProcessorContext` inside every `Task` structure.

---

# 4. Why PC is especially important

The Program Counter tells the processor which instruction comes next.

Suppose:

```text
PID 1
PC = 40
```

After its time slice, the OS saves:

```text
PID 1 context:
    PC = 40
    x1 = ...
    x2 = ...
    flags = ...
```

If PID 1 is later restored with `PC=40`, it fetches the same next instruction it would have fetched if it had never been interrupted.

Without saving PC, the task might restart at address 0 or continue from another task's PC.

That would make multitasking incorrect.

---

# 5. Single processor scheduling

The default build uses:

```text
NP = 1
```

Suppose the ready queue contains:

```text
PID1 -> PID2 -> PID3
```

The scheduler gives CPU 0 to PID1.

```text
CPU0 -> PID1
```

After 10 instructions:

```text
SAVE PID1
PID1 -> READY
CPU0 -> free
```

Next:

```text
RESTORE PID2
CPU0 -> PID2
```

After another slice:

```text
SAVE PID2
PID2 -> READY
```

Then PID3 runs.

Eventually:

```text
RESTORE PID1
```

PID1 continues from its saved PC and register values.

This is the basic idea of operating-system time sharing.

---

# 6. Why this is called parallel/concurrent execution

On one CPU, two instructions cannot physically execute at exactly the same instant in this simulator.

Instead, execution is interleaved:

```text
Time --->

PID1: [##########]
PID2:             [##########]
PID3:                         [##########]
PID1:                                     [##########]
```

Each block represents a time slice.

This gives the user-level effect that multiple programs are executing together. Technically, on a single CPU this is **concurrent time sharing**, not simultaneous parallel execution.

---

# 7. Round-robin ready queue

The scheduler uses a round-robin style selection.

A cursor remembers where the next search should start.

For example:

```text
READY:
PID1 PID2 PID3 PID4
```

Possible sequence:

```text
PID1
PID2
PID3
PID4
PID1
PID2
PID3
PID4
...
```

If PID3 finishes:

```text
PID1
PID2
PID4
PID1
PID2
PID4
...
```

The scheduler does not need a separate CPU for every task.

---

# 8. Dispatching a task

The dispatch operation performs these logical steps:

```text
Find READY task
       |
       v
Assign task temporarily to CPU
       |
       v
Tell processor which task owns its memory
       |
       v
Has task run before?
   /          \
 no            yes
 |              |
 v              v
reset CPU     restore context
 |              |
 +-------> CPU starts execution
```

For a new task, all registers and PC start from zero.

For an old task, its previously saved state is restored.

---

# 9. Context save

After a non-finished task consumes its time slice:

```text
CPU state
   |
   +--> integer registers
   +--> vector registers
   +--> PC
   +--> Z/N/C/V
   +--> execution state
             |
             v
       Task.context
```

The CPU is then released:

```text
Task state = READY
Task proc_id = -1
CPU = IDLE
```

This allows another READY task to be dispatched.

---

# 10. Context restore

When the saved task gets a CPU again:

```text
Task.context
     |
     +--> integer registers
     +--> vector registers
     +--> PC
     +--> flags
            |
            v
       CPU state
```

Then `process_instructions()` continues from that state.

The processor is therefore reusable while the task's execution state remains associated with the task.

---

# 11. Why task identity and CPU identity must be separate

This is one of the most important design points.

An incorrect design would do:

```text
pageTable[processor_id]
```

because it assumes that a task belongs permanently to one processor.

But after context switching/migration we can have:

```text
PID 5 -> CPU 0

later

PID 5 -> CPU 1
```

If the page table were indexed by CPU number, PID5 would suddenly use CPU1's address space.

That would be wrong.

The correct design is:

```text
Task slot -> page table
CPU -> currently running task
```

For example:

```text
Task slot 5
     |
     +--> pageTable[5]

CPU 0
     |
     +--> currently running Task 5
```

Later:

```text
CPU 1
     |
     +--> currently running Task 5
```

The page table remains:

```text
pageTable[5]
```

This is why `memory_context[]` was added to the processor implementation.

---

# 12. Logical memory is still task-owned

The Lab 5 MMU remains active.

Each task has logical instruction/data addresses, but physical memory is shared.

```text
PID1 logical memory ----> pageTable[task1] ----> physical frames
PID2 logical memory ----> pageTable[task2] ----> physical frames
PID3 logical memory ----> pageTable[task3] ----> physical frames
```

The CPU must first identify which task is currently executing.

Then the processor asks the MMU to translate that task's logical address.

---

# 13. Instruction fetch during context switching

Suppose PID2 is running on CPU0.

The processor needs instruction bytes at:

```text
PC = 40
```

The processor does not directly use physical address 40.

Instead:

```text
CPU0
  |
  +--> current task = PID2/task slot 2
  |
  +--> logical PC = 40
  |
  +--> getPhysicallAddress(task_slot=2, isFetch=1, address=40)
  |
  +--> physical address
  |
  +--> memory[physical address]
```

When PID3 runs next, the task slot changes:

```text
CPU0
  |
  +--> current task = PID3/task slot 3
```

Now its memory accesses use pageTable[3].

---

# 14. Data memory during a context switch

Suppose PID1 executes:

```text
x1 = [x2]
```

The logical address stored in x2 belongs to PID1's logical memory.

The processor therefore calls the memory system with PID1's task slot.

After a context switch, PID2 may have a completely different logical address space.

This separation prevents one task from accidentally reading another task's physical frames.

---

# 15. What happens when a task finishes?

A task that executes opcode `0x00` reaches the end of its simulation.

The scheduler detects:

```text
end_of_simulation[CPU] == 1
```

Then:

```text
1. Find the task's OS entry.
2. Write its logical data memory back to data.byte.
3. Release its physical frames.
4. Remove it from the active task table.
5. Free the CPU.
```

Once frames are released, a WAITING task may be loaded into memory and moved to READY.

---

# 16. Why some tasks can be WAITING

Physical memory is limited.

There are only:

```text
16 frames total
1 reserved
15 usable
```

A task may need several instruction/data pages.

If there are not enough free frames, the OS cannot keep that task resident.

Therefore:

```text
NEW
 |
 +--> cannot allocate enough frames
 |
 v
WAITING
```

After another task finishes:

```text
finished task
     |
     +--> release frames
              |
              v
       WAITING task can load
              |
              v
            READY
```

This behavior is separate from CPU scheduling.

---

# 17. Task 1a: extending to multiple processors

Once single-processor context switching works, increasing the processor count becomes straightforward.

The Makefile supports:

```bash
make NP=4
```

The processor state arrays become:

```text
Register[4][256]
VectorRegister[4][32][8]
PC[4]
flags[4]
```

The OS also has:

```text
CPU0
CPU1
CPU2
CPU3
```

The same READY queue is shared.

For example:

```text
READY: PID1 PID2 PID3 PID4 PID5 PID6

CPU0 -> PID1
CPU1 -> PID2
CPU2 -> PID3
CPU3 -> PID4
```

After a time slice, contexts are saved and the next READY tasks can be dispatched.

Therefore Task 1a is an extension of the same context-switching abstraction rather than a separate scheduler design.

---

# 18. Task migration in the multiprocessor version

A task is not permanently owned by a CPU.

Example:

```text
Round 1:
PID5 -> CPU0
```

After saving:

```text
PID5 -> READY
```

Later:

```text
PID5 -> CPU2
```

Before CPU2 executes it, the OS restores PID5's context into CPU2 and tells CPU2 to use PID5's memory context.

Therefore:

```text
CPU identity changes
Task context does not
Task page table does not
```

That is the key abstraction needed for a clean multiprocessor extension.

---

# 19. Important files and their responsibilities

## `os.c`

Responsible for:

- Task table
- PID assignment
- Loader
- READY/WAITING/RUNNING state
- Round-robin scheduling
- Dispatch
- Context save/restore calls
- CPU assignment
- Shell
- Task finalization

## `processor.c`

Responsible for:

- CPU registers
- Vector registers
- PC
- Flags
- Fetch/decode/execute
- Context save
- Context restore
- CPU-to-task memory mapping

## `processor.h`

Defines `ProcessorContext` and the processor API.

## `memory.c`

Responsible for:

- Shared physical memory
- Page tables
- Free-frame management
- Logical-to-physical translation
- Loading task pages
- Finalizing task data

## `memory.h`

Defines configurable `NP`, memory sizes, and memory APIs.

## `Makefile`

Allows both modes:

```bash
make              # NP=1
make NP=4         # four CPUs
```

---

# 20. Complete execution flow

The complete flow is:

```text
                   PROGRAM.TXT + DATA.BYTE
                              |
                              v
                           LOADER
                              |
                    +---------+---------+
                    |                   |
             allocate frames       no frames
                    |                   |
                    v                   v
                  READY             WAITING
                    |
                    v
             READY QUEUE
                    |
                    v
                DISPATCH
                    |
          +---------+---------+
          |                   |
       NP = 1             NP = 4
          |                   |
       CPU0             CPU0..CPU3
          |                   |
          +---------+---------+
                    |
                    v
             RESTORE CONTEXT
                    |
                    v
              EXECUTE 10 INS.
                    |
             +------+------+
             |             |
          finished       not finished
             |             |
             v             v
         FINALIZE       SAVE CONTEXT
         free pages     READY queue
             |             |
             +------+------+
                    |
                    v
                 SCHEDULER
                    |
                    +----> next task
```

---

# 21. How to verify the new feature

Build and run the automatic tests:

```bash
make test
```

The test runner explicitly checks a single-processor scenario in which six tasks all execute using CPU0 and the log contains both:

```text
[CONTEXT] SAVE
[CONTEXT] RESTORE
```

It then rebuilds with four processors and verifies that the multiprocessor version executes the same tasks successfully.

The final expected result is:

```text
11/11 tests passed
ALL TESTS PASSED
```

---

# 22. Simple intuition to remember

Think of the CPU as a **desk** and every process as a **student**.

There is only one desk in the single-processor version.

Student A works at the desk for a while. Before leaving, A puts all important papers into A's folder:

```text
A's registers
A's PC
A's flags
A's vector registers
```

Student B then takes the desk and works using B's folder.

Later A returns, opens A's folder, and continues exactly where A stopped.

The desk is the CPU.

The folder is the saved context.

The OS scheduler decides who gets the desk.

With four desks (`NP=4`), four students can work at the same time, while the same context-saving idea is still used whenever tasks are switched.
