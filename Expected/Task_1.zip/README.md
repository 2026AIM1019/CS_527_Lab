# CS527 Lab 5 - Task 1: Context Switching and Multiprocessor Extension

This project is the CS527 Lab 5 mini-computer simulator extended with **Task 1**:

1. **Single processor multitasking:** one processor executes multiple tasks by using time-sliced scheduling and saving/restoring each task's CPU context.
2. **Task 1a - multiprocessor extension:** the same design can be compiled with multiple processor instances. The default build uses one processor; `NP=4` enables four processors.

The original Lab 5 functionality is retained: compiler, bytecode execution, vector registers/instructions, Print, OS shell, paging, logical-to-physical address translation, shared physical memory, and the existing tests.

---

## 1. What was changed for this task?

### Single processor multitasking

The default configuration is:

```text
NP = 1
```

There can still be many processes. They do **not** need one processor each.

The scheduler gives one READY task a fixed time slice (`TIME_SLICE = 10` instructions). When the slice ends:

```text
CPU registers + vector registers + PC + flags
                |
                v
        Task's saved context
                |
                v
        CPU becomes available
                |
                v
       another READY task runs
```

When the old task is selected again, its saved context is restored and execution continues from its saved PC.

### Multiprocessor extension

Build with:

```bash
make NP=4
```

Now four processor instances exist. The same READY queue is shared by all processors. A task is not permanently tied to a processor, so a saved task can later resume on another processor.

---

## 2. Build the project

### Default: single processor

```bash
make clean
make
```

This builds the main requested version with:

```text
NP = 1
```

### Four-processor extension

```bash
make clean
make NP=4
```

or simply:

```bash
make mp
```

`make mp` rebuilds the executable with four processors.

---

## 3. How to run the project

The executable is:

```bash
./executable
```

There are two ways to provide tasks.

### Method A - command-line input

Pass program/data pairs:

```bash
./executable tests/test_01/program.txt tests/test_01/data.byte
```

For multiple tasks:

```bash
./executable \
  tests/lab4_multiprocess/program1.txt tests/lab4_multiprocess/data1.byte \
  tests/lab4_multiprocess/program2.txt tests/lab4_multiprocess/data2.byte \
  tests/lab4_multiprocess/program3.txt tests/lab4_multiprocess/data3.byte
```

The arguments must always occur in pairs:

```text
program-file data-file
```

### Method B - interactive shell

Run:

```bash
./executable
```

You will see:

```text
$ 
```

Enter:

```text
$ tests/test_01/program.txt tests/test_01/data.byte
```

The shell accepts the program/data pair and the OS creates a new PID.

You can also omit the `$` when typing:

```text
tests/test_01/program.txt tests/test_01/data.byte
```

To stop accepting new tasks:

```text
$ exit
```

`exit` does **not** kill existing tasks. The scheduler continues executing all already accepted tasks until they finish.

---

## 4. How multiple tasks execute on ONE processor

Suppose the READY queue contains:

```text
PID1 PID2 PID3
```

With `NP=1` the scheduler behaves conceptually like:

```text
Round 1:
    CPU0 -> PID1 -> 10 instructions
    SAVE PID1 context

Round 2:
    RESTORE PID2 context
    CPU0 -> PID2 -> 10 instructions
    SAVE PID2 context

Round 3:
    RESTORE PID3 context
    CPU0 -> PID3 -> 10 instructions
    SAVE PID3 context

Round 4:
    RESTORE PID1 context
    CPU0 -> PID1 -> next 10 instructions
```

Therefore multiple programs make progress even though there is only one physical CPU instance.

This is **concurrent time sharing**, not true simultaneous execution on one CPU.

---

## 5. What is saved during a context switch?

For every task, the OS stores a `ProcessorContext` containing:

- 256 integer registers (`x0` to `x255`)
- 32 vector registers (`v0` to `v31`), each represented as 8 x 32-bit lanes
- Program Counter (`PC`)
- `Z`, `N`, `C`, `V` flags
- End-of-simulation state
- A flag telling whether the context has been initialized

The context is stored inside the task's OS table, not inside the processor.

This is important because the processor is a reusable resource. The task owns its execution state.

---

## 6. Task identity vs processor identity

A major implementation detail is that **PID/task identity is different from CPU identity**.

A task can run like this:

```text
PID 5 -> CPU 0
       SAVE
PID 5 -> CPU 1
       RESTORE
```

The MMU therefore uses a **task slot** for the page table instead of using the CPU number.

This prevents a context switch or CPU migration from accidentally changing the task's logical-to-physical memory mapping.

---

## 7. Physical memory and paging

The Lab 5 memory model remains:

```text
MEMSIZE  = 8192 bytes
PAGESIZE = 512 bytes
```

There are:

```text
8192 / 512 = 16 physical frames
```

Frame 0 is reserved, leaving 15 allocatable frames.

Every task has its own page table:

```c
pageTable[MAX_PROCESSES][NUM_LOGICAL_PAGES]
```

This is different from the CPU count. A system with `NP=1` can still have many task page tables.

---

## 8. Scheduler process

The scheduler repeatedly performs:

```text
1. Promote tasks waiting for physical memory.
2. Find idle CPUs.
3. Dispatch READY tasks.
4. Restore their contexts.
5. Execute TIME_SLICE instructions.
6. If task finished:
       finalize data
       release physical frames
       remove task
   else:
       save processor context
       move task back to READY
       free the CPU
7. Try waiting tasks again.
8. Let the non-blocking shell accept another task.
9. Repeat until shell exited and no task remains.
```

---

## 9. Process log

Execution details are written to:

```text
process.log
```

Useful entries include:

```text
[DISPATCH] PID 2 -> CPU 0
[CONTEXT] SAVE PID 2 <- CPU 0: PC=40
[CONTEXT] RESTORE PID 2 -> CPU 0: PC=40
[FINISH] PID 2 completed on CPU 0
```

These entries make it easy to verify that context saving/restoring is actually happening.

---

## 10. Demonstration mode

For the four-processor demonstration:

```bash
make demo
```

This builds with `NP=4` and runs the existing multi-process demonstration with detailed scheduler output.

---

## 11. Automatic tests

Run:

```bash
make test
```

The test runner checks:

- Existing scalar tests
- Vector array addition
- Vector FIR
- Print instruction
- **Single-processor context switching**
- **Four-processor extension**
- Lab 5 MMU/page-boundary behavior

The test runner automatically builds the required processor count for each test group.

Expected final message:

```text
11/11 tests passed
ALL TESTS PASSED
```

---

## 12. Source files

```text
main.c          Program entry point
compiler.c      Source-language compiler
compiler.h      Compiler declarations
processor.c     CPU execution + context save/restore
processor.h     Processor state/context declarations
memory.c        Physical memory + page tables + MMU
memory.h        Memory configuration/declarations
os.c            Tasks, loader, scheduler, shell, context switching
os.h            OS declarations
Makefile        Build/test commands

INTUITION_AND_PROCESS.md   Detailed explanation of the design
TEST_CASES.md              Existing test descriptions
LAB5_CHANGES.md            Lab 5 memory/MMU notes
test_runner.py             Automated regression tests
run_multiprocess_demo.sh   Four-processor demo
```

---

## 13. Important commands at a glance

```bash
# Single processor - main Task 1 version
make clean
make
./executable

# Four processor - Task 1a extension
make clean
make NP=4
./executable

# Four processor demonstration
make demo

# Complete automated verification
make test
```
