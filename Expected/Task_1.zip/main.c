#include <stdio.h>
#include "os.h"

int main(int argc, char **argv)
{
    /*
     * Tasks are passed as program/data pairs.  With no command-line tasks,
     * the interactive non-blocking shell accepts them while the scheduler
     * is running.
     */
    if (argc > 1 && ((argc - 1) % 2 != 0)) {
        fprintf(stderr,
                "Usage: %s [program.txt data.byte] [program.txt data.byte] ...\n",
                argv[0]);
        return 1;
    }

    os_init();

    /* Load all command-line tasks before starting the scheduler. */
    for (int i = 1; i < argc; i += 2) {
        if (loader(argv[i], argv[i + 1]) < 0)
            return 1;
    }

    /*
     * The OS scheduler now owns CPU assignment and context switching.
     * Default build: one processor (NP=1).
     * Extension build: make NP=4 executable.
     */
    scheduler();
    return 0;
}
