#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <stdint.h>
#include <stdio.h>
#include "memory.h"

/*
 * A processor has a small amount of architectural state.  When the OS
 * switches from one task to another, this state must be saved somewhere
 * safe and restored when that task gets the CPU again.
 *
 * Keeping this structure explicit makes the context-switch idea easy to
 * see: Task A's registers are not overwritten by Task B; they are copied
 * out before the switch and copied back before A runs again.
 */
typedef struct {
    int32_t integer[256];
    int32_t vector[32][8];
    int pc;
    int z, n, c, v;
    int end_of_simulation;
    int initialized;
} ProcessorContext;

extern int32_t Register[NP][256];
extern int32_t VectorRegister[NP][32][8];
extern int PC[NP];

extern int opcode, dest, src1, src2;
extern int Z[NP], N[NP], C[NP], V[NP];
extern int process_pid[NP];
extern int end_of_simulation[NP];
extern int proc_id;
extern FILE *fd_log;

void reset(int id);
void fetch(int id);
void decode(void);
void execute(int id);
void process_instructions(int id, int instruction_count);
void set_processor_pid(int id, int pid);

/* Context-switch support used by the operating system scheduler. */
void save_processor_context(int id, ProcessorContext *context);
void load_processor_context(int id, const ProcessorContext *context);
void set_memory_context(int processor_id, int task_slot);

#endif
