#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>

/*
 * NP is deliberately configurable at compile time.
 *
 * Default: NP=1 -> the main version demonstrates a single CPU doing
 * multitasking by saving/restoring task contexts.
 *
 * Extension: make NP=4 -> the same OS/processor code uses four CPU
 * instances, which demonstrates the multiprocessor extension (Task 1a).
 */
#ifndef NP
#define NP 1
#endif

#define MAX_PROCESSES 128
#define MEMSIZE 8192
#define PAGESIZE 512
#define NUM_LOGICAL_PAGES (1024 / PAGESIZE + 4096 / PAGESIZE)
#define NUM_PHYSICAL_PAGES (MEMSIZE / PAGESIZE)
#define INSTRUCTION_LOGICAL_SIZE 1024
#define DATA_LOGICAL_SIZE 4096

extern unsigned char memory[MEMSIZE];
/*
 * Page tables belong to TASKS, not processors.  A task may run on CPU 0
 * in one time slice and CPU 1 in a later slice, so using the CPU number as
 * the page-table index would be incorrect.
 */
extern unsigned char pageTable[MAX_PROCESSES][NUM_LOGICAL_PAGES];
extern unsigned char freePages[NUM_PHYSICAL_PAGES];

void memory_system_init(void);
int getPhysicallAddress(int task_slot, int isFetch, int address);
int getFreePage(void);
void releaseProcessPages(int task_slot);

int initialize(int task_slot, const char *program_file, const char *data_file);
int finalize(int task_slot, const char *data_file);

int32_t read_memory_32(int task_slot, int address);
void write_memory_32(int task_slot, int address, int32_t value);

#endif
