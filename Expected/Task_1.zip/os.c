#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>
#include <time.h>
#include <stdarg.h>
#include "os.h"
#include "compiler.h"
#include "memory.h"
#include "processor.h"

/*
 * The OS keeps the life-cycle state of every user task here.
 *
 * Important design change for this task:
 *   - proc_id is NOT the identity of a task.
 *   - A task owns a ProcessorContext which lives in the OS task table.
 *   - A CPU is only a temporary execution resource.
 *
 * Therefore the same task can run on CPU 0 now and CPU 1 later without
 * losing its registers, PC or condition flags.
 */
typedef enum { UNUSED=0, READY=1, RUNNING=2, WAITING=3 } State;

typedef struct {
    int pid;
    int proc_id;                 /* -1 when the task is not on a CPU. */
    State state;
    char program_file[512];
    char data_file[512];
    char generated_program[512];
    ProcessorContext context;    /* Saved CPU state for this task. */
} Task;

static Task tasks[MAX_PROCESSES];
static int next_pid = 1;

/* proc_pid[p] tells which task is currently occupying processor p. */
static int proc_pid[NP];

static int shell_exit = 0;
static char shell_line[1024];
static int shell_len = 0;
static int prompt_shown = 0;
static int demo_mode = 0;
static unsigned long scheduler_round = 0;

/* Starting point used by the round-robin ready-queue search. */
static int ready_cursor = 0;

static void log_event(const char *fmt, ...)
{
    if (!fd_log) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(fd_log, fmt, ap);
    va_end(ap);
    fflush(fd_log);
}

static void msleep(unsigned usec)
{
    struct timespec ts;
    ts.tv_sec = usec / 1000000U;
    ts.tv_nsec = (long)(usec % 1000000U) * 1000L;
    nanosleep(&ts, NULL);
}

static Task *find_task(int pid)
{
    for (int i = 0; i < MAX_PROCESSES; ++i)
        if (tasks[i].state != UNUSED && tasks[i].pid == pid)
            return &tasks[i];
    return NULL;
}

static int find_task_slot_by_pid(int pid)
{
    for (int i = 0; i < MAX_PROCESSES; ++i)
        if (tasks[i].state != UNUSED && tasks[i].pid == pid)
            return i;
    return -1;
}

static int file_readable(const char *path)
{
    FILE *fp = fopen(path, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

static int copy_file(const char *src, const char *dst)
{
    FILE *a = fopen(src, "rb");
    FILE *b;
    char buf[4096];
    size_t n;

    if (!a) return 0;
    b = fopen(dst, "wb");
    if (!b) {
        fclose(a);
        return 0;
    }

    while ((n = fread(buf, 1, sizeof(buf), a)) > 0) {
        if (fwrite(buf, 1, n, b) != n) {
            fclose(a);
            fclose(b);
            return 0;
        }
    }

    fclose(a);
    fclose(b);
    return 1;
}

static void sibling_path(const char *source, const char *name, char *out, size_t n)
{
    const char *slash = strrchr(source, '/');

    if (slash) {
        size_t k = (size_t)(slash - source);
        if (k + 1 + strlen(name) + 1 <= n) {
            memcpy(out, source, k);
            out[k] = '/';
            strcpy(out + k + 1, name);
            return;
        }
    }

    snprintf(out, n, "%s", name);
}

void os_init(void)
{
    memset(tasks, 0, sizeof(tasks));
    memset(proc_pid, 0, sizeof(proc_pid));
    next_pid = 1;
    shell_exit = 0;
    shell_len = 0;
    prompt_shown = 0;
    scheduler_round = 0;
    ready_cursor = 0;
    demo_mode = (getenv("OS_DEMO") != NULL);

    /* Physical memory and all per-task page tables start empty. */
    memory_system_init();

    fd_log = fopen("process.log", "w");
    if (!fd_log) {
        fprintf(stderr, "OS: warning: cannot open process.log\n");
    } else {
        log_event("============================================================\n");
        log_event("                 CS527 LAB 5 PROCESS LOG\n");
        log_event("============================================================\n");
        log_event("[OS] NP=%d, TIME_SLICE=%d instructions\n", NP, TIME_SLICE);
        log_event("[OS] Task contexts are saved/restored on every context switch.\n\n");
    }
}

/*
 * Load a new task into memory.
 *
 * Notice that we no longer require a free CPU here.  A task can be loaded
 * into the READY queue even when every CPU is busy.  The scheduler will
 * give it a CPU at the next context-switch opportunity.
 */
int loader(const char *program_file, const char *data_file)
{
    int slot = -1;
    char generated[512] = {0};
    char program_byte[512];
    const char *dot;
    int is_source;

    if (!program_file || !data_file || !*program_file || !*data_file) {
        fprintf(stderr, "OS: program and data filenames are required\n");
        return -1;
    }

    if (!file_readable(program_file)) {
        fprintf(stderr, "[Loader] Cannot open program: %s\n", program_file);
        return -1;
    }
    if (!file_readable(data_file)) {
        fprintf(stderr, "[Loader] Cannot open data: %s\n", data_file);
        return -1;
    }

    for (int i = 0; i < MAX_PROCESSES; ++i) {
        if (tasks[i].state == UNUSED) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        fprintf(stderr, "OS: process table full\n");
        return -1;
    }

    dot = strrchr(program_file, '.');
    is_source = dot && strcmp(dot, ".txt") == 0;

    if (is_source) {
        sibling_path(program_file, "program.byte", program_byte, sizeof(program_byte));
        compile(program_file, program_byte);
        if (!file_readable(program_byte)) {
            fprintf(stderr, "OS: compilation failed for %s\n", program_file);
            return -1;
        }

        if (snprintf(generated, sizeof(generated), "%s.pid%d", program_byte,
                     next_pid) >= (int)sizeof(generated)) {
            fprintf(stderr, "OS: generated bytecode path is too long\n");
            return -1;
        }

        if (!copy_file(program_byte, generated)) {
            fprintf(stderr, "OS: cannot preserve generated bytecode %s\n", program_byte);
            return -1;
        }
        program_file = generated;
    }

    memset(&tasks[slot], 0, sizeof(tasks[slot]));
    tasks[slot].pid = next_pid++;
    tasks[slot].proc_id = -1;
    tasks[slot].state = WAITING;
    snprintf(tasks[slot].program_file, sizeof(tasks[slot].program_file), "%s", program_file);
    snprintf(tasks[slot].data_file, sizeof(tasks[slot].data_file), "%s", data_file);
    snprintf(tasks[slot].generated_program, sizeof(tasks[slot].generated_program), "%s", generated);

    /*
     * Page tables are indexed by task slot, not CPU id.  This is what makes
     * CPU migration/context switching safe.
     */
    int init_rc = initialize(slot, program_file, data_file);
    if (init_rc == 0) {
        tasks[slot].state = READY;
        tasks[slot].context.initialized = 0;
        printf("[OS] PID %d loaded into READY queue\n", tasks[slot].pid);
        log_event("[LOADER] PID %d loaded; task slot=%d; state=READY\n",
                  tasks[slot].pid, slot);
    } else if (init_rc == -2) {
        /* Physical memory is a temporary resource shortage.  Keep the task
           and its generated bytecode so it can be retried later. */
        tasks[slot].state = WAITING;
        printf("[OS] PID %d placed in WAITING queue (physical memory unavailable)\n",
               tasks[slot].pid);
        log_event("[STATE] PID %d: NEW -> WAITING (physical memory unavailable)\n",
                  tasks[slot].pid);
    } else {
        fprintf(stderr, "OS: failed to initialize PID %d\n", tasks[slot].pid);
        if (generated[0]) unlink(generated);
        memset(&tasks[slot], 0, sizeof(tasks[slot]));
        return -1;
    }

    if (demo_mode)
        printf("[DEMO] PID %d -> %s queue\n", tasks[slot].pid,
               tasks[slot].state == READY ? "READY" : "WAITING");

    fflush(stdout);
    return tasks[slot].pid;
}

/*
 * Try to move waiting tasks into memory after a running task has finished.
 * This is independent of CPU availability because READY tasks themselves
 * do not own a CPU permanently.
 */
static void promote_waiting(void)
{
    for (int i = 0; i < MAX_PROCESSES; ++i) {
        if (tasks[i].state != WAITING) continue;

        int rc = initialize(i, tasks[i].program_file, tasks[i].data_file);
        if (rc != 0)
            continue; /* rc=-2 means physical memory is still full. */

        tasks[i].state = READY;
        tasks[i].context.initialized = 0;
        log_event("[STATE] PID %d: WAITING -> READY\n", tasks[i].pid);
        if (demo_mode)
            printf("[DEMO] WAITING -> READY: PID %d\n", tasks[i].pid);
        else
            printf("[OS] PID %d moved from WAITING to READY queue\n", tasks[i].pid);
    }
}

/* Return true if the task is currently executing on some CPU. */
static int task_is_running(const Task *task)
{
    return task && task->state == RUNNING && task->proc_id >= 0;
}

/*
 * Pick the next READY task using round-robin order.
 *
 * This is the key scheduler operation for the single-processor version:
 * PID 1 runs for one time slice, its context is saved, then PID 2 gets the
 * same CPU, and later PID 1's saved context is restored.
 */
static int next_ready_task(void)
{
    for (int step = 0; step < MAX_PROCESSES; ++step) {
        int index = (ready_cursor + step) % MAX_PROCESSES;
        if (tasks[index].state == READY && !task_is_running(&tasks[index])) {
            ready_cursor = (index + 1) % MAX_PROCESSES;
            return index;
        }
    }
    return -1;
}

/*
 * Give idle processors a READY task.
 *
 * With NP=1 this is ordinary context switching on one CPU.
 * With NP=4 it becomes the requested multiprocessor extension: up to four
 * READY tasks execute in each scheduler round, and tasks can migrate when
 * a different CPU becomes available.
 */
static void dispatch_ready_tasks(void)
{
    for (int p = 0; p < NP; ++p) {
        if (proc_pid[p] != 0) continue;

        int slot = next_ready_task();
        if (slot < 0) break;

        Task *task = &tasks[slot];
        task->proc_id = p;
        task->state = RUNNING;
        proc_pid[p] = task->pid;

        set_memory_context(p, slot);
        set_processor_pid(p, task->pid);

        if (task->context.initialized) {
            /* Resume exactly where this task stopped last time. */
            load_processor_context(p, &task->context);
            log_event("[CONTEXT] RESTORE PID %d -> CPU %d: PC=%d\n",
                      task->pid, p, task->context.pc);
            if (demo_mode)
                printf("[DEMO] RESTORE context: PID %d on CPU %d (PC=%d)\n",
                       task->pid, p, task->context.pc);
        } else {
            /* First execution: create a clean architectural state. */
            reset(p);
            set_memory_context(p, slot);
            set_processor_pid(p, task->pid);
            log_event("[CONTEXT] CREATE PID %d -> CPU %d: PC=0\n", task->pid, p);
        }

        log_event("[DISPATCH] PID %d -> CPU %d\n", task->pid, p);
        if (demo_mode)
            printf("[DEMO] DISPATCH PID %d -> CPU %d\n", task->pid, p);
    }
}

/*
 * Finish one task and release its memory pages.
 */
static void finish_task(int p)
{
    int pid = proc_pid[p];
    int slot = find_task_slot_by_pid(pid);
    if (slot < 0) {
        proc_pid[p] = 0;
        return;
    }

    Task *task = &tasks[slot];

    if (finalize(slot, task->data_file) != 0) {
        fprintf(stderr, "[OS] Warning: could not finalize PID %d\n", task->pid);
        log_event("[FINISH] PID %d finalize returned an error\n", task->pid);
    }

    log_event("[FINISH] PID %d completed on CPU %d\n", task->pid, p);
    log_event("[MEMORY] PID %d released its physical-memory frames\n", task->pid);
    printf("[OS] PID %d finished on CPU %d\n", task->pid, p);

    if (demo_mode)
        printf("[DEMO] PID %d -> FINISHED; CPU %d becomes FREE\n", task->pid, p);

    if (task->generated_program[0]) unlink(task->generated_program);

    task->state = UNUSED;
    task->proc_id = -1;
    proc_pid[p] = 0;
    set_memory_context(p, -1);
}

static const char *state_name(State s)
{
    switch (s) {
        case READY: return "READY";
        case RUNNING: return "RUNNING";
        case WAITING: return "WAITING";
        default: return "UNUSED";
    }
}

static void log_queue_status(const char *phase)
{
    if (!fd_log) return;

    log_event("[QUEUE] %s\n", phase);
    log_event("        READY : ");
    int any = 0;
    for (int i = 0; i < MAX_PROCESSES; ++i) {
        if (tasks[i].state == READY) {
            log_event("PID%d ", tasks[i].pid);
            any = 1;
        }
    }
    if (!any) log_event("EMPTY");
    log_event("\n        WAITING: ");
    any = 0;
    for (int i = 0; i < MAX_PROCESSES; ++i) {
        if (tasks[i].state == WAITING) {
            log_event("PID%d ", tasks[i].pid);
            any = 1;
        }
    }
    if (!any) log_event("EMPTY");
    log_event("\n        CPU    : ");
    for (int p = 0; p < NP; ++p) {
        if (proc_pid[p]) {
            Task *t = find_task(proc_pid[p]);
            log_event("CPU%d=PID%d(%s) ", p, proc_pid[p],
                      t ? state_name(t->state) : "?");
        } else {
            log_event("CPU%d=IDLE ", p);
        }
    }
    log_event("\n");
}

static void print_scheduler_status(const char *phase)
{
    if (!demo_mode) return;

    printf("\n[DEMO] Scheduler round %lu -- %s\n", scheduler_round, phase);
    printf("[DEMO] CPUs: ");
    for (int p = 0; p < NP; ++p) {
        if (proc_pid[p]) {
            Task *t = find_task(proc_pid[p]);
            printf("CPU%d=PID%d(%s)%s", p, proc_pid[p],
                   t ? state_name(t->state) : "?",
                   p == NP - 1 ? "" : " | ");
        } else {
            printf("CPU%d=IDLE%s", p, p == NP - 1 ? "" : " | ");
        }
    }

    printf("\n[DEMO] READY queue: ");
    int any_ready = 0;
    for (int i = 0; i < MAX_PROCESSES; ++i) {
        if (tasks[i].state == READY) {
            printf("PID%d ", tasks[i].pid);
            any_ready = 1;
        }
    }
    if (!any_ready) printf("empty");

    printf("\n[DEMO] WAITING queue: ");
    int any_waiting = 0;
    for (int i = 0; i < MAX_PROCESSES; ++i) {
        if (tasks[i].state == WAITING) {
            printf("PID%d ", tasks[i].pid);
            any_waiting = 1;
        }
    }
    if (!any_waiting) printf("empty");
    printf("\n");
    fflush(stdout);
}

static void print_time_slice(int p, int pid, int instructions)
{
    if (!demo_mode) return;
    printf("[DEMO] CPU %d: PID %d executes %d instructions (time slice)\n",
           p, pid, instructions);
    fflush(stdout);
}

static void print_prompt(void)
{
    if (!prompt_shown && !shell_exit) {
        printf("$ ");
        fflush(stdout);
        prompt_shown = 1;
    }
}

/* Non-blocking shell. One complete line is consumed per scheduler turn. */
void shell(void)
{
    fd_set set;
    struct timeval tv = {0, 0};
    char ch;

    if (shell_exit) return;
    print_prompt();

    FD_ZERO(&set);
    FD_SET(STDIN_FILENO, &set);
    if (select(STDIN_FILENO + 1, &set, NULL, NULL, &tv) <= 0) return;

    while (read(STDIN_FILENO, &ch, 1) == 1) {
        if (ch == '\r') continue;

        if (ch == '\n') {
            char local[1024];
            char *save = NULL;
            char *a, *b, *extra;
            int pid;

            shell_line[shell_len] = '\0';
            snprintf(local, sizeof(local), "%s", shell_line);
            shell_len = 0;

            char *s = local;
            while (*s == ' ' || *s == '\t') ++s;
            if (*s == '$') {
                ++s;
                while (*s == ' ' || *s == '\t') ++s;
            }

            if (*s == '\0') {
                prompt_shown = 0;
                print_prompt();
                return;
            }

            if (strcmp(s, "exit") == 0) {
                shell_exit = 1;
                prompt_shown = 0;
                log_event("[SHELL] exit received; no new tasks will be accepted.\n");
                printf("[OS] Shell exiting; existing tasks will continue.\n");
                fflush(stdout);
                return;
            }

            a = strtok_r(s, " \t", &save);
            b = strtok_r(NULL, " \t", &save);
            extra = strtok_r(NULL, " \t", &save);

            if (!a || !b || extra) {
                fprintf(stderr, "[Shell] Invalid command. Use: <program.txt> <data.byte>\n");
                prompt_shown = 0;
                print_prompt();
                return;
            }

            pid = loader(a, b);
            if (pid > 0)
                printf("[OS] PID %d accepted\n", pid);
            fflush(stdout);
            prompt_shown = 0;
            print_prompt();
            return;
        }

        if (shell_len < (int)sizeof(shell_line) - 1)
            shell_line[shell_len++] = ch;
    }

    /* stdin closed: behave like 'exit', but don't block the OS. */
    shell_exit = 1;
}

void scheduler(void)
{
    while (1) {
        int active = 0;
        ++scheduler_round;

        log_event("\n-------------------- SCHEDULER ROUND %lu --------------------\n",
                  scheduler_round);

        /* Tasks waiting for physical frames may become READY after a
           previous task has finished and released its frames. */
        promote_waiting();

        /* Fill all currently idle CPUs from the shared READY queue. */
        dispatch_ready_tasks();

        log_event("[QUEUE] Scheduler begins round %lu\n", scheduler_round);
        print_scheduler_status("before time slices");
        log_queue_status("Before time slices");

        /*
         * Every CPU gets one time slice.  In NP=1 there is only one loop
         * iteration, so the same CPU is deliberately reused for many tasks
         * across scheduler rounds.  In NP=4, four CPUs receive slices.
         */
        for (int p = 0; p < NP; ++p) {
            if (!proc_pid[p]) continue;

            active = 1;
            int pid = proc_pid[p];
            int slot = find_task_slot_by_pid(pid);
            Task *task = (slot >= 0) ? &tasks[slot] : NULL;
            if (!task) {
                proc_pid[p] = 0;
                continue;
            }

            task->state = RUNNING;
            log_event("[RUN] Round %lu: CPU %d -> PID %d\n",
                      scheduler_round, p, pid);
            log_event("[TIME SLICE] PID %d on CPU %d: execute up to %d instructions\n",
                      pid, p, TIME_SLICE);
            print_time_slice(p, pid, TIME_SLICE);

            process_instructions(p, TIME_SLICE);

            if (end_of_simulation[p]) {
                /* The task is finished; its data is written back and its
                   physical frames are returned to the MMU. */
                finish_task(p);
            } else {
                /*
                 * This is the actual context switch:
                 *   1. Save CPU registers/PC/flags into the task.
                 *   2. Mark the task READY.
                 *   3. Release the CPU so another READY task can use it.
                 *
                 * Nothing is reset here.  The saved PC is exactly where
                 * the task must continue during its next time slice.
                 */
                save_processor_context(p, &task->context);
                task->state = READY;
                task->proc_id = -1;
                proc_pid[p] = 0;

                log_event("[CONTEXT] SAVE PID %d <- CPU %d: PC=%d\n",
                          task->pid, p, task->context.pc);
                log_event("[TIME SLICE END] PID %d: RUNNING -> READY; CPU state saved\n",
                          task->pid);
                if (demo_mode)
                    printf("[DEMO] SAVE context: PID %d from CPU %d (PC=%d)\n",
                           task->pid, p, task->context.pc);
            }
        }

        /* A completed task may have freed enough frames for waiting tasks. */
        promote_waiting();

        print_scheduler_status("after time slices");
        log_queue_status("After time slices");
        shell();

        for (int p = 0; p < NP; ++p)
            if (proc_pid[p]) active = 1;

        for (int i = 0; i < MAX_PROCESSES; ++i)
            if (tasks[i].state == READY || tasks[i].state == WAITING)
                active = 1;

        if (shell_exit && !active) break;

        /* Small delay keeps the demonstration readable without affecting
           the architectural meaning of a time slice. */
        msleep(1000);
    }

    log_event("\n============================================================\n");
    log_event("[OS] Scheduler stopped: all tasks finished and shell exited.\n");
    log_event("============================================================\n");

    if (fd_log) {
        fflush(fd_log);
        fclose(fd_log);
        fd_log = NULL;
    }
}

int os_should_exit(void)
{
    return shell_exit;
}
