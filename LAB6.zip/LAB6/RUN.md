# RUN.md

## Assignment 5 Lab 6 - Build, Test and Run Instructions

This file contains the exact commands to compile, test, and run the project on Ubuntu/Linux.

---

## 1. Open the project folder

Open a terminal and go to the project directory.

Example:

```bash
cd ~/Downloads/assignment_05_lab6_no_python
```

Check that the required files are present:

```bash
ls
```

You should see files such as:

```text
Makefile
main.c
os.c
os.h
memory.c
memory.h
processor.c
processor.h
compiler.c
compiler.h
tests/
test_runner.sh
run_multiprocess_demo.sh
```

---

## 2. Give execute permission to shell scripts

Run:

```bash
chmod +x test_runner.sh
chmod +x run_multiprocess_demo.sh
```

---

## 3. Clean the previous build

Run:

```bash
make clean
```

Expected output is similar to:

```text
rm -f *.o executable process.log
```

### Important

Do NOT write:

```bash
make clean make
```

Those are two separate `make` commands.

Correct:

```bash
make clean
make
```

---

## 4. Build the project

Run:

```bash
make
```

The compiler will compile:

```text
main.c
compiler.c
memory.c
processor.c
os.c
```

and create:

```text
executable
```

Check it:

```bash
ls -l executable
```

---

# 5. Run all automated tests

The easiest way to verify the complete assignment is:

```bash
make test
```

The test runner will build the project and execute all automated tests.

Expected final result:

```text
[PASS] Clean
[PASS] Build
[PASS] test_01
[PASS] test_02
[PASS] test_03
[PASS] test_04
[PASS] test_05
[PASS] vector_array_add
[PASS] vector_fir
[PASS] lab4_print
[PASS] lab4_multiprocess
[PASS] lab5_mmu
[PASS] lab6_frequency
[PASS] lab6_page_table_storage

14/14 tests passed
ALL TESTS PASSED
```

If you get:

```text
14/14 tests passed
ALL TESTS PASSED
```

the automated test suite has passed.

---

# 6. Build again after `make test`

In this version of the project, the test runner performs a clean operation as part of its testing process.

Therefore, after:

```bash
make test
```

run:

```bash
make
```

This ensures that the `executable` is available for manual execution.

Check:

```bash
ls -l executable
```

---

# 7. Run the simulator interactively

The simulator uses an interactive shell.

Start it with:

```bash
./executable
```

You should see:

```text
$
```

At the `$` prompt, enter a program/data pair.

For example:

```text
tests/test_01/program.txt tests/test_01/data.byte
```

Do NOT type:

```text
./executable tests/test_01/program.txt tests/test_01/data.byte
```

inside the simulator shell.

The `./executable` part is only used when starting the simulator from the Linux terminal.

Correct sequence:

```bash
./executable
```

Then inside the simulator:

```text
$ tests/test_01/program.txt tests/test_01/data.byte
```

---

# 8. Check instruction-frequency output

After executing a program, `.freq` files are generated.

Check:

```bash
ls -l *.freq
```

To display the frequency information:

```bash
cat *.freq
```

For the first test, you can specifically display:

```bash
cat program_1.freq
```

Example output:

```text
1 Read x1, 0
1 Read x2, 4
1 Read x3, 8
1 Read x4, 12
1 x5 = x1 + x2
1 x6 = x3 + x4
1 x7 = x5 + x6
1 Write x7, 16
```

The number at the beginning of each line is the number of times that source-level instruction was executed.

For example:

```text
201 x1 = x1 + 1
```

means that this source instruction executed 201 times.

---

# 9. Run the multiprocessor demonstration

Give permission if necessary:

```bash
chmod +x run_multiprocess_demo.sh
```

Then run:

```bash
./run_multiprocess_demo.sh
```

This can be used to demonstrate the existing multiprocessor/scheduling functionality.

---

# 10. Useful commands

### Clean build files

```bash
make clean
```

### Compile

```bash
make
```

### Run all tests

```bash
make test
```

### Start simulator

```bash
./executable
```

### List frequency files

```bash
ls -l *.freq
```

### Display frequency files

```bash
cat *.freq
```

### Display one frequency file

```bash
cat program_1.freq
```

### Check executable

```bash
ls -l executable
```

### Check project files

```bash
ls -la
```

---

# 11. Recommended complete sequence for demonstration

For a fresh build/demo, use these commands in this order:

```bash
cd ~/Downloads/assignment_05_lab6_no_python

chmod +x test_runner.sh
chmod +x run_multiprocess_demo.sh

make clean
make
make test

make

./executable
```

When the simulator shows:

```text
$
```

enter:

```text
tests/test_01/program.txt tests/test_01/data.byte
```

After execution, stop the interactive simulator when appropriate.

Then check:

```bash
ls -l *.freq
```

and:

```bash
cat program_1.freq
```

---

# 12. Important command-line mistake to avoid

This is WRONG:

```bash
make clean make
```

because `make` treats `make` as another target name.

It can produce:

```text
make: *** No rule to make target 'make'. Stop.
```

Use separate commands:

```bash
make clean
make
```

You can also put them on one line using `&&`:

```bash
make clean && make
```

Similarly, when running the simulator, do not enter:

```text
./executable tests/test_01/program.txt tests/test_01/data.byte
```

after the `$` prompt.

Instead:

```bash
./executable
```

then:

```text
$ tests/test_01/program.txt tests/test_01/data.byte
```

---

# 13. Short version

If everything is already extracted and you are inside the project directory:

```bash
chmod +x test_runner.sh
chmod +x run_multiprocess_demo.sh
make clean
make
make test
make
./executable
```

Then at the `$` prompt:

```text
tests/test_01/program.txt tests/test_01/data.byte
```

Then check:

```bash
ls -l *.freq
cat program_1.freq
```

---

## Expected successful test result

```text
14/14 tests passed
ALL TESTS PASSED
```

This is the main result to show when verifying the project.
